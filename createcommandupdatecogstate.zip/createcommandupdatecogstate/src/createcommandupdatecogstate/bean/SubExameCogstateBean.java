package createcommandupdatecogstate.bean;

public class SubExameCogstateBean {
	private Integer id;
	private Integer score_subexame_cogstate;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getScore_subexame_cogstate() {
		return score_subexame_cogstate;
	}
	public void setScore_subexame_cogstate(Integer score_subexame_cogstate) {
		this.score_subexame_cogstate = score_subexame_cogstate;
	}
}
