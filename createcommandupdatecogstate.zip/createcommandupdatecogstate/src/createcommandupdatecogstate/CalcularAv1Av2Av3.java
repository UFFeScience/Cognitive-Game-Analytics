package createcommandupdatecogstate;

public class CalcularAv1Av2Av3 {
	public Integer[] calcularAv1Av2Av3(Integer[] v_score_cogstate) {
		for ( int index = 0; index < v_score_cogstate.length; index++ ) {
			if ( v_score_cogstate[index] == -12 ) {
				v_score_cogstate[index] = v_score_cogstate[index - 2] - v_score_cogstate[index - 1];
			} else if ( v_score_cogstate[index] == -23 ) {
				v_score_cogstate[index] = v_score_cogstate[index - 3] - v_score_cogstate[index - 1];
			}
		}
		return v_score_cogstate;
	}
}
