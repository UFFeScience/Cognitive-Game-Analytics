package createcommandupdatecogstate;

import java.io.IOException;
import java.sql.SQLException;

import createcommandupdatecogstate.bean.SubExameCogstateBean;
import createcommandupdatecogstate.dao.SubExameCogstateDAO;

public class ExtrairDados {
	//private String[][] matrix_game_hour;
	
	public Integer[] executarQuery(String sub_exame, int index) {
		// TODO Auto-generated method stub
		//List<SubExameCogstateBean> listaDatasRetornadasSubExameCogstate = new ArrayList<SubExameCogstateBean>();
		
		Integer[] v_dadosRetornadosSubExameCogstate = new Integer[186];
		
		SubExameCogstateDAO subExameCogstateDAO = new SubExameCogstateDAO();

		try {
			v_dadosRetornadosSubExameCogstate = subExameCogstateDAO.getListSubExameCogstate(sub_exame);
			//listaDatasRetornadasSubExameCogstate = subExameCogstateDAO.getListSubExameCogstate(sub_exame);
			//GerarMatrizHoraJogo gerarMatrizHoraJogo = new GerarMatrizHoraJogo();
			//matrix_game_hour = gerarMatrizHoraJogo.popularMatrizJogoExame(listaDatasRetornadasAVP, listaDatasRetornadasSJ, datasRetornadasPaciente, id, index);
			return v_dadosRetornadosSubExameCogstate;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} /*catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return null;
	}
}
