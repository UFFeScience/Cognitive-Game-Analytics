package createcommandupdatecogstate;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import createcommandupdatecogstate.util.Constante;
import createcommandupdatecogstate.util.Util;

public class InicioArff {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		File arq_update = new File("/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/scriptsBD/gerar_comandos_sql/UPDATE_COMMAND_TABLE_AVALIACAO_PACIENTE_COM_SUBEXAMES_COGSTATE_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		//File arq_insercao = new File("C:\\gerar_comandos_sql\\UPDATE_COMMAND_TABLE_AVALIACAO_PACIENTE_COM_SUBEXAMES_COGSTATE_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		FileWriter flw = null;
		//try {
		arq_update.createNewFile();
		flw = new FileWriter(arq_update);
		
		
		Integer[] v_score_cogstate = new Integer[186];
		int total_reg = ((Constante.sub_exame_cogstate.length) * (v_score_cogstate.length - 1));
		int parcial_reg = 0;
		for ( int index = 0; index < Constante.sub_exame_cogstate.length; index++ ) {
			
			ExtrairDados extrairDados = new ExtrairDados();
			/* Tratar os Dados antes de gravá-los no arquivo ARFF. */
			v_score_cogstate = extrairDados.executarQuery(Constante.sub_exame_cogstate[index], index);
			CalcularAv1Av2Av3 calcAv1Av2Av3 = new CalcularAv1Av2Av3();
			v_score_cogstate = calcAv1Av2Av3.calcularAv1Av2Av3(v_score_cogstate);
			/* Escrever que Montará o comando Update */
			CreateCommandUpdateCogstate gerarUpdateCogstate = new CreateCommandUpdateCogstate();
			parcial_reg = ((v_score_cogstate.length - 1) * (index + 1));
			gerarUpdateCogstate.gerarScriptUpdateCogstate(flw, Constante.sub_exame_cogstate[index], v_score_cogstate, parcial_reg, total_reg);
		}	
		
		System.exit(0);
	}
}
