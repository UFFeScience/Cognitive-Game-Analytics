package createcommandupdatecogstate;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import createcommandupdatecogstate.util.Util;

public class CreateCommandUpdateCogstate {
	public void gerarScriptUpdateCogstate(FileWriter flw, String sub_exame_cogstate, Integer[] v_score_cogstate, int parcial_reg, int total_reg) throws IOException {
		System.out.println("Arquivo do comando SQL-DDL Update Subexames COGSTATE Criado com Sucesso.");
		/* Construir os dados para montar o script update  */
		for ( int index = 0; index < v_score_cogstate.length; index++ ) {
			gerarCommandUpdateCogstate(flw, sub_exame_cogstate, v_score_cogstate[index], index);
		}
		if ( parcial_reg == total_reg ) {
			fecharArq(flw);
		}
	}
	
	//public void gerarCommandUpdateCogstate(FileWriter flw, int id, String lerNomeRespTxt) {
	public void gerarCommandUpdateCogstate(FileWriter flw, String sub_exame_cogstate, Integer score_cogstate, int index) {
		// TODO Auto-generated method stub
		/* Criar novo Script da Cláusula Update */
		String subexame = null;
		//subexame = sub_exame_cogstate.replaceAll("\\s+", "-1").replaceAll("\\W+", "-2").toUpperCase();
		//subexame = sub_exame_cogstate.replaceAll("\\W+", "-2").toUpperCase();
		String[] subExameCogstate = sub_exame_cogstate.replaceAll("\\W+", "-2").toUpperCase().split("-2");
		if ( subExameCogstate.length == 2 ) {
			subexame = subExameCogstate[0] + "_" + subExameCogstate[1] + "_PONTUACAO";
		} else if ( subExameCogstate.length == 3 ) {
			subexame = subExameCogstate[0] + "_" + subExameCogstate[1] + "_" + subExameCogstate[2] + "_PONTUACAO";
		} else {
			subexame = subExameCogstate[0] + "_" + subExameCogstate[1] + "_" + subExameCogstate[2] + "_" + subExameCogstate[3] + "_PONTUACAO";
		}
		//System.out.println(subexame);
		try {
			flw.write("UPDATE AVALIACAO_PACIENTE SET " + subexame + " = " + score_cogstate + " WHERE ID = " + (index + 1) + ";");
			flw.write("\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void fecharArq(FileWriter flw) throws IOException {
		flw.close();
		System.out.println("Arquivo do comando SQL-DDL Update Subexames COGSTATE Gravado com Sucesso.");
	}
}
