package createcommandupdatecogstate.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	public Connection getConnection() {
		try {
			return DriverManager.getConnection("jdbc:postgresql://localhost:5432/academia_cerebro","postgres","4n5a1r2d0i");
			//return DriverManager.getConnection("jdbc:postgresql://localhost:5433/academia_cerebro_3","postgres","451263");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
