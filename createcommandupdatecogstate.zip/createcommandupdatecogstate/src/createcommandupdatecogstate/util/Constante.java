package createcommandupdatecogstate.util;

public class Constante { 
	public static final Integer[] ID_PACIENTE = {3,6,13,14,15,22,24,26,28,32,34,38,39,50,63,71,76};
	public static final String[] nome_jogo = {"Card shark","Right turn","Mental map","Memory grid","Hawk eye","Mixed signals","Juggle factor","Recognition","Syllable stacks","Visual sweeps","Target tracker","In the Know","Face to face","Optic flow","Face facts","Divided attention","Scene crasher","Freeze frame","Auditory ace","To-Do List Training","Fine Tuning","Double decision","Hear Hear","Rhythm Recall","True north","Eye for detail","Sound sweeps","Mind Bender","Mind Eye"};
	public static final Integer[] n_jogo = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29};
	public static final Integer[] n_jogo_exame = {3,4,6,7,9,10,11,13,14,16,19,22,23,24,27,28};
	public static final Integer[] hora_treino = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40};
	public static final String[] genero = {"Masculino", "Feminino"};
	public static final String[] grupo = {"Bottom up", "Top down"};
	public static final String[] exame = {"Dafs","Hits","Cr","Tiadl","Gds-15","Cogstate","Camcog Recordacao","Camcog Praxia","Fluencia","Trail_a","Trail_b"};
	public static final String[] classAvPaciente = {"Melhorou", "Piorou"};
	public static final String[] sub_exame_cogstate = {"One Back","Two Back","Detection Task","Identification Task","Set Shifting Task","Social-Emotional Cognition Task"};
}
