package createcommandupdatecogstate.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import createcommandupdatecogstate.util.ConnectionFactory;
import createcommandupdatecogstate.bean.SubExameCogstateBean;;

public class SubExameCogstateDAO {
	private Connection conn;
	public SubExameCogstateDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	//public List<SubExameCogstateBean> getListSubExameCogstate(String sub_exame) throws SQLException {
	public Integer[] getListSubExameCogstate(String sub_exame) throws SQLException {
		PreparedStatement stmt = null;
		//List<SubExameCogstateBean> listaSubExameCogstate = new ArrayList<SubExameCogstateBean>();
		//Integer[] v_avp = new Integer[93];
		
		Integer[] v_score = new Integer[186];
		v_score = iniciarVetorScoreCogstate(v_score);
		v_score = iniciarAv1Av2Av3VetorScoreCogstate(v_score);
		
		StringBuilder sqlSubExameCogstate = new StringBuilder();
		
		sqlSubExameCogstate.append("SELECT Avp.id AS id, AACG.score AS score_subexame_cogstate")
		  .append(" FROM ATIVIDADE_COGSTATE ACG")
		  .append(" INNER JOIN")
		  .append(" AVALIACAO_ATIVIDADE_COGSTATE AACG on ACG.ID = AACG.ID_ATIVIDADE_COGSTATE")
		  .append(" INNER JOIN")
		  .append(" AVALIACAO_PACIENTE AVP ON AACG.ID_AVALIACAO = AVP.ID")
		  .append(" WHERE ACG.descricao_teste = '" + sub_exame + "'")
		  .append(" ORDER BY Avp.id;");
		 
		try {
			stmt = conn.prepareStatement(sqlSubExameCogstate.toString());
			ResultSet rs = stmt.executeQuery();
			//int index = 0;
			while ( rs.next() ) {
				SubExameCogstateBean subExameCogstateBean = new SubExameCogstateBean();
				subExameCogstateBean.setId(rs.getInt("id"));
				subExameCogstateBean.setScore_subexame_cogstate(rs.getInt("score_subexame_cogstate"));
				//v_avp[index] = subExameCogstateBean.getId();
				v_score[subExameCogstateBean.getId() - 1] = subExameCogstateBean.getScore_subexame_cogstate();
				//index++;
				//listaSubExameCogstate.add(SubExameCogstateBean);
			}
			rs.close();
		} finally {
			if ( stmt != null ) {
				stmt.close();
			}
			if ( conn != null ) {
				conn.close();
			}
		}
		return v_score;
		//return listaSubExameCogstate;
	}

	public Integer[] iniciarAv1Av2Av3VetorScoreCogstate(Integer[] v_score) {
		// TODO Auto-generated method stub
		//Integer num = (int) Math.ceil(((v_score.length - 93) / 2));
		/* Retornar o Teto de qq número do tipo Double ou Float */
		//Integer num = Math.round(((v_score.length - 93) / 2));
		//for ( int i = 2, j = 4; i <= num && j <= num; i += 6, j += 6 ) {
		for ( int i = 2, j = 4; i < v_score.length && j < v_score.length; i += 6, j += 6 ) {
			v_score[i] = -12;
			v_score[j] = -23;
		}
		return v_score;
	}

	public Integer[] iniciarVetorScoreCogstate(Integer[] v_score) {
		// TODO Auto-generated method stub
		int i = 0;
		while ( i < v_score.length ) {
			v_score[i] = 0;
			i++;
		}
		return v_score;
	}
}
