package createCommandInsertWhoqolGdsKatzLawton;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CreateCommandInsertTug {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreateCommandInsertTug gerarInsertTug = new CreateCommandInsertTug();
		try {
			gerarInsertTug.lerNomeRespTugTxt();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void lerNomeRespTugTxt() throws IOException {
		String lerNomeRespTxt = null;
		Scanner scanner = null;
		String filePath = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/KeyWords/KeyWords_Resp_CAMCOG.txt";
		BufferedInputStream file = new BufferedInputStream(new FileInputStream(filePath));
		/* Vou Scannear o arquivo que está armazenado no Buffer */
		scanner = new Scanner(file);
		int qtdLinhas = 0;
		int id_1 = 1;
		int id_2 = 0;
		File arq_insercao = new File("/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/scriptsBD/gerar_comandos_sql/INSERT_COMMAND_TABLE_AVALIACAO_QUESTAO_CAMCOG_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		//File arq_insercao = new File("C:\\gerar_comandos_sql\\INSERT_COMMAND_TABLE_AVALIACAO_QUESTAO_WHOQOL_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		arq_insercao.createNewFile();
		System.out.println("Arquivo do comando SQL-DDL Insert GDS Criado com Sucesso.");
		FileWriter flw = new FileWriter(arq_insercao);
		String[] paciente = null;
		String item[] = null;
		/* Enquanto tiver registro no arquivo a ser lido, o retorno é true */
		while ( scanner.hasNext() ) {
			qtdLinhas++;
			lerNomeRespTxt = scanner.nextLine();
			paciente = lerNomeRespTxt.split("\t");
			System.out.println("Paciente: " + paciente[0]);
			System.out.println("lerNomeRespTxt: " + lerNomeRespTxt);
			if ( paciente[0].equals("paciente") ) {
				System.out.println("Paciente: " + paciente[1]);
				qtdLinhas--;
				continue;
			}
			/* AV1 */
			if ( qtdLinhas <= 15 ) {
				if ( qtdLinhas <= 10 ) {
					item = lerNomeRespTxt.split("\t");
					System.out.println("Itens_AV1: " + item[0] + "\n" + item[1]);
					gerarCommandInsertTug(flw, id_1, qtdLinhas, (!"null".equals(item[0]) ? '\'' + item[0] + '\'' : '\'' + "Falta Resposta" + '\''), item[1]);
				} else {
					gerarCommandInsertTug(flw, id_1, qtdLinhas, item[0], lerNomeRespTxt);
				}
				
			} else if ( qtdLinhas <= 30 ) {
				/* Quando mudar de uma avaliação para outro, reinicia(com valor 1) a contagem */
				/* AV2 */
				/* Antes de inserir a primeira linha no arquivo quebra a linha duas vezes na Transição Av1 - Av2*/
				if ( qtdLinhas == 16 ) {
					flw.write("\n\n");
				}
				id_2 = id_1 + 1;
				if ( qtdLinhas >= 16 && qtdLinhas <= 25) {
					item = lerNomeRespTxt.split("\t");
					System.out.println("Itens_AV2: " + item[0] + "\n" + item[1]);
					gerarCommandInsertTug(flw, id_2, (qtdLinhas - 15), (!"null".equals(item[0]) ? '\'' + item[0] + '\'' : '\'' + "Falta Resposta" + '\''), item[1]);
				} else {
					gerarCommandInsertTug(flw, id_2, (qtdLinhas - 15), item[0], lerNomeRespTxt);
				}
			} else {
				/* AV3 */
				/* Antes de inserir a primeira linha no arquivo quebra a linha duas vezes na Transição Av2 - Av3 */
				if ( qtdLinhas == 31 ) {
					flw.write("\n\n");
				}
				id_2 = id_1 + 3;
				if ( qtdLinhas >= 31 && qtdLinhas <= 40) {
					item = lerNomeRespTxt.split("\t");
					System.out.println("Itens_AV3: " + item[0] + "\n" + item[1]);
					gerarCommandInsertTug(flw, id_2, (qtdLinhas - 30), (!"null".equals(item[0]) ? '\'' + item[0] + '\'' : '\'' + "Falta Resposta" + '\''), item[1]);
				} else {
					gerarCommandInsertTug(flw, id_2, (qtdLinhas - 30), item[0], lerNomeRespTxt);
				}
			}
			/* Quando mudar de um paciente para outro, reinicia(zerando) a contagem */
			if ( qtdLinhas == 45 ) {
				qtdLinhas = 0;
				id_1 = id_2 + 3; // ou id_1 = id_3 + 3
				flw.write("\n\n\n");
			}

		}
		
		fecharArq(flw);
	}

	//public void gerarCommandInsertCamcog(FileWriter flw, int id, int index, String lerNomeRespTxt) {
	public void gerarCommandInsertTug(FileWriter flw, int id, int index, String resposta, String tempo_real) {	
		// TODO Auto-generated method stub
		/* Criar novo arquivo de Inserção */
		try {

			//if ( index == 27 ) {
			/* Quebradentro de cada Exame, pois tem exames que possuem subseções, como o caso do Whoqol e Camcoq(1 - Rec; 2 - Praxia) */
			if ( index == 11 ) {
				flw.write("\n");
			} /*else if ( index == 31 ) {
				flw.write("\n");
			}*/
			
			//flw.write("INSERT INTO avaliacao_questao_whoqol (id_avaliacao, id_questao_whoqol, resposta_questao_whoqol) values ("+ id + "," + index + "," + '\'' + lerNomeRespTxt + '\'' + ");" + "\n");
			flw.write("INSERT INTO avaliacao_atividade_tug (id_avaliacao, id_atividade_tug, resposta, tempo_real) values ("+ id + "," + index + "," + resposta + "," + tempo_real + ");" + "\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void fecharArq(FileWriter flw) throws IOException {
		flw.close();
		System.out.println("Arquivo do comando SQL-DDL Insert Gravado com Sucesso.");
		System.exit(0);
	}
}
