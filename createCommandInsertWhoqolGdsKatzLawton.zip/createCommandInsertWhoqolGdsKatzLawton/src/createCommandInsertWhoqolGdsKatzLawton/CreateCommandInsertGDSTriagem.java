package createCommandInsertWhoqolGdsKatzLawton;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CreateCommandInsertGDSTriagem {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreateCommandInsertGDSTriagem gerarInsertWhoqol = new CreateCommandInsertGDSTriagem();
		try {
			gerarInsertWhoqol.lerNomeRespWhoqolTxt();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void lerNomeRespWhoqolTxt() throws IOException {
		String lerNomeRespTxt = null;
		Scanner scanner = null;
		String filePath = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/KeyWords/KeyWords_Resp_GDS.txt";
		//String filePath = "C:\\gerar_comandos_sql\\KeyWords_Resp_Whoqol.txt";
		//File pathAtual = new File(filePath);
		//InputStream isPath = new FileInputStream(pathAtual);
		//BufferedReader bfrPath = new BufferedReader(new );
		BufferedInputStream file = new BufferedInputStream(new FileInputStream(filePath));
		/* Vou Scannear o arquivo que está armazenado no Buffer */
		scanner = new Scanner(file);
		int qtdLinhas = 0;
		int id_1 = 187;
		//int id_2 = 0;
		File arq_insercao = new File("/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/scriptsBD/gerar_comandos_sql/INSERT_COMMAND_TABLE_AVALIACAO_QUESTAO_GDS_TRIAGEM_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		//File arq_insercao = new File("C:\\gerar_comandos_sql\\INSERT_COMMAND_TABLE_AVALIACAO_QUESTAO_WHOQOL_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		arq_insercao.createNewFile();
		System.out.println("Arquivo do comando SQL-DDL Insert GDS Criado com Sucesso.");
		FileWriter flw = new FileWriter(arq_insercao);
		String[] paciente = null;
		/* Enquanto tiver registro no arquivo a ser lido, o retorno é true */
		while ( scanner.hasNext() ) {
			qtdLinhas++;
			lerNomeRespTxt = scanner.nextLine();
			paciente = lerNomeRespTxt.split("\t");
			System.out.println("Paciente: " + paciente[0]);
			System.out.println("lerNomeRespTxt: " + lerNomeRespTxt);
			if ( paciente[0].equals("paciente") ) {
				System.out.println("Paciente: " + paciente[1]);
				qtdLinhas--;
				continue;
			}
			/* AV1 */
			if ( qtdLinhas <= 15 ) {
				gerarCommandInsertWhoqol(flw, id_1, qtdLinhas, lerNomeRespTxt);
			} else if ( qtdLinhas <= 30 ) {
				continue;
				/* Quando mudar de uma avaliação para outro, reinicia(com valor 1) a contagem */
				/* AV2 */
				/* Antes de inserir a primeira linha no arquivo quebra a linha duas vezes na Transição Av1 - Av2*/
				//if ( qtdLinhas == 16 ) {
					//flw.write("\n\n");
				//}
				//id_2 = id_1 + 1;
				//gerarCommandInsertWhoqol(flw, id_2, (qtdLinhas - 15), lerNomeRespTxt);
			} else if ( qtdLinhas < 45 ) {
				/* AV3 */
				continue;
				/* Antes de inserir a primeira linha no arquivo quebra a linha duas vezes na Transição Av2 - Av3 */
				//if ( qtdLinhas == 31 ) {
					//flw.write("\n\n");
				//}
				//id_2 = id_1 + 3; // ou id_3 = id_2 + 2;
				//gerarCommandInsertWhoqol(flw, id_2, (qtdLinhas - 30), lerNomeRespTxt);
			}
			/* Quando mudar de um paciente para outro, reinicia(zerando) a contagem */
			if ( qtdLinhas == 45 ) {
				qtdLinhas = 0;
				id_1++; //id_1 = id_2 + 3; // ou id_1 = id_3 + 3
				flw.write("\n\n\n");
			}

		}
		
		fecharArq(flw);
	}

	public void gerarCommandInsertWhoqol(FileWriter flw, int id, int index, String lerNomeRespTxt) {
		// TODO Auto-generated method stub
		/* Criar novo arquivo de Inserção */
		try {

			//if ( index == 27 ) {
			if ( index == 16 ) {
				flw.write("\n");
			} else if ( index == 31 ) {
				flw.write("\n");
			}
			
			//flw.write("INSERT INTO avaliacao_questao_whoqol (id_avaliacao, id_questao_whoqol, resposta_questao_whoqol) values ("+ id + "," + index + "," + '\'' + lerNomeRespTxt + '\'' + ");" + "\n");
			flw.write("INSERT INTO avaliacao_questao_gds (id_avaliacao, id_questao_gds, resposta_questao_gds) values ("+ id + "," + index + "," + '\'' + lerNomeRespTxt + '\'' + ");" + "\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void fecharArq(FileWriter flw) throws IOException {
		flw.close();
		System.out.println("Arquivo do comando SQL-DDL Insert Gravado com Sucesso.");
		System.exit(0);
	}
}
