package createCommandInsertWhoqolGdsKatzLawton;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CreateCommandInsertQiTriagem {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreateCommandInsertQiTriagem gerarInsertQi = new CreateCommandInsertQiTriagem();
		try {
			gerarInsertQi.lerNomeRespQiTxt();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void lerNomeRespQiTxt() throws IOException {
		String lerNomeRespTxt = null;
		Scanner scanner = null;
		String filePath = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/KeyWords/KeyWords_Resp_QI.txt";
		BufferedInputStream file = new BufferedInputStream(new FileInputStream(filePath));
		/* Vou Scannear o arquivo que está armazenado no Buffer */
		scanner = new Scanner(file);
		int qtdLinhas = 0;
		int id_1 = 187;
		File arq_insercao = new File("/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/scriptsBD/gerar_comandos_sql/INSERT_COMMAND_TABLE_AVALIACAO_QUESTAO_QI_TRIAGEM_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		//File arq_insercao = new File("C:\\gerar_comandos_sql\\INSERT_COMMAND_TABLE_AVALIACAO_QUESTAO_WHOQOL_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		arq_insercao.createNewFile();
		System.out.println("Arquivo do comando SQL-DDL Insert QI TRIAGEM Criado com Sucesso.");
		FileWriter flw = new FileWriter(arq_insercao);
		String[] paciente = null;
		String item[] = null;
		/* Enquanto tiver registro no arquivo a ser lido, o retorno é true */
		while ( scanner.hasNext() ) {
			qtdLinhas++;
			lerNomeRespTxt = scanner.nextLine();
			paciente = lerNomeRespTxt.split("\t");
			System.out.println("Paciente: " + paciente[0]);
			System.out.println("lerNomeRespTxt: " + lerNomeRespTxt);
			if ( paciente[0].equals("paciente") ) {
				System.out.println("Paciente: " + paciente[1]);
				qtdLinhas--;
				continue;
			}
			/* AV1 */
			if ( qtdLinhas >= 29 ) {
				item = lerNomeRespTxt.split("\t");
				System.out.println("Itens_AV1_Matricial: " + item[0] + "\n" + item[1] + "\n" + item[2]);
				gerarCommandInsertQi(flw, id_1, qtdLinhas, (!"null".equals(item[0]) ? new Integer(item[0]) : null), (!"null".equals(item[1]) ? '\'' + item[1] + '\'' : null), (!"null".equals(item[2]) ? new Integer(item[2]) : null));
				//gerarCommandInsertQi(flw, id_1, qtdLinhas, (!"null".equals(item[0]) ? '\'' + item[0] + '\'' : '\'' + "Falta Resposta" + '\''), (!"null".equals(item[1]) ? '\'' + item[1] + '\'' : '\'' + "Falta Resposta" + '\''), (!"null".equals(item[2]) ? '\'' + item[2] + '\'' : '\'' + "Falta Resposta" + '\''));
			} else {
				item = lerNomeRespTxt.split("\t");
				System.out.println("Itens_AV1_Informacao: " + item[0] + "\n" + item[1]);
				gerarCommandInsertQi(flw, id_1, qtdLinhas, null, '\'' + item[0] + '\'', new Integer(item[1]));
			}
				
			//}
			/* Quando mudar de um paciente para outro, reinicia(zerando) a contagem */
			if ( qtdLinhas == 57 ) {
				qtdLinhas = 0;
				id_1++; //id_1 += 6;
				//id_1 = id_2 + 3; // ou id_1 = id_3 + 3
				flw.write("\n\n\n");
			}

		}
		
		fecharArq(flw);
	}

	//public void gerarCommandInsertCamcog(FileWriter flw, int id, int index, String lerNomeRespTxt) {
	public void gerarCommandInsertQi(FileWriter flw, int id, int index, Integer resposta_gabarito_rac_matricial, String resposta_questao_qi, Integer pontuacao_subtotal) {	
		// TODO Auto-generated method stub
		/* Criar novo arquivo de Inserção */
		try {

			//if ( index == 27 ) {
			/* Quebradentro de cada Exame, pois tem exames que possuem subseções, como o caso do Whoqol e Camcoq(1 - Rec; 2 - Praxia) */
			if ( index == 29 ) {
				flw.write("\n");
			} /*else if ( index == 31 ) {
				flw.write("\n");
			}*/
			
			flw.write("INSERT INTO avaliacao_questao_qi (id_avaliacao, id_questao_qi, resposta_gabarito_rac_matricial, resposta_questao_qi, pontuacao_subtotal) values ("+ id + "," + index + "," + resposta_gabarito_rac_matricial + "," + resposta_questao_qi + "," + pontuacao_subtotal + ");" + "\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void fecharArq(FileWriter flw) throws IOException {
		flw.close();
		System.out.println("Arquivo do comando SQL-DDL Insert Gravado com Sucesso.");
		System.exit(0);
	}
}
