package createcommandinsert;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Util {
	public static String getSystemDateAndTime() {
		/* Definir o modelo de formatação de Data e Hora */
		/* DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"); */
		DateFormat df = new SimpleDateFormat("yyyyMMdd_HH_mm_ss");
		/* Pegar a Data e hora do Sistema, necessário para o Backup. */ 
		Date date = new Date();
		/* Retorno a Daya e Hora formatados(Format) pelo modelo definido.*/
		return df.format(date);
	}
}
