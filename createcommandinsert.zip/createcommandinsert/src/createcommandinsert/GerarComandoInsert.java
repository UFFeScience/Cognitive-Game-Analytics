package createcommandinsert;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GerarComandoInsert {
	//private StringBuilder comandoInsert = new StringBuilder();
	private List<String> listaComandosInserts = new ArrayList<String>();
	public List<String> createComandoInsert(String dado) {
		StringBuilder comandoInsert = new StringBuilder();
		comandoInsert.append("insert into avaliacao_paciente (trail_a,trail_a_segundo,hits,cr,trail_b,trail_b_segundo,fluencia,gds_pontuacao_total,katz_pontuacao_total,lawton_pontuacao_total,tiadl_pontuacao_total,dafs_pontuacao_total,camcog_recordacao_pontuacao_total,camcog_praxia_pontuacao_total,whoqol_abrev_pontuacao_total,whoqol_old_pontuacao_total,tug_pontuacao_total,droga_substancia_total,medicamento_substancia_total,mini_mental_pontuacao_total,qi_pontuacao_total,cogstate_pontuacao_total,percentual_trail_a,percentual_hits,percentual_cr,percentual_trail_b,percentual_fluencia,percentual_gds,percentual_katz,percentual_lawton,percentual_tiadl,percentual_dafs,percentual_camcog_recordacao,percentual_camcog_praxia,percentual_whoqol_abrev,percentual_whoqol_old,percentual_tug,percentual_cogstate,id_tipo_avaliacao)")
		.append(" values (" + dado + ");").append("\n");
		System.out.println("comandoInsert: " + comandoInsert.toString());
		listaComandosInserts.add(comandoInsert.toString());
		return listaComandosInserts;
	}
	
	public void escreverEmArquivoTxt(List<String> listaComandosInserts) {
		File arq_insercao = new File("/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/scriptsBD/gerar_comandos_sql/INSERT_COMMAND_TABLE_AVALIACAO_PACIENTE_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		//File arq_insercao = new File("/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/scriptsBD/gerar_comandos_sql/INSERT_COMMAND_TABLE_AVALIACAO_PACIENTE_DMLSQL.sql");
		//File arq_insercao = new File("C:\\gerar_comandos_sql\\INSERT_COMMAND_TABLE_AVALIACAO_PACIENTE_DMLSQL_" + Util.getSystemDateAndTime() + ".sql");
		try {
			/* Criar novo arquivo de Inserção */
			arq_insercao.createNewFile();
			System.out.println("Arquivo do comando SQL-DDL Insert Criado com Sucesso.");
			/* Salvar o arquivo de Inserção */
			FileWriter flw = new FileWriter(arq_insercao);
			for (String comandoDeInsercao : listaComandosInserts) {
				flw.write(comandoDeInsercao + "\n");
			}
			flw.close();
			//listaComandosInserts = null;
			System.out.println("Arquivo do comando SQL-DDL Insert Gravado com Sucesso.");
			//return listaComandosInserts;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
		
	}
}
