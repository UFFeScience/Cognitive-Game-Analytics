package createcommandinsert;

import static javax.swing.GroupLayout.Alignment.BASELINE;
import static javax.swing.GroupLayout.Alignment.LEADING;
import static javax.swing.GroupLayout.Alignment.TRAILING;

import java.awt.EventQueue;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;

public class JTabbed extends JFrame implements ActionListener {
	// Declaração de variáveis
	private static int contObjTela = 0;
	private JTabbedPane jTabbedPaneContainer;
	private JPanel jpanel01;
	private JPanel jpanel02;
	private JPanel jpanel03;
	private JPanel jpanel04;
	private JPanel jpanel05;
	private JLabel trail_a_label;
	private JLabel trail_a_segundo_label;
	private JLabel hits_label;
	private JLabel cr_label;
	private JLabel trail_b_label;
	private JLabel trail_b_segundo_label;
	private JLabel fluencia_label;
	private JLabel gds_pontuacao_total_label;
	private JLabel katz_pontuacao_total_label;
	private JLabel lawton_pontuacao_total_label;
	private JLabel tiadl_pontuacao_total_label;
	private JLabel dafs_pontuacao_total_label;
	private JLabel cogstate_pontuacao_total_label;
	private JLabel camcog_recordacao_pontuacao_total_label;
	private JLabel camcog_praxia_pontuacao_total_label;
	private JLabel whoqol_abrev_pontuacao_total_label;
	private JLabel whoqol_old_pontuacao_total_label;
	private JLabel tug_pontuacao_total_label;
	private JLabel droga_substancia_total_label;
	private JLabel medicamento_substancia_total_label;
	private JLabel mini_mental_pontuacao_total_label;
	private JLabel qi_pontuacao_total_label;
	private JLabel trail_a_percentual_label;
	private JLabel trail_b_percentual_label;
	private JLabel hits_percentual_label;
	private JLabel cr_percentual_label;
	private JLabel fluencia_percentual_label;
	private JLabel gds_percentual_label;
	private JLabel katz_percentual_label;
	private JLabel lawton_percentual_label;
	private JLabel tiadl_percentual_label;
	private JLabel dafs_percentual_label;
	private JLabel cogstate_percentual_label;
	private JLabel camcog_recordacao_percentual_label;
	private JLabel camcog_praxia_percentual_label;
	private JLabel whoqol_abrev_percentual_label;
	private JLabel whoqol_old_percentual_label;
	private JLabel tug_percentual_label;
	private JLabel id_tipo_avaliacao_label;
	private JTextField trail_a;
	private JTextField trail_a_segundo;
	private JTextField hits;
	private JTextField cr;
	private JTextField trail_b;
	private JTextField trail_b_segundo;
	private JTextField fluencia;
	private JTextField gds_pontuacao_total;
	private JTextField katz_pontuacao_total;
	private JTextField lawton_pontuacao_total;
	private JTextField tiadl_pontuacao_total;
	private JTextField dafs_pontuacao_total;
	private JTextField cogstate_pontuacao_total;
	private JTextField camcog_recordacao_pontuacao_total;
	private JTextField camcog_praxia_pontuacao_total;
	private JTextField whoqol_abrev_pontuacao_total;
	private JTextField whoqol_old_pontuacao_total;
	private JTextField tug_pontuacao_total;
	private JTextField droga_substancia_total;
	private JTextField medicamento_substancia_total;
	private JTextField mini_mental_pontuacao_total;
	private JTextField qi_pontuacao_total;
	private JTextField trail_a_percentual;
	private JTextField trail_b_percentual;
	private JTextField hits_percentual;
	private JTextField cr_percentual;
	private JTextField fluencia_percentual;
	private JTextField gds_percentual;
	private JTextField katz_percentual;
	private JTextField lawton_percentual;
	private JTextField tiadl_percentual;
	private JTextField dafs_percentual;
	private JTextField cogstate_percentual;
	private JTextField camcog_recordacao_percentual;
	private JTextField camcog_praxia_percentual;
	private JTextField whoqol_abrev_percentual;
	private JTextField whoqol_old_percentual;
	private JTextField tug_percentual;
	private JTextField id_tipo_avaliacao;
	private JTextField[] arrTextField;
	private List<JTextField> listaComponentesTextField;
	private JButton jButtonInserirNaLista;
	private JButton jButtonCancelarOperacao;
	private JButton jButtonGerarArquivo;
    private JButton jButtonAnterior;
    private JButton jButtonProximo;
	private GroupLayout groupExame01Layout;
	private GroupLayout groupExame02Layout;
	private GroupLayout groupExame03Layout;
	private GroupLayout groupExame04Layout;
	private GroupLayout groupExame05Layout;
	private GroupLayout groupButtonLayout;
	
    /* Início Classe Inserir */
	private List<String> listaComandosInserts;
	private GerarComandoInsert gerarInsert = new GerarComandoInsert();
	private static final int AV1 = 1;
	private static final int AV2 = 2;
	private static final int AV1_AV2 = 3;
	private static final int AV3 = 4;
	private static final int AV2_AV3 = 5;
	private static final int AV1_AV3 = 6;
	// E para o Evento TAB e para os evntos Prox e Ant também! Vou acabar com isso com a sepração pela criação das classes. Só vou deixar o evento TAB para críticar possíveis inserções erradas em cada campo.
	private StringBuilder construtor;
	private static final String[] ARR = {"AV1","AV2","AV1_AV2","AV3","AV2_AV3","AV1_AV3"};
	private int index;
	/* Final Classe Inserir */

    /* Evento TAB */
    private JTextField tpTextField;
	private int temDoisPontos;
	private String[] v_av1;
	private String[] v_av2;
	private String[] v_av3;
	private int index_av1;
	private int index_av2;
	private int index_av3;
	/* Fim Evento TAB */
	
	/* Evento dos botões prox e Anterior */
	private Integer[] sub_exames_cognitivos;
	private Integer[] perc_exames_cognitivos;
	private Integer divZero;
	/* Fim Evento dos botões prox e Anterior */

      public JTabbed() {
    	  super("Inclusão dos novos campos da Entidade Avaliacao_Paciente");
          initComponents();
      }
   
      private void initComponents() {
    	  ++contObjTela;
    	  System.out.println(contObjTela);

    	  v_av1 = new String[17];
    	  v_av2 = new String[17];
    	  v_av3 = new String[17];
    	  
    	  arrTextField = new JTextField[33];
    	  
          jTabbedPaneContainer = new JTabbedPane();
          
          construcaoDosComponentes();
          
          jTabbedPaneContainer.addTab("Grupo Exame 01", jpanel01);
          jTabbedPaneContainer.addTab("Grupo Exame 02", jpanel02);
          jTabbedPaneContainer.addTab("Grupo Exame 03", jpanel03);
          jTabbedPaneContainer.addTab("Grupo Exame 04", jpanel04);
          jTabbedPaneContainer.addTab("Grupo Exame 05", jpanel05);
          
          /* Adiciono as Abas no Frame */
          add(jTabbedPaneContainer);
         
      }
      
      public void construcaoDosComponentes() {
    	  construtor = new StringBuilder();
    	  
          /* Construção dos Labels */	
          //JPanel jpaneLabel = construirLabels(jpanel); 
    	  construirLabelsGrupoAbasExames01();
    	  construirLabelsGrupoAbasExames02();
    	  construirLabelsGrupoAbasExames03();
    	  construirLabelsGrupoAbasExames04();
    	  construirLabelsGrupoAbasExames05();
          /* Construção dos campos TextField */
          //JPanel jpanelTextField = construirTextField(jpaneLabel);
    	  construirTextFieldGrupoAbasExames01();
    	  construirTextFieldGrupoAbasExames02();
    	  construirTextFieldGrupoAbasExames03();
    	  construirTextFieldGrupoAbasExames04();
    	  construirTextFieldGrupoAbasExames05();
    	  
          /* Evento acionado pelo Teclado */
          construirEvtTeclado();
          /* Evento acionado pelo Botão */
          construirEvtBotao();
          /* 
           * Construir estrutura de alinhamento dos Labels e TextField 
           */
          groupExame01Layout = new GroupLayout(jpanel01);
    	  groupExame01Layout.setAutoCreateGaps(true);
    	  groupExame01Layout.setAutoCreateContainerGaps(true);
          jpanel01.setLayout(groupExame01Layout);
          
          groupExame02Layout = new GroupLayout(jpanel02);
          groupExame02Layout.setAutoCreateGaps(true);
          groupExame02Layout.setAutoCreateContainerGaps(true);
          jpanel02.setLayout(groupExame02Layout);
          
          groupExame03Layout = new GroupLayout(jpanel03);
    	  groupExame03Layout.setAutoCreateGaps(true);
    	  groupExame03Layout.setAutoCreateContainerGaps(true);
          jpanel03.setLayout(groupExame03Layout);
          
          groupExame04Layout = new GroupLayout(jpanel04);
          groupExame04Layout.setAutoCreateGaps(true);
          groupExame04Layout.setAutoCreateContainerGaps(true);
          jpanel04.setLayout(groupExame04Layout);
          
          groupExame05Layout = new GroupLayout(jpanel05);
          groupExame05Layout.setAutoCreateGaps(true);
          groupExame05Layout.setAutoCreateContainerGaps(true);
          jpanel05.setLayout(groupExame05Layout);
          
          groupButtonLayout = new GroupLayout(getContentPane());
          groupButtonLayout.setAutoCreateGaps(true);
          groupButtonLayout.setAutoCreateContainerGaps(true);
          getContentPane().setLayout(groupButtonLayout);
          
          
          /* Construir Estrutura Horizontal */
    	  construirGroupLayoutHoriz();
    	  /* Construir Estrutura Vertical */
    	  construirGroupLayoutVert();
    	  
      }
      
      public void construirEvtBotao() {
    	  jButtonProximo = new JButton();
          jButtonAnterior = new JButton();
    	  jButtonProximo.setText("Proximo");
      	  jButtonProximo.addActionListener(new ActionListener() {
              @Override
		  public void actionPerformed(java.awt.event.ActionEvent evt) {
                  jButtonProximoActionPerformed(evt);
              }
          });
   
          jButtonAnterior.setText("Anterior");
          jButtonAnterior.addActionListener(new ActionListener() {
              @Override
			public void actionPerformed(java.awt.event.ActionEvent evt) {
                  jButtonAnteriorActionPerformed(evt);
              }
          });
		  jButtonInserirNaLista = new JButton("Inserir"); 
	      /* Adicionar o Evento */
		  jButtonInserirNaLista.addActionListener(this);
	      
	      jButtonGerarArquivo = new JButton("Gerar Arquivo");
	      /* Adiciona o Evento para o botao */
	      jButtonGerarArquivo.addActionListener(this);
	      
	      jButtonCancelarOperacao = new JButton("Cancelar");
	      /* Adiciona o Evento para o botao */
	      jButtonCancelarOperacao.addActionListener(this);
	}
      
      public void construirGroupLayoutHoriz() {
          groupExame01Layout.setHorizontalGroup
	      (
	    	groupExame01Layout.createSequentialGroup()
	  	        .addGroup(
	  	        	/* Alinhar o bloco à esq com n linhas(JLabel) b1 - b3 (Leading); b2 - b4(Trailing) */
	  	            groupExame01Layout.createParallelGroup(LEADING)
		  	            .addComponent(trail_a_label)
	  	                .addComponent(trail_a_segundo_label)
	  	                .addComponent(hits_label)
	  	                .addComponent(cr_label)
	  	                .addComponent(trail_b_label)
	  	                .addComponent(trail_b_segundo_label)
	  	                .addComponent(fluencia_label)
	  	                .addComponent(gds_pontuacao_total_label)
	  	                .addComponent(katz_pontuacao_total_label)
	  	                .addComponent(lawton_pontuacao_total_label)
	  	            )
	  	      .addGroup(
		  	        	/* Alinhar o bloco à direita com n linhas(JTextField) */
	  	    		groupExame01Layout.createParallelGroup(TRAILING)
	  	    			.addComponent(trail_a)
	  	                .addComponent(trail_a_segundo)
	  	                .addComponent(hits)
	  	                .addComponent(cr)
			  	      	.addComponent(trail_b)
			  	      	.addComponent(trail_b_segundo)
			  	      	.addComponent(fluencia)
			  	      	.addComponent(gds_pontuacao_total)
			  	      	.addComponent(katz_pontuacao_total)
			  	      	.addComponent(lawton_pontuacao_total)
	          
		  	        )
	  	     ); 
            
          
          groupExame02Layout.setHorizontalGroup
	      (
	    	groupExame02Layout.createSequentialGroup()
	  	        .addGroup(
	  	        	/* Alinhar o bloco à esq com n linhas(JLabel) b1 - b3 (Leading); b2 - b4(Trailing) */
	  	        	groupExame02Layout.createParallelGroup(LEADING)
	  	        		.addComponent(tiadl_pontuacao_total_label)
	  	                .addComponent(dafs_pontuacao_total_label)
	  	                .addComponent(camcog_recordacao_pontuacao_total_label)
	  	                .addComponent(camcog_praxia_pontuacao_total_label)
	  	                .addComponent(whoqol_abrev_pontuacao_total_label)
	  	                .addComponent(whoqol_old_pontuacao_total_label)
	  	                .addComponent(tug_pontuacao_total_label)
	  	                
	  	            )
	  	      .addGroup(
		  	        	/* Alinhar o bloco à direita com n linhas(JTextField) */
	  	    		groupExame02Layout.createParallelGroup(TRAILING)
	  	    			.addComponent(tiadl_pontuacao_total)
			  	      	.addComponent(dafs_pontuacao_total)
			  	      	.addComponent(camcog_recordacao_pontuacao_total)
			  	      	.addComponent(camcog_praxia_pontuacao_total)
			  	      	.addComponent(whoqol_abrev_pontuacao_total)
			  	      	.addComponent(whoqol_old_pontuacao_total)
			  	      	.addComponent(tug_pontuacao_total)
			  	      	
	          
		  	        )
	  	     ); 
          
          groupExame03Layout.setHorizontalGroup
	      (
	    	groupExame03Layout.createSequentialGroup()
	  	        .addGroup(
	  	        	/* Alinhar o bloco à esq com n linhas(JLabel) b1 - b3 (Leading); b2 - b4(Trailing) */
	  	            groupExame03Layout.createParallelGroup(LEADING)
	  	            	.addComponent(droga_substancia_total_label)
	  	            	.addComponent(medicamento_substancia_total_label)
	  	            	.addComponent(mini_mental_pontuacao_total_label)
	  	            	.addComponent(qi_pontuacao_total_label)
	  	                
	  	            )
	  	      .addGroup(
		  	        	/* Alinhar o bloco à direita com n linhas(JTextField) */
	  	    		groupExame03Layout.createParallelGroup(TRAILING)
		  	    		.addComponent(droga_substancia_total)
			  	      	.addComponent(medicamento_substancia_total)
			  	      	.addComponent(mini_mental_pontuacao_total)	
		  	    		.addComponent(qi_pontuacao_total)
			  	        
	          
		  	        )
	  	     ); 
            
          
          groupExame04Layout.setHorizontalGroup
	      (
	    	groupExame04Layout.createSequentialGroup()
	  	        .addGroup(
	  	        	/* Alinhar o bloco à esq com n linhas(JLabel) b1 - b3 (Leading); b2 - b4(Trailing) */
	  	            groupExame04Layout.createParallelGroup(LEADING)
	  	                .addComponent(cogstate_pontuacao_total_label)
	  	                .addComponent(trail_a_percentual_label)
	  	                .addComponent(hits_percentual_label)
	  	                .addComponent(cr_percentual_label)
	  	                .addComponent(trail_b_percentual_label)
	  	                .addComponent(fluencia_percentual_label)
	  	                .addComponent(gds_percentual_label)
	  	                .addComponent(katz_percentual_label)
	  	                .addComponent(lawton_percentual_label)
	  	            )
	  	      .addGroup(
		  	        	/* Alinhar o bloco à direita com n linhas(JTextField) */
	  	    		groupExame04Layout.createParallelGroup(TRAILING)
			  	        .addComponent(cogstate_pontuacao_total)
			  	      	.addComponent(trail_a_percentual)
			  	      	.addComponent(hits_percentual)
			  	      	.addComponent(cr_percentual)
			  	        .addComponent(trail_b_percentual)
			  	      	.addComponent(fluencia_percentual)
			  	      	.addComponent(gds_percentual)
			  	      	.addComponent(katz_percentual)
			  	      	.addComponent(lawton_percentual)
	          
		  	        )
	  	     ); 
          
          groupExame05Layout.setHorizontalGroup
	      (
	    	groupExame05Layout.createSequentialGroup()
	  	        .addGroup(
	  	        	/* Alinhar o bloco à esq com n linhas(JLabel) b1 - b3 (Leading); b2 - b4(Trailing) */
	  	        	groupExame05Layout.createParallelGroup(LEADING)
	  	        		.addComponent(tiadl_percentual_label)
	  	                .addComponent(dafs_percentual_label)
	  	                .addComponent(camcog_recordacao_percentual_label)
	  	                .addComponent(camcog_praxia_percentual_label)
	  	                .addComponent(whoqol_abrev_percentual_label)
	  	                .addComponent(whoqol_old_percentual_label)
	  	                .addComponent(tug_percentual_label)
	  	                .addComponent(cogstate_percentual_label)
	  	                .addComponent(id_tipo_avaliacao_label)
	  	            )
	  	      .addGroup(
		  	        	/* Alinhar o bloco à direita com n linhas(JTextField) */
	  	    		groupExame05Layout.createParallelGroup(TRAILING)
	  	    			.addComponent(tiadl_percentual)
			  	      	.addComponent(dafs_percentual)
			  	      	.addComponent(camcog_recordacao_percentual)
			  	      	.addComponent(camcog_praxia_percentual)
			  	      	.addComponent(whoqol_abrev_percentual)
			  	      	.addComponent(whoqol_old_percentual)
			  	      	.addComponent(tug_percentual)
			  	        .addComponent(cogstate_percentual)
			  	      	.addComponent(id_tipo_avaliacao)
	          
		  	        )
	  	     ); 
          
          
          groupButtonLayout.setHorizontalGroup
	      (

	    		  groupButtonLayout.createParallelGroup(LEADING)
	              .addComponent(jTabbedPaneContainer)
	              .addGroup(groupButtonLayout.createSequentialGroup()
	                   .addComponent(jButtonProximo)
	                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                   .addComponent(jButtonAnterior)
	                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                   .addComponent(jButtonInserirNaLista)
	                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                   .addComponent(jButtonGerarArquivo)
	                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                   .addComponent(jButtonCancelarOperacao)
	               )
	            
	  	     ); 
  	}
  	
  	public void construirGroupLayoutVert() {
  		groupExame01Layout.setVerticalGroup
	      (
	      		
	    		groupExame01Layout.createSequentialGroup()
	    		// Adicionar o grupo dos novos componentes - Baseline(Linha de Base -> Horizontal - Leitura da Esq para Dir) 
	    	 
	    		.addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame01Layout.createParallelGroup(BASELINE)
	    			.addComponent(trail_a_label)
  	                .addComponent(trail_a)
	  	        )
	  	        .addGroup(
	  	        	groupExame01Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(trail_a_segundo_label)
  	                .addComponent(trail_a_segundo)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame01Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(hits_label)
  	                .addComponent(hits)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame01Layout.createParallelGroup(BASELINE)
	    			.addComponent(cr_label)
  	                .addComponent(cr)
	  	        )
	  	        .addGroup(
	  	        	groupExame01Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(trail_b_label)
  	                .addComponent(trail_b)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame01Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(trail_b_segundo_label)
  	                .addComponent(trail_b_segundo)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame01Layout.createParallelGroup(BASELINE)
	    			.addComponent(fluencia_label)
  	                .addComponent(fluencia)
	  	        )
	  	        .addGroup(
	  	        	groupExame01Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(gds_pontuacao_total_label)
  	                .addComponent(gds_pontuacao_total)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame01Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(katz_pontuacao_total_label)
  	                .addComponent(katz_pontuacao_total)
		  	    )
	  	      .addGroup(
		  	        	groupExame01Layout.createParallelGroup(BASELINE)
		  	        	.addComponent(lawton_pontuacao_total_label)
	  	                .addComponent(lawton_pontuacao_total)
			  	 )
	  	        
	       );
  		
  		groupExame02Layout.setVerticalGroup
	      (
	      		
	    	 groupExame02Layout.createSequentialGroup()
	    		// Adicionar o grupo dos novos componentes - Baseline(Linha de Base -> Horizontal - Leitura da Esq para Dir) 
	    	 
	    		.addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame02Layout.createParallelGroup(BASELINE)
	    			.addComponent(tiadl_pontuacao_total_label)
  	                .addComponent(tiadl_pontuacao_total)
	  	        )
	  	        .addGroup(
	  	        	groupExame02Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(dafs_pontuacao_total_label)
  	                .addComponent(dafs_pontuacao_total)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame02Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(camcog_recordacao_pontuacao_total_label)
  	                .addComponent(camcog_recordacao_pontuacao_total)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame02Layout.createParallelGroup(BASELINE)
	    			.addComponent(camcog_praxia_pontuacao_total_label)
  	                .addComponent(camcog_praxia_pontuacao_total)
	  	        )
	  	        .addGroup(
	  	        	groupExame02Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(whoqol_abrev_pontuacao_total_label)
  	                .addComponent(whoqol_abrev_pontuacao_total)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame02Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(whoqol_old_pontuacao_total_label)
  	                .addComponent(whoqol_old_pontuacao_total)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame02Layout.createParallelGroup(BASELINE)
	    			.addComponent(tug_pontuacao_total_label)
  	                .addComponent(tug_pontuacao_total)
	  	        )
	  	        

	       );
  		
  		groupExame03Layout.setVerticalGroup
	      (
	      		
	    		groupExame03Layout.createSequentialGroup()
	    		// Adicionar o grupo dos novos componentes - Baseline(Linha de Base -> Horizontal - Leitura da Esq para Dir) 
	    		.addGroup(
		  	        	groupExame03Layout.createParallelGroup(BASELINE)
		  	        	.addComponent(droga_substancia_total_label)
	  	                .addComponent(droga_substancia_total)
		  	    )
		  	        
	  	        .addGroup(
	  	        	groupExame03Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(medicamento_substancia_total_label)
  	                .addComponent(medicamento_substancia_total)
		  	    )
		  	    .addGroup(
		  	        	groupExame03Layout.createParallelGroup(BASELINE)
		  	        	.addComponent(mini_mental_pontuacao_total_label)
	  	                .addComponent(mini_mental_pontuacao_total)
			  	)
	    		.addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame03Layout.createParallelGroup(BASELINE)
	    			.addComponent(qi_pontuacao_total_label)
  	                .addComponent(qi_pontuacao_total)
	  	        )
	  	        
	       );
		
  		groupExame04Layout.setVerticalGroup
	      (
	      		
	    		
	    		groupExame04Layout.createSequentialGroup()
	    		// Adicionar o grupo dos novos componentes - Baseline(Linha de Base -> Horizontal - Leitura da Esq para Dir) 
	    	 

	  	        .addGroup(
	  	        	groupExame04Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(cogstate_pontuacao_total_label)
	        		.addComponent(cogstate_pontuacao_total)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame04Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(trail_a_percentual_label)
	                .addComponent(trail_a_percentual)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame04Layout.createParallelGroup(BASELINE)
	    			.addComponent(hits_percentual_label)
	                .addComponent(hits_percentual)
	  	        )
	  	        .addGroup(
	  	        	groupExame04Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(cr_percentual_label)
	                .addComponent(cr_percentual)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame04Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(trail_b_percentual_label)
	                .addComponent(trail_b_percentual)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame04Layout.createParallelGroup(BASELINE)
	    			.addComponent(fluencia_percentual_label)
	                .addComponent(fluencia_percentual)
	  	        )
	  	        .addGroup(
	  	        	groupExame04Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(gds_percentual_label)
	                .addComponent(gds_percentual)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame04Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(katz_percentual_label)
	                .addComponent(katz_percentual)
		  	    )
	  	      .addGroup(
		  	        	groupExame04Layout.createParallelGroup(BASELINE)
		  	        	.addComponent(lawton_percentual_label)
	  	                .addComponent(lawton_percentual)
			  	)
	  	        
	       );
		
		groupExame05Layout.setVerticalGroup
	      (
	      		
	    		groupExame05Layout.createSequentialGroup()
	    		// Adicionar o grupo dos novos componentes - Baseline(Linha de Base -> Horizontal - Leitura da Esq para Dir) 
	    	 
	    		.addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	    			groupExame05Layout.createParallelGroup(BASELINE)
	    			.addComponent(tiadl_percentual_label)
	                .addComponent(tiadl_percentual)
	  	        )
	  	        .addGroup(
	  	        	groupExame05Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(dafs_percentual_label)
	                .addComponent(dafs_percentual)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame05Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(camcog_recordacao_percentual_label)
	                .addComponent(camcog_recordacao_percentual)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	  	    		groupExame05Layout.createParallelGroup(BASELINE)
	    			.addComponent(camcog_praxia_percentual_label)
	                .addComponent(camcog_praxia_percentual)
	  	        )
	  	        .addGroup(
	  	        	groupExame05Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(whoqol_abrev_percentual_label)
	                .addComponent(whoqol_abrev_percentual)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame05Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(whoqol_old_percentual_label)
	                .addComponent(whoqol_old_percentual)
		  	    )
	  	      .addGroup(
	  	        		// Alinhar o bloco sequencial na linha de base com n colunas b1 - b2(JLabel - JTextField) (Baseline); b3 - b4(JLabel - JTextField)(Baseline) -> faz um z(o movimento de leitura esq para dir) 
	  	    		groupExame05Layout.createParallelGroup(BASELINE)
	    			.addComponent(tug_percentual_label)
	                .addComponent(tug_percentual)
	  	        )
	  	        .addGroup(
	  	        	groupExame05Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(cogstate_percentual_label)
	        		.addComponent(cogstate_percentual)
	  	        )
	  	        
	  	        .addGroup(
	  	        	groupExame05Layout.createParallelGroup(BASELINE)
	  	        	.addComponent(id_tipo_avaliacao_label)
	        		.addComponent(id_tipo_avaliacao)
		  	    )
	  	        
	       );
		
		groupButtonLayout.setVerticalGroup
	      (
	    		groupButtonLayout.createParallelGroup(LEADING)
	    		.addGroup(groupButtonLayout.createSequentialGroup()
                  .addComponent(jTabbedPaneContainer)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                  .addGroup(groupButtonLayout.createParallelGroup(BASELINE)
                      .addComponent(jButtonProximo)
                      .addComponent(jButtonAnterior)
                      .addComponent(jButtonInserirNaLista)
	  	        	  .addComponent(jButtonGerarArquivo)
	  	        	  .addComponent(jButtonCancelarOperacao)
                  )
              )
	  	      
	       ); 

  	}
  	
  	public void construirEvtTeclado() {
  		lancaEvt(trail_a);
  	    lancaEvt(trail_a_segundo);
  	    lancaEvt(hits);
  	    lancaEvt(cr);
  	    lancaEvt(trail_b);
  	    lancaEvt(trail_b_segundo);
  	    lancaEvt(fluencia);
  	    lancaEvt(gds_pontuacao_total);
  	    lancaEvt(katz_pontuacao_total);
  	    lancaEvt(lawton_pontuacao_total);
  	    lancaEvt(tiadl_pontuacao_total);
  	    lancaEvt(dafs_pontuacao_total);
  	    lancaEvt(camcog_recordacao_pontuacao_total);
  	    lancaEvt(camcog_praxia_pontuacao_total);
  	    lancaEvt(whoqol_abrev_pontuacao_total);
  	    lancaEvt(whoqol_old_pontuacao_total);
  	    lancaEvt(tug_pontuacao_total);
  	    lancaEvt(droga_substancia_total);
  	    lancaEvt(medicamento_substancia_total);
  	    lancaEvt(mini_mental_pontuacao_total);
  	    lancaEvt(qi_pontuacao_total);
  	    lancaEvt(cogstate_pontuacao_total);	
  	    lancaEvt(trail_a_percentual);
  	    lancaEvt(trail_b_percentual);
  	    lancaEvt(hits_percentual);
  	    lancaEvt(cr_percentual);
  	    lancaEvt(fluencia_percentual);
  	    lancaEvt(gds_percentual);
  	    lancaEvt(katz_percentual);
  	    lancaEvt(lawton_percentual);
  	    lancaEvt(tiadl_percentual);
  	    lancaEvt(dafs_percentual);
  	    lancaEvt(camcog_recordacao_percentual);
  	    lancaEvt(camcog_praxia_percentual);
  	    lancaEvt(whoqol_abrev_percentual);
  	    lancaEvt(whoqol_old_percentual);
  	    lancaEvt(tug_percentual);
  	    lancaEvt(cogstate_percentual);
  	    lancaEvt(id_tipo_avaliacao);
  	}
      
   
      public void lancaEvt(JTextField jTextField) {
  		jTextField.addKeyListener(new KeyAdapter() {
  	    	public void keyReleased( KeyEvent evt ) {
  	    		capturarTabKeyRelease(evt);
  	    	}
  	    });
  	}
      
      /* Evento produzido pela tecla TAB */
	  public void capturarTabKeyRelease(KeyEvent evt) {
		  tpTextField = (JTextField) evt.getSource();
		  tpTextField.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, Collections.emptySet());
		  if ( evt.getKeyCode() == KeyEvent.VK_TAB ) {
			  System.out.println("Tipos: " + tpTextField.getName());
			  if ( "trail_a".equals(tpTextField.getName()) || "trail_b".equals(tpTextField.getName())) {
				  System.out.println("Vazio : " + tpTextField.getName());
				  if ( "N".equals(tpTextField.getText().toUpperCase()) ) {
					  tpTextField.setText("null");
					  System.out.println("Med-Drog-N: " + tpTextField.getText());
				  } else {
					  temDoisPontos = (tpTextField.getText()).indexOf(':');
					  System.out.println("temDoisPontos: " + temDoisPontos);
					  if ( temDoisPontos != -1 ) {
						  String porAspasSimplesNaPalavra = "'" + tpTextField.getText() + "'";
						  tpTextField.setText(porAspasSimplesNaPalavra);
						  System.out.println("porAspasSimplesNaPalavra: " + porAspasSimplesNaPalavra);
					  } else {
						  JOptionPane.showMessageDialog(null, "Erro! Você deve inserir no formato HH:MM:SS!",null,JOptionPane.ERROR_MESSAGE);
					  }
				  } 
			  } else if ( "droga_substancia_total".equals(tpTextField.getName()) || "medicamento_substancia_total".equals(tpTextField.getName()) ) {
				  String porAspasSimplesNaPalavra = "'" + tpTextField.getText() + "'";
				  tpTextField.setText(porAspasSimplesNaPalavra);
				  System.out.println("porAspasSimplesNaPalavra: " + porAspasSimplesNaPalavra);
			  } else if ( "id_tipo_avaliacao".equals(tpTextField.getName()) && "N".equals(tpTextField.getText().toUpperCase())) {
				  JOptionPane.showMessageDialog(null, tpTextField.getText().toUpperCase() + " Inválido. O id_tipo_avaliacao deve conter Número. ", "Opção Errada!!!", JOptionPane.WARNING_MESSAGE);	  
			  }	else if ( ("trail_a_percentual".equals(tpTextField.getName()) || "trail_b_percentual".equals(tpTextField.getName()) || "hits_percentual".equals(tpTextField.getName()) || "cr_percentual".equals(tpTextField.getName()) 
					  	|| "fluencia_percentual".equals(tpTextField.getName()) || "gds_percentual".equals(tpTextField.getName()) || "katz_percentual".equals(tpTextField.getName()) || "lawton_percentual".equals(tpTextField.getName()) 
					  	|| "tiadl_percentual".equals(tpTextField.getName()) || "dafs_percentual".equals(tpTextField.getName()) || "camcog_recordacao_percentual".equals(tpTextField.getName()) || "camcog_praxia_percentual".equals(tpTextField.getName()) 
					  	|| "whoqol_abrev_percentual".equals(tpTextField.getName()) || "whoqol_old_percentual".equals(tpTextField.getName()) || "tug_percentual".equals(tpTextField.getName()) || "mini_mental_pontuacao_total".equals(tpTextField.getName()) 
					  	|| "qi_pontuacao_total".equals(tpTextField.getName()) || "whoqol_abrev_pontuacao_total".equals(tpTextField.getName()) || "whoqol_old_pontuacao_total".equals(tpTextField.getName()) || "gds_pontuacao_total".equals(tpTextField.getName())
					  	|| "tug_pontuacao_total".equals(tpTextField.getName()) || "cogstate_percentual".equals(tpTextField.getName()) || "droga_substancia_total".equals(tpTextField.getName()) || "medicamento_substancia_total".equals(tpTextField.getName()) )
					  	&& ( "N".equals(tpTextField.getText().toUpperCase())) ) {
				  tpTextField.setText("null");
				  System.out.println("N: " + tpTextField.getText());
			  }
			  if (!"N".equals(tpTextField.getText().toUpperCase()) && temDoisPontos != -1) {
				  System.out.println("jTextField: " + tpTextField.getText());
				  
				  /* Vetor contendo o valor dos exames que serão utilizados para o Cálculo */
				  if ( (!"trail_a".equals(tpTextField.getName()) /*&& !"trail_b".equals(tpTextField.getName())*/ && !"id_tipo_avaliacao".equals(tpTextField.getName()) 
					 && !"droga_substancia_total".equals(tpTextField.getName()) && !"medicamento_substancia_total".equals(tpTextField.getName()) 
					 && !"mini_mental_pontuacao_total".equals(tpTextField.getName()) && !"qi_pontuacao_total".equals(tpTextField.getName()) 
					 && !"trail_a_percentual".equals(tpTextField.getName()) && !"trail_b_percentual".equals(tpTextField.getName()) && !"hits_percentual".equals(tpTextField.getName()) && !"cr_percentual".equals(tpTextField.getName()) 
					 && !"fluencia_percentual".equals(tpTextField.getName()) && !"gds_percentual".equals(tpTextField.getName()) && !"katz_percentual".equals(tpTextField.getName()) && !"lawton_percentual".equals(tpTextField.getName()) 
					 && !"tiadl_percentual".equals(tpTextField.getName()) && !"dafs_percentual".equals(tpTextField.getName()) && !"camcog_recordacao_percentual".equals(tpTextField.getName()) && !"camcog_praxia_percentual".equals(tpTextField.getName()) 
					 && !"whoqol_abrev_percentual".equals(tpTextField.getName()) && !"whoqol_old_percentual".equals(tpTextField.getName()) && !"tug_percentual".equals(tpTextField.getName()) && !"cogstate_percentual".equals(tpTextField.getName()) )) {
					  System.out.println("jTextField para o Calculo v_exames 02: " + tpTextField.getText() + "\t" + tpTextField.getName());

					  if ( contObjTela == AV1 ) {
						  v_av1[index_av1] = tpTextField.getText();
						  System.out.println("v_av1[" + index_av1 + "]:" + v_av1[index_av1]);
						  ++index_av1;
					  } else if ( contObjTela == AV2 ) {
						  v_av2[index_av2] = tpTextField.getText();
						  System.out.println("v_av2[" + index_av2 + "]:" + v_av2[index_av2]);
						  ++index_av2;
					  } else if ( contObjTela == AV3 ) {
						  v_av3[index_av3] = tpTextField.getText();
						  System.out.println("v_av3[" + index_av3 + "]:" + v_av3[index_av3]);
						  ++index_av3;
					  }
				  } 
				  if ( contObjTela != AV1_AV2 || contObjTela != AV2_AV3 || contObjTela != AV1_AV3) {
					  System.out.println("ENTROU!!!");
					 construtor.append(tpTextField.getText()).append(",");
				  }
				  tpTextField.transferFocus();
			  }
			  
		  }
	  }
	  
	  /* Evento produzido pelo mouse */
	  public void actionPerformed( ActionEvent evt ) {
		  JButton tpButton = (JButton) evt.getSource();
		  /* Criar Método para criar o comando insert */
		  if ( tpButton == jButtonInserirNaLista ) {
			JOptionPane.showMessageDialog(null, ARR[index++] + " Inserido com Sucesso. ", null, JOptionPane.WARNING_MESSAGE); 
			
			if ( contObjTela == AV1 || ( contObjTela == AV2 || contObjTela == AV3 ) ) {
				for ( int i_textField_perc = 17; i_textField_perc < arrTextField.length; i_textField_perc++ ) {
       			 	System.out.println("arrTextField[" + i_textField_perc + "]: " + arrTextField[i_textField_perc].getName() + "\t" + arrTextField[i_textField_perc].getText()); 	
       			 	construtor.append(arrTextField[i_textField_perc].getText()).append(",");
          	  	}
       		 	System.out.println("id_tipo_avaliacao: " + id_tipo_avaliacao.getText());
       		 	construtor.append(id_tipo_avaliacao.getText()).append(",");
				
       	 	} 
			
			if ((contObjTela == AV1_AV2 || contObjTela == AV2_AV3 || contObjTela == AV1_AV3)) {
				 /* Entrar com o Cosntrutor automático sem acionar a tecla Tab */
				 System.out.println("trail_a: " + trail_a.getText());
				 construtor.append(trail_a.getText()).append(",");
				 /* Contagem até TUG_PONTUAÇÃO_TOTAL */
				 for ( int i_textField = 0; i_textField < (arrTextField.length) - 17; i_textField++ ) {
					 System.out.println("arrTextField[" + i_textField + "]: " + arrTextField[i_textField].getName() + "\t" + arrTextField[i_textField].getText());
					 construtor.append(arrTextField[i_textField].getText()).append(",");
				 }
				 
				 System.out.println("droga_substancia_total: " + droga_substancia_total.getText());
            	 System.out.println("medicamento_substancia_total: " + medicamento_substancia_total.getText());
            	 System.out.println("mini_mental_pontuacao_total: " + mini_mental_pontuacao_total.getText());
            	 System.out.println("qi_pontuacao_total: " + qi_pontuacao_total.getText());
            	 
				 construtor.append(droga_substancia_total.getText()).append(",");
				 construtor.append(medicamento_substancia_total.getText()).append(",");
				 construtor.append(mini_mental_pontuacao_total.getText()).append(",");
				 construtor.append(qi_pontuacao_total.getText()).append(",");
				 /* Contagem até COGSTATE_PERCENTUAL */
				 for ( int i_textField = (arrTextField.length) - 17; i_textField < arrTextField.length; i_textField++ ) {
					 System.out.println("arrTextField[" + i_textField + "]: " + arrTextField[i_textField].getName() + "\t" + arrTextField[i_textField].getText());
					 construtor.append(arrTextField[i_textField].getText()).append(",");
				 }
				 System.out.println("id_tipo_avaliacao: " + id_tipo_avaliacao.getText());
				 construtor.append(id_tipo_avaliacao.getText()).append(",");
			 }
			
			contObjTela++;
			if ( contObjTela > 6 ) {
				v_av1 = new String[17];
		    	v_av2 = new String[17];
		    	v_av3 = new String[17];
		    			    	
			  	index_av1 = 0;
			  	index_av2 = 0;
			  	index_av3 = 0;
			  	
				contObjTela = 1;
				index = 0;
			}
			
			System.out.println("countObjTela: " + contObjTela);
			System.out.println("O Botão INSERIR na Tela acionado");
			
			for ( JTextField jTextField : listaComponentesTextField ) {
				jTextField.setText(null);
			}
			
			construtor.deleteCharAt(construtor.lastIndexOf(","));
			System.out.println("Construtor: " + construtor.toString());
			listaComandosInserts = gerarInsert.createComandoInsert(construtor.toString());
			construtor = new StringBuilder();
		  } else if ( tpButton == jButtonGerarArquivo ) {
		  	System.out.println("O Botão Concluir acionado");
		  	//v_exames = new Integer[48];
		  	
		  	v_av1 = new String[17];
	    	v_av2 = new String[17];
	    	v_av3 = new String[17];
	    	
		  	index_av1 = 0;
		  	index_av2 = 0;
		  	index_av3 = 0;
		  	
		  	contObjTela = 1;
		  	index = 0;
		  	gerarInsert.escreverEmArquivoTxt(listaComandosInserts);
		  	if ( listaComandosInserts != null ) {
		  		listaComandosInserts.clear();
		  	}
		  } else {
			  System.out.println("O Botão Cancelar acionado");
			  System.exit(0);
		  }
		  
	  }
	  
	  public void construirLabelsGrupoAbasExames05() {
			jpanel05 = new JPanel();
			
			tiadl_percentual_label = new JLabel("Tiadl_Percentual");
			jpanel05.add(tiadl_percentual_label);
		      
		      dafs_percentual_label = new JLabel("Dafs_Percentual");
		      jpanel05.add(dafs_percentual_label);
		        
		      camcog_recordacao_percentual_label = new JLabel("Camcog_Record_Percentual");
		      jpanel05.add(camcog_recordacao_percentual_label);
		      
		      camcog_praxia_percentual_label = new JLabel("Camcog_Praxia_Percentual");
		      jpanel05.add(camcog_praxia_percentual_label);
		      
		      whoqol_abrev_percentual_label = new JLabel("Whoqol_Abrev_Percentual");
		      jpanel05.add(whoqol_abrev_percentual_label);
		      
		      whoqol_old_percentual_label = new JLabel("Whoqol_Old_Percentual");
		      jpanel05.add(whoqol_old_percentual_label);
		      
		      tug_percentual_label = new JLabel("Tug_Percentual");
		      jpanel05.add(tug_percentual_label);
		      
		      cogstate_percentual_label = new JLabel("Cogstate_Percentual");
		      jpanel05.add(cogstate_percentual_label);
		      
		      id_tipo_avaliacao_label = new JLabel("Id_tipo_avaliacao");
		      jpanel05.add(id_tipo_avaliacao_label);
			
		}  
    
	public void construirLabelsGrupoAbasExames04() {
		jpanel04 = new JPanel();
		
		cogstate_pontuacao_total_label = new JLabel("Cogstate_Pontuação_Total");
		jpanel04.add(cogstate_pontuacao_total_label);
	      
	      /* Label dos Percentuais */
	      trail_a_percentual_label = new JLabel("Trail_A_Percentual");
	      jpanel04.add(trail_a_percentual_label);
	      
	      hits_percentual_label = new JLabel("Hits_Percentual");
	      jpanel04.add(hits_percentual_label);
	      
	      cr_percentual_label = new JLabel("Cr_Percentual");
	      jpanel04.add(cr_percentual_label);
	      
	      trail_b_percentual_label = new JLabel("Trail_B_Percentual");
	      jpanel04.add(trail_b_percentual_label);
	      
	      fluencia_percentual_label = new JLabel("Fluencia_Percentual");
	      jpanel04.add(fluencia_percentual_label);
	      
	      gds_percentual_label = new JLabel("Gds_Percentual");
	      jpanel04.add(gds_percentual_label);
	      
	      katz_percentual_label = new JLabel("Katz_Percentual");
	      jpanel04.add(katz_percentual_label);
	      
	      lawton_percentual_label = new JLabel("Lawton_Percentual");
	      jpanel04.add(lawton_percentual_label);
		
	}

	public void construirLabelsGrupoAbasExames03() {
		  jpanel03 = new JPanel();
		
		  droga_substancia_total_label = new JLabel("Droga_Substancia_Total");
	      jpanel03.add(droga_substancia_total_label);
	      
	      medicamento_substancia_total_label = new JLabel("Medicamento_Substancia_Total");
	      jpanel03.add(medicamento_substancia_total_label);
	      
	      mini_mental_pontuacao_total_label = new JLabel("Mini_Mental_Pontuação_Total");
	      jpanel03.add(mini_mental_pontuacao_total_label);
  	  
	      qi_pontuacao_total_label = new JLabel("Qi_Pontuação_Total");
	      jpanel03.add(qi_pontuacao_total_label);
	      
	      
	}

	public void construirLabelsGrupoAbasExames02() {
		  jpanel02 = new JPanel();  
		
		  tiadl_pontuacao_total_label = new JLabel("Tiadl_Pontuação_Total");
		  jpanel02.add(tiadl_pontuacao_total_label);
	      
	      dafs_pontuacao_total_label = new JLabel("Dafs_Pontuação_Total");
	      jpanel02.add(dafs_pontuacao_total_label);

	      camcog_recordacao_pontuacao_total_label = new JLabel("Camcog_Record_Pont_Total");
	      jpanel02.add(camcog_recordacao_pontuacao_total_label);
	      
	      camcog_praxia_pontuacao_total_label = new JLabel("Camcog_Praxia_Pont_Total");
	      jpanel02.add(camcog_praxia_pontuacao_total_label);
	      
	      whoqol_abrev_pontuacao_total_label = new JLabel("Whoqol_Abrev_Pontuação_Total");
	      jpanel02.add(whoqol_abrev_pontuacao_total_label);
	      
	      whoqol_old_pontuacao_total_label = new JLabel("Whoqol_Old_Pontuação_Total");
	      jpanel02.add(whoqol_old_pontuacao_total_label);
	      
	      tug_pontuacao_total_label = new JLabel("Tug_Pontuação_Total");
	      jpanel02.add(tug_pontuacao_total_label);
	      
	}

	public void construirLabelsGrupoAbasExames01() {
		  jpanel01 = new JPanel();
		
		  trail_a_label = new JLabel("Trail_A");
		  jpanel01.add(trail_a_label);
	      
	      trail_a_segundo_label = new JLabel("Trail_A_Segundo");
	      jpanel01.add(trail_a_segundo_label);
	      
	      hits_label = new JLabel("Hits");
	      jpanel01.add(hits_label);
	      
	      cr_label = new JLabel("Cr");
	      jpanel01.add(cr_label);
	      
	      trail_b_label = new JLabel("Trail_B");
	      jpanel01.add(trail_b_label);
	      
	      trail_b_segundo_label = new JLabel("Trail_B_Segundo");
	      jpanel01.add(trail_b_segundo_label);
	      
	      fluencia_label = new JLabel("Fluencia");
	      jpanel01.add(fluencia_label);
	      
	      gds_pontuacao_total_label = new JLabel("GDS_Pontuação_total");
	      jpanel01.add(gds_pontuacao_total_label);
	      
	      katz_pontuacao_total_label = new JLabel("Katz_Pontuação_Total");
	      jpanel01.add(katz_pontuacao_total_label);
	      
	      lawton_pontuacao_total_label = new JLabel("Lawton_Pontuação_Total");
	      jpanel01.add(lawton_pontuacao_total_label);

		
	}
	
	public void construirTextFieldGrupoAbasExames05() {
		  tiadl_percentual = new JTextField(10);
	      tiadl_percentual.setName("tiadl_percentual");
	      jpanel05.add(tiadl_percentual);
	      listaComponentesTextField.add(tiadl_percentual);
	      arrTextField[25] = tiadl_percentual;
	      
	      dafs_percentual = new JTextField(10);
	      dafs_percentual.setName("dafs_percentual");
	      jpanel05.add(dafs_percentual);
	      listaComponentesTextField.add(dafs_percentual);
	      arrTextField[26] = dafs_percentual;
	      
	      camcog_recordacao_percentual = new JTextField(10);
	      camcog_recordacao_percentual.setName("camcog_recordacao_percentual");
	      jpanel05.add(camcog_recordacao_percentual);
	      listaComponentesTextField.add(camcog_recordacao_percentual);
	      arrTextField[27] = camcog_recordacao_percentual;
	      
	      camcog_praxia_percentual = new JTextField(10);
	      camcog_praxia_percentual.setName("camcog_praxia_percentual");
	      jpanel05.add(camcog_praxia_percentual);
	      listaComponentesTextField.add(camcog_praxia_percentual);
	      arrTextField[28] = camcog_praxia_percentual;
	      
	      whoqol_abrev_percentual = new JTextField(10);
	      whoqol_abrev_percentual.setName("whoqol_abrev_percentual");
	      jpanel05.add(whoqol_abrev_percentual);
	      listaComponentesTextField.add(whoqol_abrev_percentual);
	      arrTextField[29] = whoqol_abrev_percentual;
	      
	      whoqol_old_percentual = new JTextField(10);
	      whoqol_old_percentual.setName("whoqol_old_percentual");
	      jpanel05.add(whoqol_old_percentual);
	      listaComponentesTextField.add(whoqol_old_percentual);
	      arrTextField[30] = whoqol_old_percentual;
	      
	      tug_percentual = new JTextField(10);
	      tug_percentual.setName("tug_percentual");
	      jpanel05.add(tug_percentual);
	      listaComponentesTextField.add(tug_percentual);
	      arrTextField[31] = tug_percentual;
	      
	      cogstate_percentual = new JTextField(10);
	      cogstate_percentual.setName("cogstate_percentual");
	      jpanel05.add(cogstate_percentual);
	      listaComponentesTextField.add(cogstate_percentual);
	      arrTextField[32] = cogstate_percentual;
	      
	      id_tipo_avaliacao = new JTextField(10);
	      id_tipo_avaliacao.setName("id_tipo_avaliacao");
	      jpanel05.add(id_tipo_avaliacao);
	      listaComponentesTextField.add(id_tipo_avaliacao);
		
	}
	
	public void construirTextFieldGrupoAbasExames04() {
		cogstate_pontuacao_total = new JTextField(10);
	      cogstate_pontuacao_total.setName("cogstate_pontuacao_total");
	      jpanel04.add(cogstate_pontuacao_total);
	      listaComponentesTextField.add(cogstate_pontuacao_total);
	      arrTextField[16] = cogstate_pontuacao_total;
	      
	      /* Construção dos campos TextField dos Percentuais */
	      trail_a_percentual = new JTextField(10);
	      trail_a_percentual.setName("trail_a_percentual");
	      jpanel04.add(trail_a_percentual);
	      listaComponentesTextField.add(trail_a_percentual);
	      arrTextField[17] = trail_a_percentual;
	      
	      hits_percentual = new JTextField(10);
	      hits_percentual.setName("hits_percentual");
	      jpanel04.add(hits_percentual);
	      listaComponentesTextField.add(hits_percentual);
	      arrTextField[18] = hits_percentual;
	      
	      cr_percentual = new JTextField(10);
	      cr_percentual.setName("cr_percentual");
	      jpanel04.add(cr_percentual);
	      listaComponentesTextField.add(cr_percentual);
	      arrTextField[19] = cr_percentual;
	      
	      trail_b_percentual = new JTextField(10);
	      trail_b_percentual.setName("trail_b_percentual");
	      jpanel04.add(trail_b_percentual);
	      listaComponentesTextField.add(trail_b_percentual);
	      arrTextField[20] = trail_b_percentual;
	      
	      fluencia_percentual = new JTextField(10);
	      fluencia_percentual.setName("fluencia_percentual");
	      jpanel04.add(fluencia_percentual);
	      listaComponentesTextField.add(fluencia_percentual);
	      arrTextField[21] = fluencia_percentual;
	      
	      gds_percentual = new JTextField(10);
	      gds_percentual.setName("gds_percentual");
	      jpanel04.add(gds_percentual);
	      listaComponentesTextField.add(gds_percentual);
	      arrTextField[22] = gds_percentual;
	      
	      katz_percentual = new JTextField(10);
	      katz_percentual.setName("katz_percentual");
	      jpanel04.add(katz_percentual);
	      listaComponentesTextField.add(katz_percentual);
	      arrTextField[23] = katz_percentual;
	      
	      lawton_percentual = new JTextField(10);
	      lawton_percentual.setName("lawton_percentual");
	      jpanel04.add(lawton_percentual);
	      listaComponentesTextField.add(lawton_percentual);
	      arrTextField[24] = lawton_percentual;
		
	}

	public void construirTextFieldGrupoAbasExames03() {
		  
		  droga_substancia_total = new JTextField(10);
	      droga_substancia_total.setName("droga_substancia_total");
	      jpanel03.add(droga_substancia_total);
	      listaComponentesTextField.add(droga_substancia_total);
	      
	      medicamento_substancia_total = new JTextField(10);
	      medicamento_substancia_total.setName("medicamento_substancia_total");
	      jpanel03.add(medicamento_substancia_total);
	      listaComponentesTextField.add(medicamento_substancia_total);
	      
	      mini_mental_pontuacao_total = new JTextField(10);
	      mini_mental_pontuacao_total.setName("mini_mental_pontuacao_total");
	      jpanel03.add(mini_mental_pontuacao_total);
	      listaComponentesTextField.add(mini_mental_pontuacao_total);
		
		  qi_pontuacao_total = new JTextField(10);
	      qi_pontuacao_total.setName("qi_pontuacao_total");
	      jpanel03.add(qi_pontuacao_total);
	      listaComponentesTextField.add(qi_pontuacao_total);

	}

	public void construirTextFieldGrupoAbasExames02() {
		  tiadl_pontuacao_total = new JTextField(10);
	      jpanel02.add(tiadl_pontuacao_total);
	      listaComponentesTextField.add(tiadl_pontuacao_total);
	      arrTextField[9] = tiadl_pontuacao_total;
	      
	      dafs_pontuacao_total = new JTextField(10);
	      jpanel02.add(dafs_pontuacao_total);
	      listaComponentesTextField.add(dafs_pontuacao_total);
	      arrTextField[10] = dafs_pontuacao_total;
	      
	      camcog_recordacao_pontuacao_total = new JTextField(10);
	      jpanel02.add(camcog_recordacao_pontuacao_total);
	      listaComponentesTextField.add(camcog_recordacao_pontuacao_total);
	      arrTextField[11] = camcog_recordacao_pontuacao_total;
	      
	      camcog_praxia_pontuacao_total = new JTextField(10);
	      jpanel02.add(camcog_praxia_pontuacao_total);
	      listaComponentesTextField.add(camcog_praxia_pontuacao_total);
	      arrTextField[12] = camcog_praxia_pontuacao_total;
	      
	      whoqol_abrev_pontuacao_total = new JTextField(10);
	      whoqol_abrev_pontuacao_total.setName("whoqol_abrev_pontuacao_total");
	      jpanel02.add(whoqol_abrev_pontuacao_total);
	      listaComponentesTextField.add(whoqol_abrev_pontuacao_total);
	      arrTextField[13] = whoqol_abrev_pontuacao_total;
	      
	      whoqol_old_pontuacao_total = new JTextField(10);
	      whoqol_old_pontuacao_total.setName("whoqol_old_pontuacao_total");
	      jpanel02.add(whoqol_old_pontuacao_total);
	      listaComponentesTextField.add(whoqol_old_pontuacao_total);
	      arrTextField[14] = whoqol_old_pontuacao_total;
	      
	      tug_pontuacao_total = new JTextField(10);
	      tug_pontuacao_total.setName("tug_pontuacao_total");
	      jpanel02.add(tug_pontuacao_total);
	      listaComponentesTextField.add(tug_pontuacao_total);
	      arrTextField[15] = tug_pontuacao_total;
	      
	}

	public void construirTextFieldGrupoAbasExames01() {
		  listaComponentesTextField = new ArrayList<JTextField>();

	      trail_a = new JTextField(10);
	      trail_a.setName("trail_a");
	      jpanel01.add(trail_a);
	      listaComponentesTextField.add(trail_a);
	      
	      trail_a_segundo = new JTextField(10);
	      jpanel01.add(trail_a_segundo);
	      listaComponentesTextField.add(trail_a_segundo);
	      arrTextField[0] = trail_a_segundo;
	      
	      hits = new JTextField(10);
	      jpanel01.add(hits);
	      listaComponentesTextField.add(hits);
	      arrTextField[1] = hits;
	      
	      cr = new JTextField(10);
	      jpanel01.add(cr);
	      listaComponentesTextField.add(cr);
	      arrTextField[2] = cr;
	      
	      trail_b = new JTextField(10);
	      trail_b.setName("trail_b");
	      jpanel01.add(trail_b);
	      listaComponentesTextField.add(trail_b);
	      arrTextField[3] = trail_b;
	      
	      trail_b_segundo = new JTextField(10);
	      jpanel01.add(trail_b_segundo);
	      listaComponentesTextField.add(trail_b_segundo);
	      arrTextField[4] = trail_b_segundo;
	      
	      fluencia = new JTextField(10);
	      jpanel01.add(fluencia);
	      listaComponentesTextField.add(fluencia);
	      arrTextField[5] = fluencia;
	      
	      gds_pontuacao_total = new JTextField(10);
	      gds_pontuacao_total.setName("gds_pontuacao_total");
	      jpanel01.add(gds_pontuacao_total);
	      listaComponentesTextField.add(gds_pontuacao_total);
	      arrTextField[6] = gds_pontuacao_total;
	      
	      katz_pontuacao_total = new JTextField(10);
	      jpanel01.add(katz_pontuacao_total);
	      listaComponentesTextField.add(katz_pontuacao_total);
	      arrTextField[7] = katz_pontuacao_total;
	      
	      lawton_pontuacao_total = new JTextField(10);
	      jpanel01.add(lawton_pontuacao_total);
	      listaComponentesTextField.add(lawton_pontuacao_total); 
	      arrTextField[8] = lawton_pontuacao_total;
		
	}

      
	public void jButtonAnteriorActionPerformed(ActionEvent evt) {
         int i = jTabbedPaneContainer.getSelectedIndex();
         System.out.println("Ant: " + i);
         
         if ( (i >= 1 && i <= 3) ) {
        	 if ( i == 3 && (contObjTela > AV1 && contObjTela <= AV1_AV3) ) {
	        	 System.out.println("Entrou Ant!!!");
	        	 droga_substancia_total.setText("null");
	        	 medicamento_substancia_total.setText("null");
	        	 mini_mental_pontuacao_total.setText("null");
	        	 qi_pontuacao_total.setText("null");
        	 } 
        	 if ( contObjTela == AV2 || (contObjTela == AV1_AV2 || contObjTela == AV2_AV3) ) {
        		 whoqol_abrev_pontuacao_total.setText("null");
        		 whoqol_old_pontuacao_total.setText("null");
        		 tug_pontuacao_total.setText("null");
        		 
        		 whoqol_abrev_percentual.setText("null");
        		 whoqol_old_percentual.setText("null");
        		 tug_percentual.setText("null");
        	 } else if ( contObjTela == AV1 || contObjTela == AV3 ) {
    			 whoqol_abrev_percentual.setText("null");
        		 whoqol_old_percentual.setText("null");
        		 tug_percentual.setText("null");
    
    		 } else if (contObjTela == AV1_AV2 || (contObjTela == AV2_AV3 || contObjTela == AV1_AV3)) {
        		 trail_a.setText("null");
        		 trail_b.setText("null");
        	 }
         }
         
         if (i == 0){
               jTabbedPaneContainer.setSelectedIndex(jTabbedPaneContainer.getComponentCount()-1);
         }else{
               jTabbedPaneContainer.setSelectedIndex(i-1);
         }
      }
   
      public void jButtonProximoActionPerformed(ActionEvent evt) {
         int i = jTabbedPaneContainer.getSelectedIndex();    
         System.out.println("Prox: " + i);
         if ( (i >= 0 && i <= 4 ) ) {
        	 if ( contObjTela == AV1 || ( contObjTela == AV2 || contObjTela == AV3 ) ) {
        		 
        		 for ( int i_textField_perc = 17; i_textField_perc < arrTextField.length; i_textField_perc++ ) {
        			 arrTextField[i_textField_perc].setText("null");
            	 }
        		 
        		 if ( contObjTela == AV1 ) {
        			 id_tipo_avaliacao.setText("1");
        		 } else if ( contObjTela == AV2 ) {
        			 id_tipo_avaliacao.setText("2");
        		 } else if ( contObjTela == AV3 ) {
        			 id_tipo_avaliacao.setText("3");
        		 }
        	 }
        	 if ( i == 1 && (contObjTela == AV2 || contObjTela == AV3) ) {
        		 System.out.println("Entrou Prox!!!");
            	 droga_substancia_total.setText("null");
            	 medicamento_substancia_total.setText("null");
            	 mini_mental_pontuacao_total.setText("null");
            	 qi_pontuacao_total.setText("null");
            	 
            	 System.out.println("droga_substancia_total: " + droga_substancia_total.getText());
            	 System.out.println("medicamento_substancia_total: " + medicamento_substancia_total.getText());
            	 System.out.println("mini_mental_pontuacao_total: " + mini_mental_pontuacao_total.getText());
            	 System.out.println("qi_pontuacao_total: " + qi_pontuacao_total.getText());
            	 
    			 construtor.append(droga_substancia_total.getText()).append(",");
    			 construtor.append(medicamento_substancia_total.getText()).append(",");
    			 construtor.append(mini_mental_pontuacao_total.getText()).append(",");
    			 construtor.append(qi_pontuacao_total.getText()).append(",");
        	 } 
        	 if ( contObjTela == AV2 ) {
    			 whoqol_abrev_pontuacao_total.setText("null");
        		 whoqol_old_pontuacao_total.setText("null");
        		 tug_pontuacao_total.setText("null");
        		 
        		 System.out.println("whoqol_abrev_pontuacao_total: " + whoqol_abrev_pontuacao_total.getText());
            	 System.out.println("whoqol_old_pontuacao_total: " + whoqol_old_pontuacao_total.getText());
            	 System.out.println("tug_pontuacao_total: " + tug_pontuacao_total.getText());

        	 } 

      		 if ((contObjTela == AV1_AV2 || contObjTela == AV2_AV3 || contObjTela == AV1_AV3)) {
        		 trail_a.setText("null");
        		 
        		 droga_substancia_total.setText("null");
            	 medicamento_substancia_total.setText("null");
            	 mini_mental_pontuacao_total.setText("null");
            	 qi_pontuacao_total.setText("null");

        		 
        		 if ( contObjTela == AV1_AV2 ) {
           			/* Fazer os Cálculos - AV1 - AV2 */
        			sub_exames_cognitivos = new Integer[17];
        	    	perc_exames_cognitivos = new Integer[17];
        	    	
        	    	for( int index_ex_pont = 0, index_ex_perc = 17; index_ex_pont < v_av1.length && index_ex_perc < (v_av1.length + v_av2.length); index_ex_perc++, index_ex_pont++ ) {
           				if ( (!"null".equals(v_av2[index_ex_pont]) && (!"trail_b".equals(arrTextField[index_ex_pont].getName()) && !"whoqol_abrev_pontuacao_total".equals(arrTextField[index_ex_pont].getName())  
           					&& !"whoqol_old_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) && !"tug_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) )) ) {
           					
           					sub_exames_cognitivos[index_ex_pont] = (int) (new Double(v_av1[index_ex_pont]) - new Double(v_av2[index_ex_pont]));
           					System.out.println("sub_exames_cognitivos[" + index_ex_pont + "]: " + sub_exames_cognitivos[index_ex_pont]);
           					arrTextField[index_ex_pont].setText(sub_exames_cognitivos[index_ex_pont].toString());
           					
           				} else if ( "trail_b".equals(arrTextField[index_ex_pont].getName()) ) {
           					arrTextField[index_ex_pont].setText("null");
           					
           					index_ex_pont++; //4
           					
           					sub_exames_cognitivos[index_ex_pont] = (int) (new Double(v_av1[index_ex_pont]) - new Double(v_av2[index_ex_pont]));
           					arrTextField[index_ex_pont].setText(sub_exames_cognitivos[index_ex_pont].toString());
           				} else if ( ("null".equals(v_av2[index_ex_pont]) && ("whoqol_abrev_pontuacao_total".equals(arrTextField[index_ex_pont].getName())  
           						  || "whoqol_old_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) || "tug_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) )) ) {
           					   arrTextField[index_ex_pont].setText("null");
           				}
           				if ( ( !"whoqol_abrev_percentual".equals(arrTextField[index_ex_perc].getName()) && !"whoqol_old_percentual".equals(arrTextField[index_ex_perc].getName()) 
           					&& !"tug_percentual".equals(arrTextField[index_ex_perc].getName()) ) ) {
           					try {
           					//if ( !"0".equals(v_av1[index_ex_pont]) ) {
           						divZero = (int) ((new Double(v_av2[index_ex_pont]) / new Double(v_av1[index_ex_pont])) - 1);
           						System.out.println("divZero: " + divZero);
           						if ( divZero < 0 ) {
           							perc_exames_cognitivos[index_ex_pont] = (int) Math.floor(((new Double(v_av2[index_ex_pont]) / new Double(v_av1[index_ex_pont])) - 1) * 100);
           							arrTextField[index_ex_perc].setText(perc_exames_cognitivos[index_ex_pont].toString());
           						} else if ( divZero != 2147483647) {
           							perc_exames_cognitivos[index_ex_pont] = (int) Math.ceil(((new Double(v_av2[index_ex_pont]) / new Double(v_av1[index_ex_pont])) - 1) * 100);	
           							arrTextField[index_ex_perc].setText(perc_exames_cognitivos[index_ex_pont].toString());
           						} else {
           							arrTextField[index_ex_perc].setText("null");
           						}

           					} catch ( ArithmeticException e ) {
           						System.out.println("Excecao arrTextField[" + index_ex_pont + "]: " + arrTextField[index_ex_pont].getText());
           						arrTextField[index_ex_perc].setText("null");
           					}

           				} else {
           					arrTextField[index_ex_perc].setText("null");
           				}
           				
           				id_tipo_avaliacao.setText("4");

           			}

           		 } else if ( contObjTela == AV2_AV3 ) {
           			// Fazer os Cálculos AV2 - AV3 
           			sub_exames_cognitivos = new Integer[17];
        	    	perc_exames_cognitivos = new Integer[17];
        	    	
        	    	for( int index_ex_pont = 0, index_ex_perc = 17; index_ex_pont < v_av2.length && index_ex_perc < (v_av2.length + v_av3.length); index_ex_perc++, index_ex_pont++ ) {
           				if ( (!"null".equals(v_av2[index_ex_pont]) && (!"trail_b".equals(arrTextField[index_ex_pont].getName()) && !"whoqol_abrev_pontuacao_total".equals(arrTextField[index_ex_pont].getName())  
           					&& !"whoqol_old_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) && !"tug_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) )) ) {
           					
           					sub_exames_cognitivos[index_ex_pont] = (int) (new Double(v_av2[index_ex_pont]) - new Double(v_av3[index_ex_pont]));
           					System.out.println("sub_exames_cognitivos[" + index_ex_pont + "]: " + sub_exames_cognitivos[index_ex_pont]);
           					arrTextField[index_ex_pont].setText(sub_exames_cognitivos[index_ex_pont].toString());
           					
           				} else if ( "trail_b".equals(arrTextField[index_ex_pont].getName()) ) {
           					arrTextField[index_ex_pont].setText("null");
           					
           					index_ex_pont++; //4
           					
           					sub_exames_cognitivos[index_ex_pont] = (int) (new Double(v_av2[index_ex_pont]) - new Double(v_av3[index_ex_pont]));
           					arrTextField[index_ex_pont].setText(sub_exames_cognitivos[index_ex_pont].toString());
           				} else if ( ("null".equals(v_av2[index_ex_pont]) && ("whoqol_abrev_pontuacao_total".equals(arrTextField[index_ex_pont].getName())  
           						  || "whoqol_old_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) || "tug_pontuacao_total".equals(arrTextField[index_ex_pont].getName()) )) ) {
           					   arrTextField[index_ex_pont].setText("null");
           				}
           				if ( ( !"whoqol_abrev_percentual".equals(arrTextField[index_ex_perc].getName()) && !"whoqol_old_percentual".equals(arrTextField[index_ex_perc].getName()) 
           					&& !"tug_percentual".equals(arrTextField[index_ex_perc].getName()) ) ) {
           					try {
           						divZero = (int) ((new Double(v_av3[index_ex_pont]) / new Double(v_av2[index_ex_pont])) - 1);
           						System.out.println("divZero: " + divZero);
           						if ( divZero < 0 ) {
           							perc_exames_cognitivos[index_ex_pont] = (int) Math.floor(((new Double(v_av3[index_ex_pont]) / new Double(v_av2[index_ex_pont])) - 1) * 100);
           							arrTextField[index_ex_perc].setText(perc_exames_cognitivos[index_ex_pont].toString());
           						} else if ( divZero != 2147483647) {
           							perc_exames_cognitivos[index_ex_pont] = (int) Math.ceil(((new Double(v_av3[index_ex_pont]) / new Double(v_av2[index_ex_pont])) - 1) * 100);	
           							arrTextField[index_ex_perc].setText(perc_exames_cognitivos[index_ex_pont].toString());
           						} else {
           							arrTextField[index_ex_perc].setText("null");
           						}

           					} catch ( ArithmeticException e ) {
           						System.out.println("Excecao arrTextField[" + index_ex_pont + "]: " + arrTextField[index_ex_pont].getText());
           						arrTextField[index_ex_perc].setText("null");
           					}

           				} else {
           					arrTextField[index_ex_perc].setText("null");
           				}
           				
           				id_tipo_avaliacao.setText("5");

           			}
        	    	

             	 } else if ( contObjTela == AV1_AV3 ) {
           			// Fazer os Cálculos AV1 - AV3
             		sub_exames_cognitivos = new Integer[17];
        	    	perc_exames_cognitivos = new Integer[17];
        	    	for( int index_ex_pont = 0, index_ex_perc = 17; index_ex_pont < v_av1.length && index_ex_perc < (v_av1.length + v_av3.length); index_ex_perc++, index_ex_pont++ ) {
           				if ( !"trail_b".equals(arrTextField[index_ex_pont].getName()) ) {
           					sub_exames_cognitivos[index_ex_pont] = (int) (new Double(v_av1[index_ex_pont]) - new Double(v_av3[index_ex_pont]));
           					System.out.println("sub_exames_cognitivos[" + index_ex_pont + "]: " + sub_exames_cognitivos[index_ex_pont]);
           					arrTextField[index_ex_pont].setText(sub_exames_cognitivos[index_ex_pont].toString());
           				} else {	
           					arrTextField[index_ex_pont].setText("null");
           					
           					index_ex_pont++; //4
           					
           					sub_exames_cognitivos[index_ex_pont] = (int) (new Double(v_av1[index_ex_pont]) - new Double(v_av3[index_ex_pont]));
           					arrTextField[index_ex_pont].setText(sub_exames_cognitivos[index_ex_pont].toString());
           				} 
       					try {
       						divZero = (int) ((new Double(v_av3[index_ex_pont]) / new Double(v_av1[index_ex_pont])) - 1);
       						System.out.println("divZero: " + divZero);
       						if ( divZero < 0 ) {
       							perc_exames_cognitivos[index_ex_pont] = (int) Math.floor(((new Double(v_av3[index_ex_pont]) / new Double(v_av1[index_ex_pont])) - 1) * 100);
       							arrTextField[index_ex_perc].setText(perc_exames_cognitivos[index_ex_pont].toString());
       						} else if ( divZero != 2147483647) {
       							perc_exames_cognitivos[index_ex_pont] = (int) Math.ceil(((new Double(v_av3[index_ex_pont]) / new Double(v_av1[index_ex_pont])) - 1) * 100);	
       							arrTextField[index_ex_perc].setText(perc_exames_cognitivos[index_ex_pont].toString());
       						} else {
       							arrTextField[index_ex_perc].setText("null");
       						}

       					} catch ( ArithmeticException e ) {
       						System.out.println("Excecao arrTextField[" + index_ex_pont + "]: " + arrTextField[index_ex_pont].getText());
       						arrTextField[index_ex_perc].setText("null");
       					}

           				id_tipo_avaliacao.setText("6");
           			}
             	 }
        	 }
      		 		 
         if (jTabbedPaneContainer.getComponentCount() - 1 == i) {
               jTabbedPaneContainer.setSelectedIndex(0);
         }else{
               jTabbedPaneContainer.setSelectedIndex(i+1);
         }
         
      }
    }
      
      /**
       * @param args the command line arguments
       */
      public static void main(String args[]) {
    	  /* Definindo uma única thread para cuidar da criação dos componentes do JFrame e encarregada de carregar todos os eventos antes da criação dos componentes. Caso contrário, os eventos, do teclado ou Mouse, são lançados após a criação dos componentes(JTextField). */
    	 EventQueue.invokeLater(new Runnable() 
  		 {
            @Override
			public void run() {
            	  JTabbed jTabbeds = new JTabbed();
            	  jTabbeds.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            	  jTabbeds.pack();
            	  jTabbeds.setVisible(true);
            }
         });
      }  
  }
