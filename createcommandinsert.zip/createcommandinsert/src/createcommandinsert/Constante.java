package createcommandinsert;

public class Constante {
	public static final int AV1 = 1;
	public static final int AV2 = 2;
	public static final int AV1_AV2 = 3;
	public static final int AV3 = 4;
	public static final int AV2_AV3 = 5;
	public static final int AV1_AV3 = 6;
}
