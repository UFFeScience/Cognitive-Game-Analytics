package academia_cerebro.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesFiles {
	public static Properties getProp() {
		Properties props = new Properties();
		FileInputStream fileStream;
		try {
			fileStream = new FileInputStream("./properties/dados.properties");
			props.load(fileStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return props;
	}
}
