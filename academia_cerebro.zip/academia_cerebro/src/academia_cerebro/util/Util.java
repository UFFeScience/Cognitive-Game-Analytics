package academia_cerebro.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import jxl.Cell;
import jxl.CellType;
import jxl.LabelCell;
import jxl.NumberCell;
import jxl.Sheet;
import jxl.Workbook;

public class Util {
	public static Timestamp convertStringToTimestamp(String data) {
		//SimpleDateFormat dataFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dataFormat = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date date = dataFormat.parse(data);
			Timestamp timestamp_date = new Timestamp(date.getTime());
			System.out.println("Formato Timestamp = " + timestamp_date);
			return timestamp_date;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static Time convertStringToTime(String tempo) {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		try {
			Date tmp = sdf.parse(tempo);
			Time time = new Time(tmp.getTime());
			System.out.println("Formato Time = " + time);
			return time;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static Date converterData(String data) {
		//SimpleDateFormat dtf = new SimpleDateFormat("dd-MM-yyyy", new Locale("pt","br"));
		//SimpleDateFormat dtf = new SimpleDateFormat("dd-MM-yyyy");
		String[] dtd = data.split("-");
		String dia = dtd[1];
		String mes = dtd[0];
		String ano = dtd[2];
		try {
			String dataBR = dia + "-" + mes + "-" + ano; 
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			Date dtBR = df.parse(dataBR);
			System.out.println("date = " + dia + "\n" + mes + "\n" + ano + "\n" + dataBR + "\n" + dtBR);
			return dtBR;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static Timestamp convertStringToTimestampSessaoJogo(String data) {
		//SimpleDateFormat dataFormat = new SimpleDateFormat("dd/MM/yyyy");
		String[] dtd = data.split("-");
		String dia = dtd[1];
		String mes = dtd[0];
		String ano = ("20" + dtd[2]);
		String dataBR = dia + "-" + mes + "-" + ano;
		System.out.println("dataBR = " + dataBR);
		SimpleDateFormat dataFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			Date date = dataFormat.parse(dataBR);
			Timestamp timestamp_date = new Timestamp(date.getTime());
			System.out.println("Formato Timestamp = " + timestamp_date);
			return timestamp_date;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/* Ler arquivo TXT */
	public static String[] lerNomeExamesTxt() throws IOException {
		// TODO Auto-generated method stub
		String lerLinhaArqTxt = null;
		//String paths = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/KeyWords/KeyWords_Exames.txt";
		String paths = PropertiesFiles.getProp().getProperty("prop.path.keywords") + "KeyWords_Exames.txt";
		File pathAtual = new File(paths);
		InputStream isPath = new FileInputStream(pathAtual); 
		BufferedReader bfrPath = new BufferedReader(new InputStreamReader(isPath));
		
		//Ler cada registro do Nome do Exame
		String[] arrNomeExame = new String[33];
		int index = 0;
		while((lerLinhaArqTxt = bfrPath.readLine()) != null) {
			arrNomeExame[index] = lerLinhaArqTxt;
			System.out.println("Nome do Exame Lido = " + arrNomeExame[index] +  "\n" + lerLinhaArqTxt + "\n" + index);
			index++;
		}
		bfrPath.close();
		
		return arrNomeExame;
	} 
	
	/* Ler arquivo TXT */
	public static String[] lerNomeArquivoTxt() throws IOException {
		// TODO Auto-generated method stub
		String lerLinhaArqTxt = null;
		//String paths = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/KeyWords/KeyWords_Exames.txt";
		String paths = PropertiesFiles.getProp().getProperty("prop.path.keywords") + "KeyWords_Exames.txt";
		File pathAtual = new File(paths);
		InputStream isPath = new FileInputStream(pathAtual); 
		BufferedReader bfrPath = new BufferedReader(new InputStreamReader(isPath));
		
		//Ler cada registro do Nome do Exame
		String[] arrNomeExame = new String[33];
		int index = 0;
		while((lerLinhaArqTxt = bfrPath.readLine()) != null) {
			arrNomeExame[index] = lerLinhaArqTxt;
			System.out.println("Nome do Exame Lido = " + arrNomeExame[index] +  "\n" + lerLinhaArqTxt + "\n" + index);
			index++;
		}
		bfrPath.close();
		
		return arrNomeExame;
	}
	
	public static Map<Object, Object> lerConteudoArquivoExcel(Workbook wb, Sheet st, String nomePlanilha) {	
		Object[][] resultado;
		Cell celulaPrimColuna;
		Cell celulaSegColuna; 
        try {
            int numLinha  = st.getRows();
            System.out.println("QTD Linhas: " + numLinha);
            int numColuna = st.getColumns();
            System.out.println("QTD Colunas: " + numColuna);
            resultado = new Object[numLinha][numColuna]; 
            Map<Object, Object> mapaParametros = new LinkedHashMap<Object, Object>();
            for(int linha=0; linha < numLinha; linha++) {
                celulaPrimColuna = st.getCell(0,linha);
                celulaSegColuna = st.getCell(1, linha); 
                System.out.println("CelulaPrimColuna.getType = " + celulaPrimColuna.getType());
                System.out.println("CelulaSegColuna.getType = " + celulaSegColuna.getType());
                if ((celulaPrimColuna.getType() == CellType.NUMBER) && (celulaSegColuna.getType() == CellType.NUMBER)) {
                    NumberCell numCelulaPrimColuna = (NumberCell) celulaPrimColuna;
                    NumberCell numCelulaSegColuna = (NumberCell) celulaSegColuna;
                    resultado[linha][0] = new Long((long) numCelulaPrimColuna.getValue());
                    resultado[linha][1] = new Long((long) numCelulaSegColuna.getValue());
                }
                if ((celulaPrimColuna.getType() == CellType.LABEL) && (celulaSegColuna.getType() == CellType.NUMBER)) {
                	LabelCell labelPrimCelula = (LabelCell) celulaPrimColuna;
                    NumberCell numCelulaSegColuna = (NumberCell) celulaSegColuna;
                    resultado[linha][0] = labelPrimCelula.getString();
                    resultado[linha][1] = new Long((long) numCelulaSegColuna.getValue());
                }
                if (((celulaPrimColuna.getType() == CellType.LABEL) && (celulaSegColuna.getType() == CellType.LABEL))) {
                    LabelCell labelPrimCelula = (LabelCell) celulaPrimColuna;
                    LabelCell labelSegCelula = (LabelCell) celulaSegColuna;
                    resultado[linha][0] = labelPrimCelula.getString();
                    resultado[linha][1] = labelSegCelula.getString();
                    
                } 
                if ((celulaPrimColuna.getType() == CellType.EMPTY) || (celulaSegColuna.getType() == CellType.EMPTY)) {
                	LabelCell labelPrimCelula = (LabelCell) celulaPrimColuna;
                    LabelCell labelSegCelula = null;
                    resultado[linha][0] = labelPrimCelula.getString();
                    resultado[linha][1] = labelSegCelula;
                }              
                mapaParametros.put(resultado[linha][0],resultado[linha][1]);            
                System.out.println("Resultado da Celula: " + resultado[linha][0] + " <- " + resultado[linha][1]);            
            }
            return mapaParametros;
        } catch (Exception e) {
        		e.printStackTrace();
        		System.out.println("Erro Geral!!!");
        }
        return null;
	}
	
	/* Ler arquivo TXT */
	public static String[] lerNomeArquivoJogosErradosTxt() throws IOException {
		// TODO Auto-generated method stub
		String lerLinhaArqTxt = null;
		//String paths = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/KeyWords/KeyWords_Jogos_Errados.txt";
		String paths = PropertiesFiles.getProp().getProperty("prop.path.keywords") + "KeyWords_Jogos_Errados.txt";
		File pathAtual = new File(paths);
		InputStream isPath = new FileInputStream(pathAtual); 
		BufferedReader bfrPath = new BufferedReader(new InputStreamReader(isPath));
		
		//Ler cada registro do Nome do Jogo
		String[] arrNomeJogo = new String[29];
		int index = 0;
		while((lerLinhaArqTxt = bfrPath.readLine()) != null) {
			arrNomeJogo[index] = lerLinhaArqTxt;
			System.out.println("Nome do Jogo Lido = " + arrNomeJogo[index] +  "\n" + lerLinhaArqTxt + "\n" + index);
			index++;
		}
		System.out.println("Nome do Jogo Lido = " + index);
		bfrPath.close();
		
		return arrNomeJogo;
	}
	
	/* Abrir arquivo TXT */
	public static BufferedReader abrirArquivo() {
		//String paths = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/KeyWords/KeyWords_Exames_Metodo.txt";
		String paths = PropertiesFiles.getProp().getProperty("prop.path.keywords") + "KeyWords_Exames_Metodo.txt";
		File pathAtual = new File(paths);
		InputStream isPath = null;
		try {
			isPath = new FileInputStream(pathAtual);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		BufferedReader bfrPath = new BufferedReader(new InputStreamReader(isPath));
		return bfrPath;
	}
}
