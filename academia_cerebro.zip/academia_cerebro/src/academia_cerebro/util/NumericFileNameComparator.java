package academia_cerebro.util;

import java.io.File;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NumericFileNameComparator implements Comparator<File> {
	/* Expressão regular que irá possibilitar combinações numéricas de 0s e 9s. Irá descartar o elemento vazio. */
	private static Pattern patPrefixoNumerico = Pattern.compile ("([0-9]+)(.*)");
    private static int compareFilenames (String filename1, String filename2) {
        // Comparamos a parte numerica e a parte nao-numerica em separado
        Matcher matcher1 = patPrefixoNumerico.matcher(filename1);
        Matcher matcher2 = patPrefixoNumerico.matcher(filename2);
        if (matcher1.matches() && matcher2.matches()) {
        	/* Comparo só os prefixos numéricos dos arquivos para ordená-los. */
            int ret = Long.valueOf(matcher1.group(1)).compareTo(Long.valueOf(matcher2.group(1)));
            /* retorno do compareTo (-1 = nomes de de arquivos diferentes e x(nome_arq1 ou 2) < y(nome_arq1 ou 2)); 0 = nomes de arquivos iguais; e +1 = nomes de arquivos diferentes somente */
            if (ret != 0) {
            	/* Retorna -1 (x < y) */
                return ret;
            } else {
            	/* Retorno de nome de arquivo igual */
            	return matcher1.group(2).compareToIgnoreCase(matcher2.group(2));
            }
        }
        // Se nao tiver prefixo numerico...
        return filename1.compareToIgnoreCase(filename2);
    }
    @Override
    public int compare(File f1, File f2) {
        if ((f1.getParent() != null && f2.getParent() != null && f1.getParent().equalsIgnoreCase(f2.getParent()))
                || (f1.getParent() == null && f2.getParent() == null))
            return compareFilenames (f1.getName(), f2.getName());
        else
            return f1.compareTo(f2);
    }
}
