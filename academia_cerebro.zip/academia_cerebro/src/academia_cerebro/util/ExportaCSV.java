package academia_cerebro.util;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class ExportaCSV {
	private static final ExportaCSV INSTANCE = new ExportaCSV();
	
	private ExportaCSV() {}
	
	public static ExportaCSV getInstance() {
		return INSTANCE;
	}
	
	public void writeToFileCSV(Map mapaRetorno, String nomeArquivo) {
        try {            
            /*PrintWriter bw = new PrintWriter(new BufferedWriter(new FileWriter(nomeArquivo + ".csv"), 8*1024*1024));*/
            Set set = mapaRetorno.entrySet();
            Iterator it = set.iterator();
            while(it.hasNext()) {
            	Map.Entry entry = (Map.Entry)it.next();
            	System.out.println(entry.getKey() + " - " + entry.getValue());
            }
            
            /*bw.write(mapaRetorno);
            bw.write(';');
            bw.write("IE");
            bw.write(';');
            bw.write("Razão Social");
            bw.write(';');
            bw.write("Tipo do responsável");
            bw.write(';');
            bw.write("Nome Resp.");
            bw.write(';');
            bw.write("Telefone Resp.");
            bw.write(';');
            bw.write("Email Resp.");
            bw.write(';');
            bw.write("Cargo Resp.");
            bw.write(';');
            bw.write('\n');*/
            
           /* for(Iterator itCredAmbt = listaCredenciadosAmbienteTeste.iterator(); itCredAmbt.hasNext();) {
                    registroBean = (RegistroBean) itCredAmbt.next();
                    bw.write(registroBean.getNuCnpj());
                    bw.write(';');
                    bw.write(registroBean.getInscricaoEstadual());
                    bw.write(';');
                    bw.write(registroBean.getRazaoSocial());
                    bw.write(';');
                    bw.write(registroBean.getDataAutorizacao());
                    bw.write(';'); 
                    if (registroBean.getGrupo() != null) {
                        bw.write(registroBean.getGrupo());
                        bw.write(';'); 
                        bw.write(registroBean.getNomeResp());
                        bw.write(';');
                        bw.write(registroBean.getTelefoneResp());
                        bw.write(';');
                        bw.write(registroBean.getEmailResp());
                        bw.write(';');
                        bw.write(registroBean.getCargoResp());        
                    } else {
                        qtdRegistrosResponsaveisNulos++;
                    }    
                bw.write('\n');
            }*/
           // bw.flush();
           // bw.close();
        } catch(Exception e) {//IOException e) {    
            e.printStackTrace();
        } 
    }  
}
