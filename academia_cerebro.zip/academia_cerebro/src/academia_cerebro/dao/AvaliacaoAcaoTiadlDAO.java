package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoAcaoTiadlDAO {
	private Connection conn;
	
	public AvaliacaoAcaoTiadlDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoAcaoTiadlBean avaliacaoAcaoTiadl) throws SQLException {
		int idResult_acao_tiadl = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_acao_tiadl = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_acao_tiadl = "select * from acao_tiadl where id = ?";
		try {
			stmt_acao_tiadl = conn.prepareStatement(sql_acao_tiadl);
			stmt_acao_tiadl.setInt(1, avaliacaoAcaoTiadl.getId_acao_tiadl());

			ResultSet rs_acao_tiadl = stmt_acao_tiadl.executeQuery();
			System.out.println("rs next = " + rs_acao_tiadl.next());
			if(rs_acao_tiadl != null) {
				int idAvaliacaoAcaoTiadl = rs_acao_tiadl.getInt("id");
				avaliacaoAcaoTiadl.setId_acao_tiadl(idAvaliacaoAcaoTiadl);

				idResult_acao_tiadl = avaliacaoAcaoTiadl.getId_acao_tiadl();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_acao_tiadl.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoAcaoTiadl.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoAcaoTiadl = rs_avaliacao_paciente.getInt("id");
				avaliacaoAcaoTiadl.setId_avaliacao(idAvaliacaoAcaoTiadl);

				idResult_avaliacao_paciente = avaliacaoAcaoTiadl.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_acao_tiadl " + "(id_avaliacao,id_acao_tiadl,tempo_execucao_acao)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_acao_tiadl);
			stmt_i.setString(3, avaliacaoAcaoTiadl.getTempo_execucao_acao());
			
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_acao_tiadl != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_acao_tiadl.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
