package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoQuestaoQiDAO {
	private Connection conn;
	
	public AvaliacaoQuestaoQiDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoQuestaoQiBean avaliacaoQuestaoQi) throws SQLException {
		int idResult_questao_qi = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_questao_qi = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_questao_qi = "select * from questao_qi where id = ?";
		try {
			stmt_questao_qi = conn.prepareStatement(sql_questao_qi);
			stmt_questao_qi.setInt(1, avaliacaoQuestaoQi.getId_questao_qi());

			ResultSet rs_questao_qi = stmt_questao_qi.executeQuery();
			System.out.println("rs next = " + rs_questao_qi.next());
			if(rs_questao_qi != null) {
				int idAvaliacaoQuestaoQi = rs_questao_qi.getInt("id");
				avaliacaoQuestaoQi.setId_questao_qi(idAvaliacaoQuestaoQi);

				idResult_questao_qi = avaliacaoQuestaoQi.getId_questao_qi();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_questao_qi.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoQuestaoQi.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoQuestaoQi = rs_avaliacao_paciente.getInt("id");
				avaliacaoQuestaoQi.setId_avaliacao(idAvaliacaoQuestaoQi);

				idResult_avaliacao_paciente = avaliacaoQuestaoQi.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_questao_qi " + "(id_avaliacao,id_questao_qi,resposta_questao_qi)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_questao_qi);
			stmt_i.setString(3, avaliacaoQuestaoQi.getResposta_questao_qi());
			
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_questao_qi != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_questao_qi.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
