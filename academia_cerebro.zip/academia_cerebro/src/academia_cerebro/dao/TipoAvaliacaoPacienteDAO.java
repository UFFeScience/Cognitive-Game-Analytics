package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class TipoAvaliacaoPacienteDAO {
	private Connection conn;
	
	public TipoAvaliacaoPacienteDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(TipoAvaliacaoPacienteBean tipoAvaliacaoPaciente) throws SQLException {
		int idResult_tipo_avaliacao = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_tipo_avaliacao = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_tipo_avaliacao = "select * from tipo_avaliacao where id = ?";
		try {
			stmt_tipo_avaliacao = conn.prepareStatement(sql_tipo_avaliacao);
			stmt_tipo_avaliacao.setInt(1, tipoAvaliacaoPaciente.getId_tipo_avaliacao());
			//stmt.setInt(1, TipoAvaliacaoPaciente.getJogoBean().getId());
			ResultSet rs_tipo_avaliacao = stmt_tipo_avaliacao.executeQuery();
			System.out.println("rs next = " + rs_tipo_avaliacao.next());
			if(rs_tipo_avaliacao != null) {
				int idTipoAvaliacaoPaciente = rs_tipo_avaliacao.getInt("id");
				tipoAvaliacaoPaciente.setId_tipo_avaliacao(idTipoAvaliacaoPaciente);
				//TipoAvaliacaoPaciente.getJogoBean().setId(idTipoAvaliacaoPaciente);
				idResult_tipo_avaliacao = tipoAvaliacaoPaciente.getId_tipo_avaliacao();
				//idResult = TipoAvaliacaoPaciente.getJogoBean().getId();
			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_tipo_avaliacao.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, tipoAvaliacaoPaciente.getId_avaliacao());
			//stmt.setInt(1, TipoAvaliacaoPaciente.getPacienteBean().getId());
			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idTipoAvaliacaoPaciente = rs_avaliacao_paciente.getInt("id");
				tipoAvaliacaoPaciente.setId_avaliacao(idTipoAvaliacaoPaciente);
				//TipoAvaliacaoPaciente.getPacienteBean().setId(idTipoAvaliacaoPaciente);
				idResult_avaliacao_paciente = tipoAvaliacaoPaciente.getId_avaliacao();
				//idResult = TipoAvaliacaoPaciente.getPacienteBean().getId();
			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into tipo_avaliacao_paciente " + "(id_tipo_avaliacao,id_avaliacao,periodo)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_tipo_avaliacao);
			stmt_i.setInt(2, idResult_avaliacao_paciente);
			stmt_i.setString(3, tipoAvaliacaoPaciente.getPeriodo());
			
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_tipo_avaliacao != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_tipo_avaliacao.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}