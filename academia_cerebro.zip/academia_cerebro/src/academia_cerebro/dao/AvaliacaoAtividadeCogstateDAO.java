package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoAtividadeCogstateDAO {
	private Connection conn;
	
	public AvaliacaoAtividadeCogstateDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoAtividadeCogstateBean avaliacaoAtividadeCogstate) throws SQLException {
		int idResult_ativ_cogstate = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_ativ_cogstate = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_ativ_cogstate = "select * from atividade_cogstate where id = ?";
		try {
			stmt_ativ_cogstate = conn.prepareStatement(sql_ativ_cogstate);
			stmt_ativ_cogstate.setInt(1, avaliacaoAtividadeCogstate.getId_atividade_cogstate());

			ResultSet rs_ativ_cogstate = stmt_ativ_cogstate.executeQuery();
			System.out.println("rs next = " + rs_ativ_cogstate.next());
			if(rs_ativ_cogstate != null) {
				int idAvaliacaoAtividadeCogstate = rs_ativ_cogstate.getInt("id");
				avaliacaoAtividadeCogstate.setId_atividade_cogstate(idAvaliacaoAtividadeCogstate);

				idResult_ativ_cogstate = avaliacaoAtividadeCogstate.getId_atividade_cogstate();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_ativ_cogstate.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoAtividadeCogstate.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoAtividadeCogstate = rs_avaliacao_paciente.getInt("id");
				avaliacaoAtividadeCogstate.setId_avaliacao(idAvaliacaoAtividadeCogstate);

				idResult_avaliacao_paciente = avaliacaoAtividadeCogstate.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_atividade_cogstate " + "(id_avaliacao,id_atividade_cogstate,data_teste_realizado)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_ativ_cogstate);
			stmt_i.setString(3, avaliacaoAtividadeCogstate.getData_teste_realizado());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_ativ_cogstate != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_ativ_cogstate.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}