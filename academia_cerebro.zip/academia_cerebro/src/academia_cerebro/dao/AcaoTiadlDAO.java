package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AcaoTiadlDAO {
	private Connection conn;
	
	public AcaoTiadlDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AcaoTiadlBean acaoTiadl) throws SQLException {
		int idResult = 0;
		//PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		//String sql = "select * from questao_tiadl where id = ?";
		
		try {
			/*stmt = conn.prepareStatement(sql);
			stmt.setInt(1, acaoTiadl.getId_questao_tiadl());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idAcaoTiadl = rs.getInt("id");
				acaoTiadl.setId_questao_tiadl(idAcaoTiadl);
				idResult = acaoTiadl.getId_questao_tiadl();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();*/
			
			String sql_i = "insert into acao_tiadl (id_questao_tiadl,descricao_acao) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, acaoTiadl.getId_questao_tiadl());
			stmt_i.setString(2, acaoTiadl.getDescricao_acao());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			//if (stmt != null || stmt_i != null) {
				//stmt.close();
			if (stmt_i != null) {
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
