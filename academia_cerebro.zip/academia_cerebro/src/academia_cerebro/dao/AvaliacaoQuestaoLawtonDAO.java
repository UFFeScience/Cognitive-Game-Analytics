package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoQuestaoLawtonDAO {
	private Connection conn;
	
	public AvaliacaoQuestaoLawtonDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoQuestaoLawtonBean avaliacaoQuestaoLawton) throws SQLException {
		int idResult_questao_lawton = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_questao_lawton = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_questao_lawton = "select * from questao_lawton where id = ?";
		try {
			stmt_questao_lawton = conn.prepareStatement(sql_questao_lawton);
			stmt_questao_lawton.setInt(1, avaliacaoQuestaoLawton.getId_questao_lawton());

			ResultSet rs_questao_lawton = stmt_questao_lawton.executeQuery();
			System.out.println("rs next = " + rs_questao_lawton.next());
			if(rs_questao_lawton != null) {
				int idAvaliacaoQuestaoLawton = rs_questao_lawton.getInt("id");
				avaliacaoQuestaoLawton.setId_questao_lawton(idAvaliacaoQuestaoLawton);

				idResult_questao_lawton = avaliacaoQuestaoLawton.getId_questao_lawton();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_questao_lawton.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoQuestaoLawton.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoQuestaoLawton = rs_avaliacao_paciente.getInt("id");
				avaliacaoQuestaoLawton.setId_avaliacao(idAvaliacaoQuestaoLawton);

				idResult_avaliacao_paciente = avaliacaoQuestaoLawton.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_questao_lawton " + "(id_avaliacao,id_questao_lawton,resposta_questao_lawton)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_questao_lawton);
			stmt_i.setString(3, avaliacaoQuestaoLawton.getResposta_questao_lawton());
			
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_questao_lawton != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_questao_lawton.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
