package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class QuestaoTiadlDAO {
	private Connection conn;
	
	public QuestaoTiadlDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(QuestaoTiadlBean questaoTiadl) throws SQLException {
		int idResult = 0;
		//PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from secao_documento_tiadl where id = ?";
		
		try {
			/*stmt = conn.prepareStatement(sql);
			stmt.setInt(1, questaoTiadl.getId_secao_tiadl());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idQuestaoTiadl = rs.getInt("id");
				questaoTiadl.setId_secao_tiadl(idQuestaoTiadl);
				idResult = questaoTiadl.getId_secao_tiadl();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();*/
			
			String sql_i = "insert into questao_tiadl (id_secao_tiadl,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, questaoTiadl.getId_secao_tiadl());
			stmt_i.setString(2, questaoTiadl.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			/*if (stmt != null || stmt_i != null) {
				stmt.close();*/
			if (stmt_i != null) {
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
