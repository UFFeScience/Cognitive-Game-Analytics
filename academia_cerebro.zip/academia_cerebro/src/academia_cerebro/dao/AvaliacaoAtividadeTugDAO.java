package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoAtividadeTugDAO {
	private Connection conn;
	
	public AvaliacaoAtividadeTugDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoAtividadeTugBean avaliacaoAtividadeTug) throws SQLException {
		int idResult_ativ_tug = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_ativ_tug = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_ativ_tug = "select * from atividade_tug where id = ?";
		try {
			stmt_ativ_tug = conn.prepareStatement(sql_ativ_tug);
			stmt_ativ_tug.setInt(1, avaliacaoAtividadeTug.getId_atividade_tug());

			ResultSet rs_ativ_tug = stmt_ativ_tug.executeQuery();
			System.out.println("rs next = " + rs_ativ_tug.next());
			if(rs_ativ_tug != null) {
				int idAvaliacaoAtividadeTug = rs_ativ_tug.getInt("id");
				avaliacaoAtividadeTug.setId_atividade_tug(idAvaliacaoAtividadeTug);

				idResult_ativ_tug = avaliacaoAtividadeTug.getId_atividade_tug();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_ativ_tug.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoAtividadeTug.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoAtividadeTug = rs_avaliacao_paciente.getInt("id");
				avaliacaoAtividadeTug.setId_avaliacao(idAvaliacaoAtividadeTug);

				idResult_avaliacao_paciente = avaliacaoAtividadeTug.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_atividade_tug " + "(id_avaliacao,id_atividade_tug,resposta,intervalo,tempo_real)" + "values(?,?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_ativ_tug);
			stmt_i.setString(3, avaliacaoAtividadeTug.getResposta());
			stmt_i.setInt(4, avaliacaoAtividadeTug.getIntervalo());
			stmt_i.setString(5, avaliacaoAtividadeTug.getTempo_real());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_ativ_tug != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_ativ_tug.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}