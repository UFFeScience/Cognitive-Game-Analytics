package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoAtividadeIpacDAO {
	private Connection conn;
	
	public AvaliacaoAtividadeIpacDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoAtividadeIpacBean avaliacaoAtividadeIpac) throws SQLException {
		int idResult_ativ_ipac = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_ativ_ipac = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_ativ_ipac = "select * from atividade_ipac where id = ?";
		try {
			stmt_ativ_ipac = conn.prepareStatement(sql_ativ_ipac);
			stmt_ativ_ipac.setInt(1, avaliacaoAtividadeIpac.getId_atividade_ipac());

			ResultSet rs_ativ_ipac = stmt_ativ_ipac.executeQuery();
			System.out.println("rs next = " + rs_ativ_ipac.next());
			if(rs_ativ_ipac != null) {
				int idAvaliacaoAtividadeIpac = rs_ativ_ipac.getInt("id");
				avaliacaoAtividadeIpac.setId_atividade_ipac(idAvaliacaoAtividadeIpac);

				idResult_ativ_ipac = avaliacaoAtividadeIpac.getId_atividade_ipac();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_ativ_ipac.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoAtividadeIpac.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoAtividadeIpac = rs_avaliacao_paciente.getInt("id");
				avaliacaoAtividadeIpac.setId_avaliacao(idAvaliacaoAtividadeIpac);

				idResult_avaliacao_paciente = avaliacaoAtividadeIpac.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_atividade_ipac " + "(id_avaliacao,id_atividade_ipac,valor_dia_semana,valor_minuto_dia,score)" + "values(?,?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_ativ_ipac);
			stmt_i.setString(3, avaliacaoAtividadeIpac.getValor_dia_semana());
			stmt_i.setString(4, avaliacaoAtividadeIpac.getValor_minuto_dia());
			stmt_i.setInt(5, avaliacaoAtividadeIpac.getScore());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_ativ_ipac != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_ativ_ipac.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
