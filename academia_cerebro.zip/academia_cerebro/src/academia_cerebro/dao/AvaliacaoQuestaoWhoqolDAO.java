package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoQuestaoWhoqolDAO {
	private Connection conn;
	
	public AvaliacaoQuestaoWhoqolDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoQuestaoWhoqolBean avaliacaoQuestaoWhoqol) throws SQLException {
		int idResult_questao_whoqol = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_questao_whoqol = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_questao_whoqol = "select * from questao_whoqol where id = ?";
		try {
			stmt_questao_whoqol = conn.prepareStatement(sql_questao_whoqol);
			stmt_questao_whoqol.setInt(1, avaliacaoQuestaoWhoqol.getId_questao_whoqol());

			ResultSet rs_questao_whoqol = stmt_questao_whoqol.executeQuery();
			System.out.println("rs next = " + rs_questao_whoqol.next());
			if(rs_questao_whoqol != null) {
				int idAvaliacaoQuestaoWhoqol = rs_questao_whoqol.getInt("id");
				avaliacaoQuestaoWhoqol.setId_questao_whoqol(idAvaliacaoQuestaoWhoqol);

				idResult_questao_whoqol = avaliacaoQuestaoWhoqol.getId_questao_whoqol();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_questao_whoqol.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoQuestaoWhoqol.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoQuestaoWhoqol = rs_avaliacao_paciente.getInt("id");
				avaliacaoQuestaoWhoqol.setId_avaliacao(idAvaliacaoQuestaoWhoqol);

				idResult_avaliacao_paciente = avaliacaoQuestaoWhoqol.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_questao_whoqol " + "(id_avaliacao,id_questao_whoqol,resposta_questao_whoqol)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_questao_whoqol);
			stmt_i.setString(3, avaliacaoQuestaoWhoqol.getReposta_questao_whoqol());
			
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_questao_whoqol != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_questao_whoqol.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
