package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class ExameCogstateDAO {
	private Connection conn;
	
	public ExameCogstateDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(ExameCogstateBean exameCogstate) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from exame_cognitivo where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, exameCogstate.getId_exc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idExameCogstate = rs.getInt("id");
				exameCogstate.setId_exc(idExameCogstate);
				idResult = exameCogstate.getId_exc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into exame_Cogstate (id_exc) values (?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
