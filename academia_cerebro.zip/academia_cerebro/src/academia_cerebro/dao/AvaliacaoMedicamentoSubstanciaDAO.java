package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoMedicamentoSubstanciaDAO {
	private Connection conn;
	
	public AvaliacaoMedicamentoSubstanciaDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoMedicamentoSubstanciaBean avaliacaoMedicamentoSubstancia) throws SQLException {
		int idResult_mdc_subst = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_mdc_subst = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_mdc_subst = "select * from medicamento_substancia where id = ?";
		try {
			stmt_mdc_subst = conn.prepareStatement(sql_mdc_subst);
			stmt_mdc_subst.setInt(1, avaliacaoMedicamentoSubstancia.getId_medicamento_subst());

			ResultSet rs_mdc_subst = stmt_mdc_subst.executeQuery();
			System.out.println("rs next = " + rs_mdc_subst.next());
			if(rs_mdc_subst != null) {
				int idAvaliacaoMedicamentoSubstancia = rs_mdc_subst.getInt("id");
				avaliacaoMedicamentoSubstancia.setId_medicamento_subst(idAvaliacaoMedicamentoSubstancia);

				idResult_mdc_subst = avaliacaoMedicamentoSubstancia.getId_medicamento_subst();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_mdc_subst.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoMedicamentoSubstancia.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoMedicamentoSubstancia = rs_avaliacao_paciente.getInt("id");
				avaliacaoMedicamentoSubstancia.setId_avaliacao(idAvaliacaoMedicamentoSubstancia);

				idResult_avaliacao_paciente = avaliacaoMedicamentoSubstancia.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_medicamento_substancia " + "(id_avaliacao,id_medicamento_subst,dosagem,tempo_uso)" + "values(?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_mdc_subst);
			stmt_i.setFloat(3, avaliacaoMedicamentoSubstancia.getDosagem());
			stmt_i.setString(4, avaliacaoMedicamentoSubstancia.getTempo_uso());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_mdc_subst != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_mdc_subst.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}