package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class QuestaoKatzDAO {
	private Connection conn;
	
	public QuestaoKatzDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(QuestaoKatzBean questaoKatz) throws SQLException {
		int idResult = 0;
		//PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		//String sql = "select * from secao_documento_katz where id = ?";
		
		try {
			/*stmt = conn.prepareStatement(sql);
			stmt.setInt(1, questaoKatz.getId_secao_katz());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idQuestaoKatz = rs.getInt("id");
				questaoKatz.setId_secao_katz(idQuestaoKatz);
				idResult = questaoKatz.getId_secao_katz();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();*/
			
			String sql_i = "insert into questao_katz (id_secao_katz,pergunta) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, questaoKatz.getId_secao_katz());
			stmt_i.setString(2, questaoKatz.getPergunta());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			//if (stmt != null || stmt_i != null) {
			if (stmt_i != null) {
				//stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
