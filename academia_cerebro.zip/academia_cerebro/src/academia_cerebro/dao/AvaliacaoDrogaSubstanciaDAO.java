package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoDrogaSubstanciaDAO {
	private Connection conn;
	
	public AvaliacaoDrogaSubstanciaDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoDrogaSubstanciaBean avaliacaoDrogaSubstancia) throws SQLException {
		int idResult_drg_subst = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_drg_subst = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_drg_subst = "select * from droga_substancia where id = ?";
		try {
			stmt_drg_subst = conn.prepareStatement(sql_drg_subst);
			stmt_drg_subst.setInt(1, avaliacaoDrogaSubstancia.getId_droga_substancia());

			ResultSet rs_drg_subst = stmt_drg_subst.executeQuery();
			System.out.println("rs next = " + rs_drg_subst.next());
			if(rs_drg_subst != null) {
				int idAvaliacaoDrogaSubstancia = rs_drg_subst.getInt("id");
				avaliacaoDrogaSubstancia.setId_droga_substancia(idAvaliacaoDrogaSubstancia);

				idResult_drg_subst = avaliacaoDrogaSubstancia.getId_droga_substancia();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_drg_subst.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoDrogaSubstancia.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoDrogaSubstancia = rs_avaliacao_paciente.getInt("id");
				avaliacaoDrogaSubstancia.setId_avaliacao(idAvaliacaoDrogaSubstancia);

				idResult_avaliacao_paciente = avaliacaoDrogaSubstancia.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_droga_substancia " + "(id_avaliacao,id_droga_substancia,resposta,quantidade)" + "values(?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_drg_subst);
			stmt_i.setString(3, avaliacaoDrogaSubstancia.getResposta());
			stmt_i.setInt(4, avaliacaoDrogaSubstancia.getQuantidade());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_drg_subst != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_drg_subst.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}