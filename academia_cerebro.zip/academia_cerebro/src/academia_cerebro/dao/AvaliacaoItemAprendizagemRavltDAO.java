package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoItemAprendizagemRavltDAO {
	private Connection conn;
	
	public AvaliacaoItemAprendizagemRavltDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoItemAprendizagemRavltBean avaliacaoItemAprendizagemRavlt) throws SQLException {
		int idResult_it_aprz_ravlt = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_it_aprz_ravlt = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_it_aprz_ravlt = "select * from item_aprendizagem_ravlt where id = ?";
		try {
			stmt_it_aprz_ravlt = conn.prepareStatement(sql_it_aprz_ravlt);
			stmt_it_aprz_ravlt.setInt(1, avaliacaoItemAprendizagemRavlt.getId_item_aprendizagem_ravlt());

			ResultSet rs_it_aprz_ravlt = stmt_it_aprz_ravlt.executeQuery();
			System.out.println("rs next = " + rs_it_aprz_ravlt.next());
			if(rs_it_aprz_ravlt != null) {
				int idAvaliacaoItemAprendizagemRavlt = rs_it_aprz_ravlt.getInt("id");
				avaliacaoItemAprendizagemRavlt.setId_item_aprendizagem_ravlt(idAvaliacaoItemAprendizagemRavlt);

				idResult_it_aprz_ravlt = avaliacaoItemAprendizagemRavlt.getId_item_aprendizagem_ravlt();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_it_aprz_ravlt.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoItemAprendizagemRavlt.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoItemAprendizagemRavlt = rs_avaliacao_paciente.getInt("id");
				avaliacaoItemAprendizagemRavlt.setId_avaliacao(idAvaliacaoItemAprendizagemRavlt);

				idResult_avaliacao_paciente = avaliacaoItemAprendizagemRavlt.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_item_aprendizagem_ravlt " + "(id_avaliacao,id_atividade_camcog,resposta)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_it_aprz_ravlt);
			stmt_i.setString(3, avaliacaoItemAprendizagemRavlt.getResposta());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_it_aprz_ravlt != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_it_aprz_ravlt.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}