package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class OpcaoMiniMentalDAO {
	private Connection conn;
	
	public OpcaoMiniMentalDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(OpcaoMiniMentalBean opcaoMiniMental) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from escolha_mini_mental where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, opcaoMiniMental.getId_esc_mini_mental());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idOpcaoMiniMental = rs.getInt("id");
				opcaoMiniMental.setId_esc_mini_mental(idOpcaoMiniMental);
				idResult = opcaoMiniMental.getId_esc_mini_mental();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into opcao_mini_mental (id_esc_mini_mental,is_correct) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setBoolean(2, opcaoMiniMental.getIs_correct());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
