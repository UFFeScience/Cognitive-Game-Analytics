package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoQuestaoGdsDAO {
	private Connection conn;
	
	public AvaliacaoQuestaoGdsDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoQuestaoGdsBean avaliacaoQuestaoGds) throws SQLException {
		int idResult_questao_gds = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_questao_gds = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_questao_gds = "select * from questao_gds where id = ?";
		try {
			stmt_questao_gds = conn.prepareStatement(sql_questao_gds);
			stmt_questao_gds.setInt(1, avaliacaoQuestaoGds.getId_questao_gds());

			ResultSet rs_questao_gds = stmt_questao_gds.executeQuery();
			System.out.println("rs next = " + rs_questao_gds.next());
			if(rs_questao_gds != null) {
				int idAvaliacaoQuestaoGds = rs_questao_gds.getInt("id");
				avaliacaoQuestaoGds.setId_questao_gds(idAvaliacaoQuestaoGds);

				idResult_questao_gds = avaliacaoQuestaoGds.getId_questao_gds();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_questao_gds.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoQuestaoGds.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoQuestaoGds = rs_avaliacao_paciente.getInt("id");
				avaliacaoQuestaoGds.setId_avaliacao(idAvaliacaoQuestaoGds);

				idResult_avaliacao_paciente = avaliacaoQuestaoGds.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_questao_gds " + "(id_avaliacao,id_questao_gds,resposta_questao_gds)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_questao_gds);
			stmt_i.setString(3, avaliacaoQuestaoGds.getResposta_questao_gds());
			
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_questao_gds != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_questao_gds.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}