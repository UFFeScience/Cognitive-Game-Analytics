package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;
import academia_cerebro.util.Util;

public class AvaliacaoPacienteDAO {
	private Connection conn;
	
	public AvaliacaoPacienteDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoPacienteBean avaliacaoPaciente) throws SQLException {
		int idResult = 0;
		//PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		//String sql = "select * from sessao where id = ?";
		try {
			/*stmt = conn.prepareStatement(sql);
			stmt.setInt(1, avaliacaoPaciente.getId_sessao_jogo());
			//stmt.setInt(1, avaliacaoPaciente.getSessaoBean().getId());
			ResultSet rs = stmt.executeQuery();
			System.out.println("rs next = " + rs.next());
			if(rs != null) {
				int idAvaliacaoPaciente = rs.getInt("id");
				avaliacaoPaciente.setId_sessao_jogo(idAvaliacaoPaciente);
				//AvaliacaoPaciente.getJogoBean().setId(idAvaliacaoPaciente);
				idResult = avaliacaoPaciente.getId_sessao_jogo();
				//idResult = AvaliacaoPaciente.getJogoBean().getId();
			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs.close();*/
			
			//String sql_i = "insert into avaliacao_paciente " + "(trail_a,trail_b,hits,cr,fluencia,id_sessao_jogo)" + "values(?,?,?,?,?,?)";
			String sql_i = "insert into avaliacao_paciente " + "(trail_a, trail_a_segundos, hits, cr, trail_b, trail_b_segundos, fluencia)" + "values(?,?,?,?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setTime(1, Util.convertStringToTime(avaliacaoPaciente.getTrail_a()));
			stmt_i.setInt(2, avaliacaoPaciente.getTrail_a_segundos());
			stmt_i.setInt(3, avaliacaoPaciente.getHits());
			stmt_i.setInt(4, avaliacaoPaciente.getCr());
			stmt_i.setTime(5, Util.convertStringToTime(avaliacaoPaciente.getTrail_b()));
			stmt_i.setInt(6, avaliacaoPaciente.getTrail_b_segundos());
			stmt_i.setInt(7, avaliacaoPaciente.getFluencia());
			//stmt_i.setInt(1, idResult);
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			//if (stmt != null || stmt_i != null) {
			if (stmt_i != null) {
				//stmt.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
