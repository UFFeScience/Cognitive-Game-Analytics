package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoItemMiniMentalDAO {
	private Connection conn;
	
	public AvaliacaoItemMiniMentalDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoItemMiniMentalBean avaliacaoItemMiniMental) throws SQLException {
		int idResult_it_mini_mental = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_it_mini_mental = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_it_mini_mental = "select * from item_mini_mental where id = ?";
		try {
			stmt_it_mini_mental = conn.prepareStatement(sql_it_mini_mental);
			stmt_it_mini_mental.setInt(1, avaliacaoItemMiniMental.getId_item_mini_mental());

			ResultSet rs_it_mini_mental = stmt_it_mini_mental.executeQuery();
			System.out.println("rs next = " + rs_it_mini_mental.next());
			if(rs_it_mini_mental != null) {
				int idAvaliacaoItemMiniMental = rs_it_mini_mental.getInt("id");
				avaliacaoItemMiniMental.setId_item_mini_mental(idAvaliacaoItemMiniMental);

				idResult_it_mini_mental = avaliacaoItemMiniMental.getId_item_mini_mental();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_it_mini_mental.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoItemMiniMental.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoItemMiniMental = rs_avaliacao_paciente.getInt("id");
				avaliacaoItemMiniMental.setId_avaliacao(idAvaliacaoItemMiniMental);

				idResult_avaliacao_paciente = avaliacaoItemMiniMental.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_item_mini_mental " + "(id_avaliacao,id_item_mini_mental)" + "values(?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_it_mini_mental);
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_it_mini_mental != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_it_mini_mental.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}