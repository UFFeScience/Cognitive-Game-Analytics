package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class DocumentoTiadlDAO {
	private Connection conn;
	
	public DocumentoTiadlDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(DocumentoTiadlBean docTiadl) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from exame_tiadl where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, docTiadl.getId_exc_tiadl());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idDocTiadl = rs.getInt("id");
				docTiadl.setId_exc_tiadl(idDocTiadl);
				idResult = docTiadl.getId_exc_tiadl();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into documento_tiadl (id_exc_,responsavel,data_criacao) values (?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, docTiadl.getResponsavel());
			stmt_i.setString(3, docTiadl.getData_criacao());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
