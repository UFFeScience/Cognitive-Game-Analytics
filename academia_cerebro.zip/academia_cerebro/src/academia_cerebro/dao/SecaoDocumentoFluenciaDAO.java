package academia_cerebro.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class SecaoDocumentoFluenciaDAO {
	private Connection conn;
	
	public SecaoDocumentoFluenciaDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(SecaoDocumentoFluenciaBean secaoDocFluencia) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_fluencia where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDocFluencia.getId_doc_fluencia());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idsecaoDocFluencia = rs.getInt("id");
				secaoDocFluencia.setId_doc_fluencia(idsecaoDocFluencia);
				idResult = secaoDocFluencia.getId_doc_fluencia();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_ (id_doc_fluencia,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDocFluencia.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
