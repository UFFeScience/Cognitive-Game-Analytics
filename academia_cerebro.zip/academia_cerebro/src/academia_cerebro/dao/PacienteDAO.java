package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;
import academia_cerebro.util.Util;

public class PacienteDAO {
	private Connection conn;
	
	public PacienteDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(PacienteBean paciente) throws SQLException {
		String sql = "insert into paciente " + "(numero,nome,contato_previo,genero,escolaridade_anos,idade,atividade_memoria,situacao,grupo,altura,peso,imc,qi,dt_nasc)" + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			stmt.setInt(1, paciente.getNumero());
			stmt.setString(2, paciente.getNome());
			stmt.setString(3, paciente.getContato_previo());
			stmt.setString(4, paciente.getGenero());
			stmt.setInt(5, paciente.getEscolaridade_anos());
			stmt.setInt(6, paciente.getIdade());
			stmt.setString(7, paciente.getAtividade_memoria());
			stmt.setString(8, paciente.getSituacao());
			stmt.setString(9, paciente.getGrupo());
			stmt.setInt(10, paciente.getAltura());
			stmt.setInt(11, paciente.getPeso());
			stmt.setInt(12, paciente.getImc());
			stmt.setString(13, paciente.getQi());
			stmt.setTimestamp(14, Util.convertStringToTimestamp(paciente.getDt_nasc()));

			stmt.execute();
			stmt.close();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				conn.close();
			}
		}
	}	
}
