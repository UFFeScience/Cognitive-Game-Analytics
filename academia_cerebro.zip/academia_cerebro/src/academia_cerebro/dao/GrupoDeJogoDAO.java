package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class GrupoDeJogoDAO {
	private Connection conn;
	
	public GrupoDeJogoDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(GrupoDeJogoBean grupoDeJogo) throws SQLException {
		String sql = "insert into grupo_de_jogo (nome) values(?)";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, grupoDeJogo.getNome());
			stmt.execute();
			stmt.close();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if ( conn != null ) {
				conn.close();
			}
		}
	}
}
