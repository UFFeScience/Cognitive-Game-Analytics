package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.SecaoDocumentoExamesBean;
import academia_cerebro.util.ConnectionFactory;

public class AcademiaCerebroDAO {
	private Connection conn;
	
	public AcademiaCerebroDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void inserirSecaoDocumentoCamcog(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_camcog where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_camcog (id_doc_camcog,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoIpac(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_ipac where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_ipac (id_doc_ipac,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoGds(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_gds where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_gds (id_doc_gds,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoKatz(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_katz where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_katz (id_doc_katz,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoLawton(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_lawton where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_lawton (id_doc_lawton,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoQi(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_qi where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_qi (id_doc_qi,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoTiadl(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_tiadl where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_tiadl (id_doc_tiadl,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoCogstate(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_cogstate where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_cogstate (id_doc_cogstate,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoMiniMental(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_mini_mental where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_mini_mental (id_doc_mini_mental,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoSubstancia(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_substancia where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_substancia (id_doc_substancia,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	
	public void inserirSecaoDocumentoTug(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_tug where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_tug (id_doc_tug,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoFluencia(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_fluencia where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_fluencia (id_doc_fluencia,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoWhoqol(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_whoqol where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_whoqol (id_doc_whoqol,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoTrailMaking(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_trail where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_trail (id_doc_trail,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void inserirSecaoDocumentoRavlt(SecaoDocumentoExamesBean secaoDoc) throws SQLException {
		
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_ravlt where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDoc.getId_doc());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDoc = rs.getInt("id");
				secaoDoc.setId_doc(idSecaoDoc);
				idResult = secaoDoc.getId_doc();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_ravlt (id_doc_ravlt,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDoc.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
	
}
