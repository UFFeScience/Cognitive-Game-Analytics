package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class JogoDAO {
	private Connection conn;
	
	public JogoDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(JogoBean jogo) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from grupo_de_jogo where id = ?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, jogo.getId_grupodejogo());
			//stmt.setInt(1, jogo.getGrupoJogoBean().getId());
			ResultSet rs = stmt.executeQuery();
			System.out.println("rs next = " + rs.next());
			if(rs != null) {
				int idJogo = rs.getInt("id");
				jogo.setId_grupodejogo(idJogo);
				//jogo.getGrupoJogoBean().setId(idJogo);
				idResult = jogo.getId_grupodejogo();
				System.out.println("idResult = " + idResult);
				//idResult = jogo.getGrupoJogoBean().getId();
			} else {
				System.out.println("Cliente nao Encontrado");
			}
			rs.close();
			
			String sql_i = "insert into jogo " + "(nome,unidade_thresold,id_grupodejogo,termo_original)" + "values(?,?,?,?)";
			
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setString(1, jogo.getNome());
			stmt_i.setString(2, jogo.getUnidade_thresold());
			stmt_i.setInt(3, idResult);
			stmt_i.setString(4, jogo.getTermo_original());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
