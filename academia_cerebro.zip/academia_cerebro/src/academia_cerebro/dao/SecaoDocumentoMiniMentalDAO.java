package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class SecaoDocumentoMiniMentalDAO {
	private Connection conn;
	
	public SecaoDocumentoMiniMentalDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(SecaoDocumentoMiniMentalBean secaoDocMiniMental) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from documento_mini_mental where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, secaoDocMiniMental.getId_doc_mini_mental());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idSecaoDocMiniMental = rs.getInt("id");
				secaoDocMiniMental.setId_doc_mini_mental(idSecaoDocMiniMental);
				idResult = secaoDocMiniMental.getId_doc_mini_mental();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into secao_documento_mini_mental (id_doc_mini_mental,titulo) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, secaoDocMiniMental.getTitulo());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
