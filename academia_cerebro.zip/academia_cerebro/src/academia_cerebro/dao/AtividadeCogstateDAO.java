package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AtividadeCogstateDAO {
	private Connection conn;
	
	public AtividadeCogstateDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AtividadeCogstateBean atividadeCogstate) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from secao_documento_cogstate where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, atividadeCogstate.getId_secao_cogstate());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idAtividadeCogstate = rs.getInt("id");
				atividadeCogstate.setId_secao_cogstate(idAtividadeCogstate);
				idResult = atividadeCogstate.getId_secao_cogstate();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into atividade_cogstate (id_secao_cogstate,descricao_teste) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.setString(2, atividadeCogstate.getDescricao_teste());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
