package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AtividadeCamcogDAO {
	private Connection conn;
	
	public AtividadeCamcogDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AtividadeCamcogBean atividadeCamcog) throws SQLException {
		int idResult = 0;
		//PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		//String sql = "select * from secao_documento_camcog where id = ?";
		
		try {
			/*stmt = conn.prepareStatement(sql);
			stmt.setInt(1, atividadeCamcog.getId_secao_camcog());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idAtividadeCamcog = rs.getInt("id");
				atividadeCamcog.setId_secao_camcog(idAtividadeCamcog);
				idResult = atividadeCamcog.getId_secao_camcog();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();*/
			
			String sql_i = "insert into atividade_camcog (id_secao_camcog,descricao) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, atividadeCamcog.getId_secao_camcog());
			stmt_i.setString(2, atividadeCamcog.getDescricao());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			//if (stmt != null || stmt_i != null) {
				//stmt.close();
			if (stmt_i != null) {
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
