package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoAtividadeFluenciaDAO {
	private Connection conn;
	
	public AvaliacaoAtividadeFluenciaDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoAtividadeFluenciaBean avaliacaoAtividadeFluencia) throws SQLException {
		int idResult_ativ_fluencia = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_ativ_fluencia = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_ativ_fluencia = "select * from atividade_fluencia where id = ?";
		try {
			stmt_ativ_fluencia = conn.prepareStatement(sql_ativ_fluencia);
			stmt_ativ_fluencia.setInt(1, avaliacaoAtividadeFluencia.getId_atividade_fluencia());

			ResultSet rs_ativ_fluencia = stmt_ativ_fluencia.executeQuery();
			System.out.println("rs next = " + rs_ativ_fluencia.next());
			if(rs_ativ_fluencia != null) {
				int idAvaliacaoAtividadeFluencia = rs_ativ_fluencia.getInt("id");
				avaliacaoAtividadeFluencia.setId_atividade_fluencia(idAvaliacaoAtividadeFluencia);

				idResult_ativ_fluencia = avaliacaoAtividadeFluencia.getId_atividade_fluencia();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_ativ_fluencia.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoAtividadeFluencia.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoAtividadeFluencia = rs_avaliacao_paciente.getInt("id");
				avaliacaoAtividadeFluencia.setId_avaliacao(idAvaliacaoAtividadeFluencia);

				idResult_avaliacao_paciente = avaliacaoAtividadeFluencia.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_atividade_fluencia " + "(id_avaliacao,id_atividade_fluencia,data_realizacao_teste,score)" + "values(?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_ativ_fluencia);
			stmt_i.setString(3, avaliacaoAtividadeFluencia.getData_realizacao_teste());
			stmt_i.setInt(4, avaliacaoAtividadeFluencia.getScore());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_ativ_fluencia != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_ativ_fluencia.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}