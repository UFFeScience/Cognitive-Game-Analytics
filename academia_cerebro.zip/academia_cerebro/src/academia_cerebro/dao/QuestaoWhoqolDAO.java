package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class QuestaoWhoqolDAO {
	private Connection conn;
	
	public QuestaoWhoqolDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(QuestaoWhoqolBean questaoWhoqol) throws SQLException {
		int idResult = 0;
		//PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from secao_documento_whoqol where id = ?";
		
		try {
			/*stmt = conn.prepareStatement(sql);
			stmt.setInt(1, questaoWhoqol.getId_secao_whoqol());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idQuestaoWhoqol = rs.getInt("id");
				questaoWhoqol.setId_secao_whoqol(idQuestaoWhoqol);
				idResult = questaoWhoqol.getId_secao_whoqol();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();*/
			
			String sql_i = "insert into questao_whoqol (id_secao_whoqol,pergunta) values (?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			//stmt_i.setInt(1, idResult);
			stmt_i.setInt(1, questaoWhoqol.getId_secao_whoqol());
			stmt_i.setString(2, questaoWhoqol.getPergunta());
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			//if (stmt != null || stmt_i != null) {
			//	stmt.close();
			if (stmt_i != null) {
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}