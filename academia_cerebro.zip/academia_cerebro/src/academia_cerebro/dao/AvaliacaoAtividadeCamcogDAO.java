package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoAtividadeCamcogDAO {
	private Connection conn;
	
	public AvaliacaoAtividadeCamcogDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoAtividadeCamcogBean avaliacaoAtividadeCamcog) throws SQLException {
		int idResult_ativ_camcog = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_ativ_camcog = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_ativ_camcog = "select * from atividade_camcog where id = ?";
		try {
			stmt_ativ_camcog = conn.prepareStatement(sql_ativ_camcog);
			stmt_ativ_camcog.setInt(1, avaliacaoAtividadeCamcog.getId_atividade_camcog());

			ResultSet rs_ativ_camcog = stmt_ativ_camcog.executeQuery();
			System.out.println("rs next = " + rs_ativ_camcog.next());
			if(rs_ativ_camcog != null) {
				int idAvaliacaoAtividadeCamcog = rs_ativ_camcog.getInt("id");
				avaliacaoAtividadeCamcog.setId_atividade_camcog(idAvaliacaoAtividadeCamcog);

				idResult_ativ_camcog = avaliacaoAtividadeCamcog.getId_atividade_camcog();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_ativ_camcog.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoAtividadeCamcog.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoAtividadeCamcog = rs_avaliacao_paciente.getInt("id");
				avaliacaoAtividadeCamcog.setId_avaliacao(idAvaliacaoAtividadeCamcog);

				idResult_avaliacao_paciente = avaliacaoAtividadeCamcog.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_atividade_camcog " + "(id_avaliacao,id_atividade_camcog,resposta,score)" + "values(?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_ativ_camcog);
			stmt_i.setString(3, avaliacaoAtividadeCamcog.getResposta());
			stmt_i.setInt(4, avaliacaoAtividadeCamcog.getScore());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_ativ_camcog != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_ativ_camcog.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}

