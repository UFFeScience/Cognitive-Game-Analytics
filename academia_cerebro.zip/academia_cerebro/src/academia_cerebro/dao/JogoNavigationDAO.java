package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class JogoNavigationDAO extends JogoDAO {
	private Connection conn;
	
	public JogoNavigationDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(JogoNavigationBean jogoNavigation) throws SQLException {
		int idResult = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt_i = null;
		String sql = "select * from jogo where id = ?";
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, jogoNavigation.getId_jogo());
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				int idJogoNavigation = rs.getInt("id");
				jogoNavigation.setId_jogo(idJogoNavigation);
				idResult = jogoNavigation.getId_jogo();
			} else {
				System.out.println("Jogo nao Encontrado!!!");
			}
			rs.close();
			
			String sql_i = "insert into jogo_navigation (id_jogo) values (?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResult);
			stmt_i.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null || stmt_i != null) {
				stmt.close();
				stmt_i.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
	}
}
