package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;
import academia_cerebro.util.Util;

public class SessaoJogoDAO {
	private Connection conn;
	
	public SessaoJogoDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(SessaoJogoBean sessaoJogo) throws SQLException {
		int idResultJogo = 0;
		int idResultPaciente = 0;
		PreparedStatement stmt_jogo = null;
		PreparedStatement stmt_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_jogo = "select * from jogo where id = ?";
		try {
			stmt_jogo = conn.prepareStatement(sql_jogo);
			stmt_jogo.setInt(1, sessaoJogo.getId_jogo());
			//stmt.setInt(1, sessaoJogo.getJogoBean().getId());
			ResultSet rs_jogo = stmt_jogo.executeQuery();
			System.out.println("rs next = " + rs_jogo.next());
			if(rs_jogo != null) {
				int idSessaoJogo = rs_jogo.getInt("id");
				sessaoJogo.setId_jogo(idSessaoJogo);
				//sessaoJogo.getJogoBean().setId(idSessaoJogo);
				idResultJogo = sessaoJogo.getId_jogo();
				//idResult = sessaoJogo.getJogoBean().getId();
			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_jogo.close();
			
			String sql_paciente = "select * from paciente where id = ?";
			stmt_paciente = conn.prepareStatement(sql_paciente);
			stmt_paciente.setInt(1, sessaoJogo.getId_paciente());
			//stmt.setInt(1, sessaoJogo.getPacienteBean().getId());
			ResultSet rs_paciente = stmt_paciente.executeQuery();
			System.out.println("rs next = " + rs_paciente.next());
			if(rs_paciente != null) {
				int idSessaoJogo = rs_paciente.getInt("id");
				sessaoJogo.setId_paciente(idSessaoJogo);
				//sessaoJogo.getPacienteBean().setId(idSessaoJogo);
				idResultPaciente = sessaoJogo.getId_paciente();
				//idResult = sessaoJogo.getPacienteBean().getId();
			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_paciente.close();
						
			String sql_i = "insert into sessao " + "(id_paciente,id_jogo,id_avaliacao,data_local,tempo,z_score,hora,thresold,stars_awarded)" + "values(?,?,?,?,?,?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			stmt_i.setInt(1, idResultPaciente);
			stmt_i.setInt(2, idResultJogo);
			if ( sessaoJogo.getId_avaliacao() != null ) {
				stmt_i.setInt(3, sessaoJogo.getId_avaliacao());
			} else {
				stmt_i.setNull(3, Types.INTEGER);
			}
			stmt_i.setTimestamp(4, Util.convertStringToTimestampSessaoJogo(sessaoJogo.getData_local()));
			stmt_i.setString(5, sessaoJogo.getTempo());
			stmt_i.setDouble(6, sessaoJogo.getZ_score());
			stmt_i.setString(7, sessaoJogo.getHora());
			stmt_i.setDouble(8, sessaoJogo.getThresold());
			stmt_i.setInt(9, sessaoJogo.getStars());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_jogo != null || stmt_paciente != null ||stmt_i != null) {
				stmt_jogo.close();
				stmt_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}
