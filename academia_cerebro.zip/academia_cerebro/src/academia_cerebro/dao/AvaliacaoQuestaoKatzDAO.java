package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoQuestaoKatzDAO {
	private Connection conn;
	
	public AvaliacaoQuestaoKatzDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoQuestaoKatzBean avaliacaoQuestaoKatz) throws SQLException {
		int idResult_questao_katz = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_questao_katz = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_questao_gds = "select * from questao_katz where id = ?";
		try {
			stmt_questao_katz = conn.prepareStatement(sql_questao_gds);
			stmt_questao_katz.setInt(1, avaliacaoQuestaoKatz.getId_questao_katz());

			ResultSet rs_questao_katz = stmt_questao_katz.executeQuery();
			System.out.println("rs next = " + rs_questao_katz.next());
			if(rs_questao_katz != null) {
				int idAvaliacaoQuestaoKatz = rs_questao_katz.getInt("id");
				avaliacaoQuestaoKatz.setId_questao_katz(idAvaliacaoQuestaoKatz);

				idResult_questao_katz = avaliacaoQuestaoKatz.getId_questao_katz();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_questao_katz.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoQuestaoKatz.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoQuestaoKatz = rs_avaliacao_paciente.getInt("id");
				avaliacaoQuestaoKatz.setId_avaliacao(idAvaliacaoQuestaoKatz);

				idResult_avaliacao_paciente = avaliacaoQuestaoKatz.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_questao_katz " + "(id_avaliacao,id_questao_katz,resposta_questao_katz)" + "values(?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_questao_katz);
			stmt_i.setString(3, avaliacaoQuestaoKatz.getResposta_questao_katz());
			
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_questao_katz != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_questao_katz.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}