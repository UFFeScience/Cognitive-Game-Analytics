package academia_cerebro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import academia_cerebro.bean.*;
import academia_cerebro.util.ConnectionFactory;

public class AvaliacaoAtividadeTrailMakingDAO {
	private Connection conn;
	
	public AvaliacaoAtividadeTrailMakingDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public void insert(AvaliacaoAtividadeTrailMakingBean avaliacaoAtividadeTrailMaking) throws SQLException {
		int idResult_ativ_trail = 0;
		int idResult_avaliacao_paciente = 0;
		PreparedStatement stmt_ativ_trail = null;
		PreparedStatement stmt_avaliacao_paciente = null;
		PreparedStatement stmt_i = null;
		String sql_ativ_trail = "select * from atividade_trail_making where id = ?";
		try {
			stmt_ativ_trail = conn.prepareStatement(sql_ativ_trail);
			stmt_ativ_trail.setInt(1, avaliacaoAtividadeTrailMaking.getId_atividade_trail());

			ResultSet rs_ativ_trail = stmt_ativ_trail.executeQuery();
			System.out.println("rs next = " + rs_ativ_trail.next());
			if(rs_ativ_trail != null) {
				int idAvaliacaoAtividadeTrailMaking = rs_ativ_trail.getInt("id");
				avaliacaoAtividadeTrailMaking.setId_atividade_trail(idAvaliacaoAtividadeTrailMaking);

				idResult_ativ_trail = avaliacaoAtividadeTrailMaking.getId_atividade_trail();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_ativ_trail.close();
			
			String sql_avaliacao_paciente = "select * from avaliacao_paciente where id = ?";
			stmt_avaliacao_paciente = conn.prepareStatement(sql_avaliacao_paciente);
			stmt_avaliacao_paciente.setInt(1, avaliacaoAtividadeTrailMaking.getId_avaliacao());

			ResultSet rs_avaliacao_paciente = stmt_avaliacao_paciente.executeQuery();
			System.out.println("rs next = " + rs_avaliacao_paciente.next());
			if(rs_avaliacao_paciente != null) {
				int idAvaliacaoAtividadeTrailMaking = rs_avaliacao_paciente.getInt("id");
				avaliacaoAtividadeTrailMaking.setId_avaliacao(idAvaliacaoAtividadeTrailMaking);

				idResult_avaliacao_paciente = avaliacaoAtividadeTrailMaking.getId_avaliacao();

			} else {
				System.out.println("Cliente nao Encontrado");
			}
			
			rs_avaliacao_paciente.close();
						
			String sql_i = "insert into avaliacao_atividade_trail_making " + "(id_avaliacao,id_atividade_trail,data_avaliacao,tempo_score)" + "values(?,?,?,?)";
			stmt_i = conn.prepareStatement(sql_i);
			
			stmt_i.setInt(1, idResult_avaliacao_paciente);
			stmt_i.setInt(2, idResult_ativ_trail);
			stmt_i.setString(3, avaliacaoAtividadeTrailMaking.getData_avaliacao());
			stmt_i.setString(4, avaliacaoAtividadeTrailMaking.getTempo_score());
			stmt_i.execute();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt_ativ_trail != null || stmt_avaliacao_paciente != null ||stmt_i != null) {
				stmt_ativ_trail.close();
				stmt_avaliacao_paciente.close();
				stmt_i.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
}