package academia_cerebro.bean;

public class SecaoDocumentoFluenciaBean {
	private Integer id;
	private Integer id_doc_fluencia;
	private DocumentoFluenciaBean documentoFluenciaBean = new DocumentoFluenciaBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_fluencia() {
		return id_doc_fluencia;
	}
	public void setId_doc_fluencia(Integer id_doc_fluencia) {
		this.id_doc_fluencia = id_doc_fluencia;
	}
	public DocumentoFluenciaBean getDocumentoFluenciaBean() {
		return documentoFluenciaBean;
	}
	public void setDocumentoFluenciaBean(DocumentoFluenciaBean documentoFluenciaBean) {
		this.documentoFluenciaBean = documentoFluenciaBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
