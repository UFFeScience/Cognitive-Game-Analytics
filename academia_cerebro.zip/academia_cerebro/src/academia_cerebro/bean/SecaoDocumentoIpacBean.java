package academia_cerebro.bean;

public class SecaoDocumentoIpacBean {
	private Integer id;
	private Integer id_doc_ipac;
	private DocumentoIpacBean documentoIpacBean = new DocumentoIpacBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_ipac() {
		return id_doc_ipac;
	}
	public void setId_doc_ipac(Integer id_doc_ipac) {
		this.id_doc_ipac = id_doc_ipac;
	}
	public DocumentoIpacBean getDocumentoIpacBean() {
		return documentoIpacBean;
	}
	public void setDocumentoIpacBean(DocumentoIpacBean documentoIpacBean) {
		this.documentoIpacBean = documentoIpacBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
