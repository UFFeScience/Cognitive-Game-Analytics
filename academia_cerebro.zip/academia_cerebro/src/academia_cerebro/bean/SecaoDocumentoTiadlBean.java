package academia_cerebro.bean;

public class SecaoDocumentoTiadlBean {
	private Integer id;
	private Integer id_doc_tiadl;
	private DocumentoTiadlBean documentoTiadlBean = new DocumentoTiadlBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_tiadl() {
		return id_doc_tiadl;
	}
	public void setId_doc_tiadl(Integer id_doc_tiadl) {
		this.id_doc_tiadl = id_doc_tiadl;
	}
	public DocumentoTiadlBean getDocumentoTiadlBean() {
		return documentoTiadlBean;
	}
	public void setDocumentoTiadlBean(DocumentoTiadlBean documentoTiadlBean) {
		this.documentoTiadlBean = documentoTiadlBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	private String titulo;
}
