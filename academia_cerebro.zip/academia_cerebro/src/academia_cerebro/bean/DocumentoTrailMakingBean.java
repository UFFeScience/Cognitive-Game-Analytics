package academia_cerebro.bean;

public class DocumentoTrailMakingBean {
	private Integer id;
	private Integer id_exc_trail;
	private ExameTrailMakingBean exameTrailMakingBean = new ExameTrailMakingBean(); 
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_trail() {
		return id_exc_trail;
	}
	public void setId_exc_trail(Integer id_exc_trail) {
		this.id_exc_trail = id_exc_trail;
	}
	public ExameTrailMakingBean getExameTrailMakingBean() {
		return exameTrailMakingBean;
	}
	public void setExameTrailMakingBean(ExameTrailMakingBean exameTrailMakingBean) {
		this.exameTrailMakingBean = exameTrailMakingBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
	private String responsavel;
	private String data_criacao;
}
