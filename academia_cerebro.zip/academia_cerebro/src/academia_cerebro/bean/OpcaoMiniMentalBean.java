package academia_cerebro.bean;

public class OpcaoMiniMentalBean {
	private Integer id;
	private Integer id_esc_mini_mental;
	private Boolean is_correct;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_esc_mini_mental() {
		return id_esc_mini_mental;
	}
	public void setId_esc_mini_mental(Integer id_esc_mini_mental) {
		this.id_esc_mini_mental = id_esc_mini_mental;
	}
	public Boolean getIs_correct() {
		return is_correct;
	}
	public void setIs_correct(Boolean is_correct) {
		this.is_correct = is_correct;
	}
}
