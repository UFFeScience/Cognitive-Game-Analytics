package academia_cerebro.bean;

public class JogoBean {
	private Integer id;
	private String nome;
	private String unidade_thresold;
	private String termo_original;
	private Integer id_grupodejogo;
	private GrupoDeJogoBean grupoJogoBean = new GrupoDeJogoBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getUnidade_thresold() {
		return unidade_thresold;
	}
	public void setUnidade_thresold(String unidade_thresold) {
		this.unidade_thresold = unidade_thresold;
	}
	public String getTermo_original() {
		return termo_original;
	}
	public void setTermo_original(String termo_original) {
		this.termo_original = termo_original;
	}
	public Integer getId_grupodejogo() {
		return id_grupodejogo;
	}
	public void setId_grupodejogo(Integer id_grupodejogo) {
		this.id_grupodejogo = id_grupodejogo;
	}
	public GrupoDeJogoBean getGrupoJogoBean() {
		return grupoJogoBean;
	}
	public void setGrupoJogoBean(GrupoDeJogoBean grupoJogoBean) {
		this.grupoJogoBean = grupoJogoBean;
	}
}
