package academia_cerebro.bean;

public class QuestaoKatzBean {
	private Integer id;
	private String pergunta;
	private Integer id_secao_katz;
	private SecaoDocumentoKatzBean secaoDocKatzBean = new SecaoDocumentoKatzBean();
	public SecaoDocumentoKatzBean getSecaoDocKatzBean() {
		return secaoDocKatzBean;
	}
	public void setSecaoDocKatzBean(SecaoDocumentoKatzBean secaoDocKatzBean) {
		this.secaoDocKatzBean = secaoDocKatzBean;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	public Integer getId_secao_katz() {
		return id_secao_katz;
	}
	public void setId_secao_katz(Integer id_secao_katz) {
		this.id_secao_katz = id_secao_katz;
	}
}
