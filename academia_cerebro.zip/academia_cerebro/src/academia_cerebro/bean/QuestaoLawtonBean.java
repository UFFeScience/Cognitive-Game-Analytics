package academia_cerebro.bean;

public class QuestaoLawtonBean {
	private Integer id;
	private String pergunta;
	private Integer id_secao_lawton;
	private SecaoDocumentoLawtonBean secaoDocLawtonBean = new SecaoDocumentoLawtonBean();
	public SecaoDocumentoLawtonBean getSecaoDocLawtonBean() {
		return secaoDocLawtonBean;
	}
	public void setSecaoDocLawtonBean(SecaoDocumentoLawtonBean secaoDocLawtonBean) {
		this.secaoDocLawtonBean = secaoDocLawtonBean;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	public Integer getId_secao_lawton() {
		return id_secao_lawton;
	}
	public void setId_secao_lawton(Integer id_secao_lawton) {
		this.id_secao_lawton = id_secao_lawton;
	}
}
