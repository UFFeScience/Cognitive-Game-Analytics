package academia_cerebro.bean;

public class DocumentoRavltBean {
	private Integer id;
	private Integer id_exc_ravlt;
	private ExameRavltBean exameRavltBean = new ExameRavltBean(); 
	private String responsavel;
	private String data_criacao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_ravlt() {
		return id_exc_ravlt;
	}
	public void setId_exc_ravlt(Integer id_exc_ravlt) {
		this.id_exc_ravlt = id_exc_ravlt;
	}
	public ExameRavltBean getExameRavltBean() {
		return exameRavltBean;
	}
	public void setExameRavltBean(ExameRavltBean exameRavltBean) {
		this.exameRavltBean = exameRavltBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
}
