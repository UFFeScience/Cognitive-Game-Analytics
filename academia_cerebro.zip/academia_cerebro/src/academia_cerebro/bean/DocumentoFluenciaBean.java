package academia_cerebro.bean;

public class DocumentoFluenciaBean {
	private Integer id;
	private Integer id_exc_fluencia;
	private ExameFluenciaBean exameFluenciaBean = new ExameFluenciaBean(); 
	private String responsavel;
	private String data_criacao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_fluencia() {
		return id_exc_fluencia;
	}
	public void setId_exc_fluencia(Integer id_exc_fluencia) {
		this.id_exc_fluencia = id_exc_fluencia;
	}
	public ExameFluenciaBean getExameFluenciaBean() {
		return exameFluenciaBean;
	}
	public void setExameFluenciaBean(ExameFluenciaBean exameFluenciaBean) {
		this.exameFluenciaBean = exameFluenciaBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
}
