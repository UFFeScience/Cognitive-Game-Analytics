package academia_cerebro.bean;

public class AcaoTiadlBean {
	private Integer id;
	private Integer id_questao_tiadl;
	private String descricao_acao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_questao_tiadl() {
		return id_questao_tiadl;
	}
	public void setId_questao_tiadl(Integer id_questao_tiadl) {
		this.id_questao_tiadl = id_questao_tiadl;
	}
	public String getDescricao_acao() {
		return descricao_acao;
	}
	public void setDescricao_acao(String descricao_acao) {
		this.descricao_acao = descricao_acao;
	}
	
}
