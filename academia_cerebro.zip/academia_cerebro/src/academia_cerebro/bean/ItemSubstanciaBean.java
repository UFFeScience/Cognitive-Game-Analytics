package academia_cerebro.bean;

public class ItemSubstanciaBean {
	private Integer id;
	private Integer id_doc_substancia;
	private DocumentoSubstanciaBean documentoSubstanciaBean = new DocumentoSubstanciaBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_substancia() {
		return id_doc_substancia;
	}
	public void setId_doc_substancia(Integer id_doc_substancia) {
		this.id_doc_substancia = id_doc_substancia;
	}
	public DocumentoSubstanciaBean getDocumentoSubstanciaBean() {
		return documentoSubstanciaBean;
	}
	public void setDocumentoSubstanciaBean(DocumentoSubstanciaBean documentoSubstanciaBean) {
		this.documentoSubstanciaBean = documentoSubstanciaBean;
	}
}
