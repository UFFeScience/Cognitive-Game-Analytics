package academia_cerebro.bean;

public class ItemMiniMentalBean {
	private Integer id;
	private Integer id_secao_mini_mental;
	private SecaoDocumentoMiniMentalBean secaoDocMiniMentalBean = new SecaoDocumentoMiniMentalBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_secao_mini_mental() {
		return id_secao_mini_mental;
	}
	public void setId_secao_mini_mental(Integer id_secao_mini_mental) {
		this.id_secao_mini_mental = id_secao_mini_mental;
	}
	public SecaoDocumentoMiniMentalBean getSecaoDocMiniMentalBean() {
		return secaoDocMiniMentalBean;
	}
	public void setSecaoDocMiniMentalBean(SecaoDocumentoMiniMentalBean secaoDocMiniMentalBean) {
		this.secaoDocMiniMentalBean = secaoDocMiniMentalBean;
	}
}
