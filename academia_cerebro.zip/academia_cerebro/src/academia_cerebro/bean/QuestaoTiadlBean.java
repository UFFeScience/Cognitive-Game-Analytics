package academia_cerebro.bean;

public class QuestaoTiadlBean {
	private Integer id;
	private String titulo;
	private Integer id_secao_tiadl;
	private SecaoDocumentoTiadlBean secaoDocTiadlBean = new SecaoDocumentoTiadlBean();
	public SecaoDocumentoTiadlBean getSecaoDocTiadlBean() {
		return secaoDocTiadlBean;
	}
	public void setSecaoDocTiadlBean(SecaoDocumentoTiadlBean secaoDocTiadlBean) {
		this.secaoDocTiadlBean = secaoDocTiadlBean;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public Integer getId_secao_tiadl() {
		return id_secao_tiadl;
	}
	public void setId_secao_tiadl(Integer id_secao_tiadl) {
		this.id_secao_tiadl = id_secao_tiadl;
	}
}
