package academia_cerebro.bean;

public class CalculoMiniMentalBean extends ItemMiniMentalBean {
	private Integer id_item_mm;
	private String instrucao;
	public Integer getId_item_mm() {
		return id_item_mm;
	}
	public void setId_item_mm(Integer id_item_mm) {
		this.id_item_mm = id_item_mm;
	}
	public String getInstrucao() {
		return instrucao;
	}
	public void setInstrucao(String instrucao) {
		this.instrucao = instrucao;
	}
}
