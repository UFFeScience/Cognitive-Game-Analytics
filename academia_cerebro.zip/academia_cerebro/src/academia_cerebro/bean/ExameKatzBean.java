package academia_cerebro.bean;

public class ExameKatzBean extends ExameCognitivoBean {
	private Integer id_exc;

	public Integer getId_exc() {
		return id_exc;
	}

	public void setId_exc(Integer id_exc) {
		this.id_exc = id_exc;
	}
}
