package academia_cerebro.bean;

public class SecaoDocumentoExamesBean {
	private Integer id;
	private Integer id_doc;
	private DocumentoCamcogBean documentoCamcogBean = new DocumentoCamcogBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc() {
		return id_doc;
	}
	public void setId_doc(Integer id_doc) {
		this.id_doc = id_doc;
	}
	public DocumentoCamcogBean getDocumentoCamcogBean() {
		return documentoCamcogBean;
	}
	public void setDocumentoCamcogBean(DocumentoCamcogBean documentoCamcogBean) {
		this.documentoCamcogBean = documentoCamcogBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
