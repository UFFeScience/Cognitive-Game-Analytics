package academia_cerebro.bean;

public class IteracaoMiniMentalBean {
	private Integer id;
	private Float valor_esperado;
	private Integer pontuacao;
	private Integer id_calc_mini_mental;
	private CalculoMiniMentalBean calcMiniMentalBean = new CalculoMiniMentalBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Float getValor_esperado() {
		return valor_esperado;
	}
	public void setValor_esperado(Float valor_esperado) {
		this.valor_esperado = valor_esperado;
	}
	public Integer getPontuacao() {
		return pontuacao;
	}
	public void setPontuacao(Integer pontuacao) {
		this.pontuacao = pontuacao;
	}
	public Integer getId_calc_mini_mental() {
		return id_calc_mini_mental;
	}
	public void setId_calc_mini_mental(Integer id_calc_mini_mental) {
		this.id_calc_mini_mental = id_calc_mini_mental;
	}
	public CalculoMiniMentalBean getCalcMiniMentalBean() {
		return calcMiniMentalBean;
	}
	public void setCalcMiniMentalBean(CalculoMiniMentalBean calcMiniMentalBean) {
		this.calcMiniMentalBean = calcMiniMentalBean;
	}
}
