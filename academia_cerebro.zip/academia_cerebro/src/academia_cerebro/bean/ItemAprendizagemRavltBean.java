package academia_cerebro.bean;

public class ItemAprendizagemRavltBean {
	private Integer id;
	private Integer id_item_ravlt;
	private String descricao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_item_ravlt() {
		return id_item_ravlt;
	}
	public void setId_item_ravlt(Integer id_item_ravlt) {
		this.id_item_ravlt = id_item_ravlt;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
