package academia_cerebro.bean;

public class SecaoDocumentoMiniMentalBean {
	private Integer id;
	private Integer id_doc_mini_mental;
	private DocumentoMiniMentalBean documentoMiniMentalBean = new DocumentoMiniMentalBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_mini_mental() {
		return id_doc_mini_mental;
	}
	public void setId_doc_mini_mental(Integer id_doc_mini_mental) {
		this.id_doc_mini_mental = id_doc_mini_mental;
	}
	public DocumentoMiniMentalBean getDocumentoMiniMentalBean() {
		return documentoMiniMentalBean;
	}
	public void setDocumentoMiniMentalBean(DocumentoMiniMentalBean documentoMiniMentalBean) {
		this.documentoMiniMentalBean = documentoMiniMentalBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
