package academia_cerebro.bean;

public class SecaoDocumentoGdsBean {
	private Integer id;
	private Integer id_doc_gds;
	private DocumentoGdsBean documentoGdsBean = new DocumentoGdsBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_gds() {
		return id_doc_gds;
	}
	public void setId_doc_gds(Integer id_doc_gds) {
		this.id_doc_gds = id_doc_gds;
	}
	public DocumentoGdsBean getDocumentoGdsBean() {
		return documentoGdsBean;
	}
	public void setDocumentoGdsBean(DocumentoGdsBean documentoGdsBean) {
		this.documentoGdsBean = documentoGdsBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
