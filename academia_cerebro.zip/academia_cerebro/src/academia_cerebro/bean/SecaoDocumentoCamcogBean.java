package academia_cerebro.bean;

public class SecaoDocumentoCamcogBean {
	private Integer id;
	private Integer id_doc_camcog;
	private DocumentoCamcogBean documentoCamcogBean = new DocumentoCamcogBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_camcog() {
		return id_doc_camcog;
	}
	public void setId_doc_camcog(Integer id_doc_camcog) {
		this.id_doc_camcog = id_doc_camcog;
	}
	public DocumentoCamcogBean getDocumentoCamcogBean() {
		return documentoCamcogBean;
	}
	public void setDocumentoCamcogBean(DocumentoCamcogBean documentoCamcogBean) {
		this.documentoCamcogBean = documentoCamcogBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
