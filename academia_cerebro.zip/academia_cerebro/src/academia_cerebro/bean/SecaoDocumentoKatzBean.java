package academia_cerebro.bean;

public class SecaoDocumentoKatzBean {
	private Integer id;
	private Integer id_doc_katz;
	private DocumentoKatzBean documentoKatzBean = new DocumentoKatzBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_katz() {
		return id_doc_katz;
	}
	public void setId_doc_katz(Integer id_doc_katz) {
		this.id_doc_katz = id_doc_katz;
	}
	public DocumentoKatzBean getDocumentoKatzBean() {
		return documentoKatzBean;
	}
	public void setDocumentoKatzBean(DocumentoKatzBean documentoKatzBean) {
		this.documentoKatzBean = documentoKatzBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
