package academia_cerebro.bean;

public class SecaoDocumentoTugBean {
	private Integer id;
	private Integer id_doc_tug;
	private DocumentoTugBean documentoTugBean = new DocumentoTugBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_tug() {
		return id_doc_tug;
	}
	public void setId_doc_tug(Integer id_doc_tug) {
		this.id_doc_tug = id_doc_tug;
	}
	public DocumentoTugBean getDocumentoTugBean() {
		return documentoTugBean;
	}
	public void setDocumentoTugBean(DocumentoTugBean documentoTugBean) {
		this.documentoTugBean = documentoTugBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
