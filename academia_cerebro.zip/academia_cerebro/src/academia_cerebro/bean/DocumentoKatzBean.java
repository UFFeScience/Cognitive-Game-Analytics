package academia_cerebro.bean;

public class DocumentoKatzBean {
	private Integer id;
	private Integer id_exc_katz;
	private ExameKatzBean exameKatzBean = new ExameKatzBean(); 
	private String responsavel;
	private String data_criacao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_katz() {
		return id_exc_katz;
	}
	public void setId_exc_katz(Integer id_exc_katz) {
		this.id_exc_katz = id_exc_katz;
	}
	public ExameKatzBean getExameKatzBean() {
		return exameKatzBean;
	}
	public void setExameKatzBean(ExameKatzBean exameKatzBean) {
		this.exameKatzBean = exameKatzBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
}
