package academia_cerebro.bean;

public class SecaoDocumentoLawtonBean {
	private Integer id;
	private Integer id_doc_lawton;
	private DocumentoLawtonBean documentoLawtonBean = new DocumentoLawtonBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_lawton() {
		return id_doc_lawton;
	}
	public void setId_doc_lawton(Integer id_doc_lawton) {
		this.id_doc_lawton = id_doc_lawton;
	}
	public DocumentoLawtonBean getDocumentoLawtonBean() {
		return documentoLawtonBean;
	}
	public void setDocumentoLawtonBean(DocumentoLawtonBean documentoLawtonBean) {
		this.documentoLawtonBean = documentoLawtonBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
