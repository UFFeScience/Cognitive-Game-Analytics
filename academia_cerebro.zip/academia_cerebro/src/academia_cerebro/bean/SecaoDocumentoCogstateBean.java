package academia_cerebro.bean;

public class SecaoDocumentoCogstateBean {
	private Integer id;
	private Integer id_doc_cogstate;
	private DocumentoCogstateBean documentoCogstateBean = new DocumentoCogstateBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_cogstate() {
		return id_doc_cogstate;
	}
	public void setId_doc_cogstate(Integer id_doc_cogstate) {
		this.id_doc_cogstate = id_doc_cogstate;
	}
	public DocumentoCogstateBean getDocumentoCogstateBean() {
		return documentoCogstateBean;
	}
	public void setDocumentoCogstateBean(DocumentoCogstateBean documentoCogstateBean) {
		this.documentoCogstateBean = documentoCogstateBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
