package academia_cerebro.bean;

public class DocumentoTugBean {
	private Integer id;
	private Integer id_exc_tug;
	private ExameTugBean exameTugBean = new ExameTugBean(); 
	private String responsavel;
	private String data_criacao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_tug() {
		return id_exc_tug;
	}
	public void setId_exc_tug(Integer id_exc_tug) {
		this.id_exc_tug = id_exc_tug;
	}
	public ExameTugBean getExameTugBean() {
		return exameTugBean;
	}
	public void setExameTugBean(ExameTugBean exameTugBean) {
		this.exameTugBean = exameTugBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
}
