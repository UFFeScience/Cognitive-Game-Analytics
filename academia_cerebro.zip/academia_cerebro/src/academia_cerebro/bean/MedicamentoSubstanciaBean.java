package academia_cerebro.bean;

public class MedicamentoSubstanciaBean extends ItemSubstanciaBean {
	private Integer id_item_subst;
	private Boolean is_atual;
	public Integer getId_item_subst() {
		return id_item_subst;
	}
	public void setId_item_subst(Integer id_item_subst) {
		this.id_item_subst = id_item_subst;
	}
	public Boolean getIs_atual() {
		return is_atual;
	}
	public void setIs_atual(Boolean is_atual) {
		this.is_atual = is_atual;
	}
}
