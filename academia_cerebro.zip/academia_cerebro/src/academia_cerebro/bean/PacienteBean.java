package academia_cerebro.bean;

public class PacienteBean {
	private Integer id;
	private Integer numero;
	private String nome;
	private String contato_previo;
	private String genero;
	private Integer escolaridade_anos;
	private Integer idade;
	private String atividade_memoria;
	private String situacao;
	private String grupo;
	private Integer altura;
	private Integer peso;
	private Integer imc;
	private String qi;
	private String dt_nasc;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getNumero() {
		return numero;
	}
	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	public Integer getAltura() {
		return altura;
	}
	public void setAltura(Integer altura) {
		this.altura = altura;
	}
	public Integer getPeso() {
		return peso;
	}
	public void setPeso(Integer peso) {
		this.peso = peso;
	}
	public Integer getImc() {
		return imc;
	}
	public void setImc(Integer imc) {
		this.imc = imc;
	}
	public String getQi() {
		return qi;
	}
	public void setQi(String qi) {
		this.qi = qi;
	}
	public String getDt_nasc() {
		return dt_nasc;
	}
	public void setDt_nasc(String dt_nasc) {
		this.dt_nasc = dt_nasc;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getContato_previo() {
		return contato_previo;
	}
	public void setContato_previo(String contato_previo) {
		this.contato_previo = contato_previo;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public Integer getEscolaridade_anos() {
		return escolaridade_anos;
	}
	public void setEscolaridade_anos(Integer escolaridade_anos) {
		this.escolaridade_anos = escolaridade_anos;
	}
	public Integer getIdade() {
		return idade;
	}
	public void setIdade(Integer idade) {
		this.idade = idade;
	}
	public String getAtividade_memoria() {
		return atividade_memoria;
	}
	public void setAtividade_memoria(String atividade_memoria) {
		this.atividade_memoria = atividade_memoria;
	}
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	
	
}
