package academia_cerebro.bean;

public class SecaoDocumentoTrailMakingBean {
	private Integer id;
	private Integer id_doc_trail;
	private DocumentoTrailMakingBean documentoTrailMakingBean = new DocumentoTrailMakingBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_trail() {
		return id_doc_trail;
	}
	public void setId_doc_trail(Integer id_doc_trail) {
		this.id_doc_trail = id_doc_trail;
	}
	public DocumentoTrailMakingBean getDocumentoTrailMakingBean() {
		return documentoTrailMakingBean;
	}
	public void setDocumentoTrailMakingBean(DocumentoTrailMakingBean documentoTrailMakingBean) {
		this.documentoTrailMakingBean = documentoTrailMakingBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
