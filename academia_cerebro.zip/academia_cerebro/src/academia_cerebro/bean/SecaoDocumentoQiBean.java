package academia_cerebro.bean;

public class SecaoDocumentoQiBean {
	private Integer id;
	private Integer id_doc_qi;
	private DocumentoQiBean documentoQiBean = new DocumentoQiBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_qi() {
		return id_doc_qi;
	}
	public void setId_doc_qi(Integer id_doc_qi) {
		this.id_doc_qi = id_doc_qi;
	}
	public DocumentoQiBean getDocumentoQiBean() {
		return documentoQiBean;
	}
	public void setDocumentoQiBean(DocumentoQiBean documentoQiBean) {
		this.documentoQiBean = documentoQiBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	private String titulo;
}
