package academia_cerebro.bean;

public class EscolhaMiniMentalBean extends ItemMiniMentalBean {
	private Integer id_item_mm;
	private String texto;
	public Integer getId_item_mm() {
		return id_item_mm;
	}
	public void setId_item_mm(Integer id_item_mm) {
		this.id_item_mm = id_item_mm;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
}
