package academia_cerebro.bean;

public class SecaoDocumentoWhoqolBean {
	private Integer id;
	private Integer id_doc_whoqol;
	private DocumentoWhoqolBean documentoWhoqolBean = new DocumentoWhoqolBean();
	private String titulo;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_whoqol() {
		return id_doc_whoqol;
	}
	public void setId_doc_whoqol(Integer id_doc_whoqol) {
		this.id_doc_whoqol = id_doc_whoqol;
	}
	public DocumentoWhoqolBean getDocumentoWhoqolBean() {
		return documentoWhoqolBean;
	}
	public void setDocumentoWhoqolBean(DocumentoWhoqolBean documentoWhoqolBean) {
		this.documentoWhoqolBean = documentoWhoqolBean;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
