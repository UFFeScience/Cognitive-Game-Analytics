package academia_cerebro.bean;

public class TipoAvaliacaoPacienteBean {
	private Integer id;
	private Integer id_tipo_avaliacao;
	private Integer id_avaliacao;
	private TipoAvaliacaoBean tpAvaliacao = new TipoAvaliacaoBean();
	private AvaliacaoPacienteBean avPacienteBean = new AvaliacaoPacienteBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_tipo_avaliacao() {
		return id_tipo_avaliacao;
	}
	public void setId_tipo_avaliacao(Integer id_tipo_avaliacao) {
		this.id_tipo_avaliacao = id_tipo_avaliacao;
	}
	public Integer getId_avaliacao() {
		return id_avaliacao;
	}
	public void setId_avaliacao(Integer id_avaliacao) {
		this.id_avaliacao = id_avaliacao;
	}
	public TipoAvaliacaoBean getTpAvaliacao() {
		return tpAvaliacao;
	}
	public void setTpAvaliacao(TipoAvaliacaoBean tpAvaliacao) {
		this.tpAvaliacao = tpAvaliacao;
	}
	public AvaliacaoPacienteBean getAvPacienteBean() {
		return avPacienteBean;
	}
	public void setAvPacienteBean(AvaliacaoPacienteBean avPacienteBean) {
		this.avPacienteBean = avPacienteBean;
	}
	public String getPeriodo() {
		return periodo;
	}
	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}
	private String periodo;
}
