package academia_cerebro.bean;

public class QuestaoWhoqolBean {
	private Integer id;
	private String pergunta;
	private Integer id_secao_whoqol;
	private SecaoDocumentoWhoqolBean secaoDocWhoqolBean = new SecaoDocumentoWhoqolBean();
	public SecaoDocumentoWhoqolBean getSecaoDocWhoqolBean() {
		return secaoDocWhoqolBean;
	}
	public void setSecaoDocWhoqolBean(SecaoDocumentoWhoqolBean secaoDocWhoqolBean) {
		this.secaoDocWhoqolBean = secaoDocWhoqolBean;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	public Integer getId_secao_whoqol() {
		return id_secao_whoqol;
	}
	public void setId_secao_whoqol(Integer id_secao_whoqol) {
		this.id_secao_whoqol = id_secao_whoqol;
	}
}
