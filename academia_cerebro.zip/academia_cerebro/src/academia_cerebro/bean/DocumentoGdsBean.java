package academia_cerebro.bean;

public class DocumentoGdsBean {
	private Integer id;
	private Integer id_exc_gds;
	private ExameGdsBean exameGdsBean = new ExameGdsBean(); 
	private String responsavel;
	private String data_criacao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_gds() {
		return id_exc_gds;
	}
	public void setId_exc_gds(Integer id_exc_gds) {
		this.id_exc_gds = id_exc_gds;
	}
	public ExameGdsBean getExameGdsBean() {
		return exameGdsBean;
	}
	public void setExameGdsBean(ExameGdsBean exameGdsBean) {
		this.exameGdsBean = exameGdsBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
}
