package academia_cerebro.bean;

public class SessaoJogoBean {
	private Integer id_paciente;
	private Integer id_jogo;
	private JogoBean jogoBean = new JogoBean();
	private PacienteBean pacienteBean = new PacienteBean();
	private String data_local;
	private String tempo;
	private Double z_score;
	private String hora;
	private Integer id_avaliacao;
	private Double thresold;
	private Integer stars;
	private Integer id;
	
	public Integer getId_paciente() {
		return id_paciente;
	}
	public void setId_paciente(Integer id_paciente) {
		this.id_paciente = id_paciente;
	}
	public Integer getId_jogo() {
		return id_jogo;
	}
	public void setId_jogo(Integer id_jogo) {
		this.id_jogo = id_jogo;
	}
	public JogoBean getJogoBean() {
		return jogoBean;
	}
	public void setJogoBean(JogoBean jogoBean) {
		this.jogoBean = jogoBean;
	}
	public PacienteBean getPacienteBean() {
		return pacienteBean;
	}
	public void setPacienteBean(PacienteBean pacienteBean) {
		this.pacienteBean = pacienteBean;
	}
	public String getTempo() {
		return tempo;
	}
	public String getData_local() {
		return data_local;
	}
	public void setData_local(String data_local) {
		this.data_local = data_local;
	}
	public void setTempo(String tempo) {
		this.tempo = tempo;
	}
	public Double getZ_score() {
		return z_score;
	}
	public void setZ_score(Double z_score) {
		this.z_score = z_score;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	
	public Integer getId_avaliacao() {
		return id_avaliacao;
	}
	public void setId_avaliacao(Integer id_avaliacao) {
		this.id_avaliacao = id_avaliacao;
	}
	
	public Double getThresold() {
		return thresold;
	}
	public void setThresold(Double thresold) {
		this.thresold = thresold;
	}
	
	/*public Long getThresold() {
		return thresold;
	}
	public void setThresold(Long thresold) {
		this.thresold = thresold;
	}*/
	
	/*public Integer getThresold() {
		return thresold;
	}
	public void setThresold(Integer thresold) {
		this.thresold = thresold;
	}*/
	public Integer getStars() {
		return stars;
	}
	public void setStars(Integer stars) {
		this.stars = stars;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
}
