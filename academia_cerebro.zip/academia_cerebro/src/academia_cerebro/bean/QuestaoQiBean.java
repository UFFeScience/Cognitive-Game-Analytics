package academia_cerebro.bean;

public class QuestaoQiBean {
	private Integer id;
	private String pergunta;
	private Integer id_secao_qi;
	private SecaoDocumentoQiBean secaoDocQiBean = new SecaoDocumentoQiBean();
	public SecaoDocumentoQiBean getSecaoDocQiBean() {
		return secaoDocQiBean;
	}
	public void setSecaoDocQiBean(SecaoDocumentoQiBean secaoDocQiBean) {
		this.secaoDocQiBean = secaoDocQiBean;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	public Integer getId_secao_qi() {
		return id_secao_qi;
	}
	public void setId_secao_qi(Integer id_secao_qi) {
		this.id_secao_qi = id_secao_qi;
	}
}
