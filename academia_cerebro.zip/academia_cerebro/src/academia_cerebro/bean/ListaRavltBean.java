package academia_cerebro.bean;

public class ListaRavltBean {
	private Integer id;
	private Integer id_doc_ravlt;
	private DocumentoRavltBean documentoRavltBean = new DocumentoRavltBean();
	private String nome;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_doc_ravlt() {
		return id_doc_ravlt;
	}
	public void setId_doc_ravlt(Integer id_doc_ravlt) {
		this.id_doc_ravlt = id_doc_ravlt;
	}
	public DocumentoRavltBean getDocumentoRavltBean() {
		return documentoRavltBean;
	}
	public void setDocumentoRavltBean(DocumentoRavltBean documentoRavltBean) {
		this.documentoRavltBean = documentoRavltBean;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
}
