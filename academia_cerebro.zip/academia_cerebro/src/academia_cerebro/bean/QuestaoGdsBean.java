package academia_cerebro.bean;

public class QuestaoGdsBean {
	private Integer id;
	private String pergunta;
	private Integer id_secao_gds;
	private SecaoDocumentoGdsBean secaoDocGdsBean = new SecaoDocumentoGdsBean();
	public SecaoDocumentoGdsBean getSecaoDocGdsBean() {
		return secaoDocGdsBean;
	}
	public void setSecaoDocGdsBean(SecaoDocumentoGdsBean secaoDocGdsBean) {
		this.secaoDocGdsBean = secaoDocGdsBean;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	public Integer getId_secao_gds() {
		return id_secao_gds;
	}
	public void setId_secao_gds(Integer id_secao_gds) {
		this.id_secao_gds = id_secao_gds;
	}
}
