package academia_cerebro.bean;

public class DocumentoTiadlBean {
	private Integer id;
	private Integer id_exc_tiadl;
	private ExameTiadlBean exameTiadlBean = new ExameTiadlBean(); 
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_tiadl() {
		return id_exc_tiadl;
	}
	public void setId_exc_tiadl(Integer id_exc_tiadl) {
		this.id_exc_tiadl = id_exc_tiadl;
	}
	public ExameTiadlBean getExameTiadlBean() {
		return exameTiadlBean;
	}
	public void setExameTiadlBean(ExameTiadlBean exameTiadlBean) {
		this.exameTiadlBean = exameTiadlBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
	private String responsavel;
	private String data_criacao;
}
