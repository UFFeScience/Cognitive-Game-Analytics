package academia_cerebro.bean;

public class DocumentoCamcogBean {
	private Integer id;
	private Integer id_exc_camcog;
	private ExameCamcogBean exameCamcogBean = new ExameCamcogBean(); 
	private String responsavel;
	private String data_criacao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_camcog() {
		return id_exc_camcog;
	}
	public void setId_exc_camcog(Integer id_exc_camcog) {
		this.id_exc_camcog = id_exc_camcog;
	}
	public ExameCamcogBean getExameCamcogBean() {
		return exameCamcogBean;
	}
	public void setExameCamcogBean(ExameCamcogBean exameCamcogBean) {
		this.exameCamcogBean = exameCamcogBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
}
