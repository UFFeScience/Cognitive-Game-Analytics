package academia_cerebro.bean;

public class DrogaSubstanciaBean extends ItemSubstanciaBean {
	private Integer id_item_subst;
	public Integer getId_item_subst() {
		return id_item_subst;
	}
	public void setId_item_subst(Integer id_item_subst) {
		this.id_item_subst = id_item_subst;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	private String pergunta;
}
