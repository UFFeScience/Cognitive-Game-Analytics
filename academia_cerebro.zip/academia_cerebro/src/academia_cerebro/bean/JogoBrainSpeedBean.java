package academia_cerebro.bean;

public class JogoBrainSpeedBean extends JogoBean {
	private Integer id_jogo;

	public Integer getId_jogo() {
		return id_jogo;
	}

	public void setId_jogo(Integer id_jogo) {
		this.id_jogo = id_jogo;
	}
}
