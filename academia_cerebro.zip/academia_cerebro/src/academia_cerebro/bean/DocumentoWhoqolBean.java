package academia_cerebro.bean;

public class DocumentoWhoqolBean {
	private Integer id;
	private Integer id_exc_whoqol;
	private ExameWhoqolBean exameWhoqolBean = new ExameWhoqolBean(); 
	private String responsavel;
	private String data_criacao;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_exc_whoqol() {
		return id_exc_whoqol;
	}
	public void setId_exc_whoqol(Integer id_exc_whoqol) {
		this.id_exc_whoqol = id_exc_whoqol;
	}
	public ExameWhoqolBean getExameWhoqolBean() {
		return exameWhoqolBean;
	}
	public void setExameWhoqolBean(ExameWhoqolBean exameWhoqolBean) {
		this.exameWhoqolBean = exameWhoqolBean;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getData_criacao() {
		return data_criacao;
	}
	public void setData_criacao(String data_criacao) {
		this.data_criacao = data_criacao;
	}
}
