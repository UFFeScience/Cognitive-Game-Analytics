package academia_cerebro.bean;

public class QuestaoMiniMentalBean extends ItemMiniMentalBean {
	private Integer id_item_mm;
	private String texto;
	private String resp_esperado;
	public Integer getId_item_mm() {
		return id_item_mm;
	}
	public void setId_item_mm(Integer id_item_mm) {
		this.id_item_mm = id_item_mm;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public String getResp_esperado() {
		return resp_esperado;
	}
	public void setResp_esperado(String resp_esperado) {
		this.resp_esperado = resp_esperado;
	}
}
