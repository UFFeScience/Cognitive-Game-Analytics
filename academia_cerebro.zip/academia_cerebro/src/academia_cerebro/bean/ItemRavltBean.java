package academia_cerebro.bean;

public class ItemRavltBean {
	private Integer id;
	private Integer id_lista_ravlt;
	private String titulo;
	private ListaRavltBean listaRavltBean = new ListaRavltBean();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId_lista_ravlt() {
		return id_lista_ravlt;
	}
	public void setId_lista_ravlt(Integer id_lista_ravlt) {
		this.id_lista_ravlt = id_lista_ravlt;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public ListaRavltBean getListaRavltBean() {
		return listaRavltBean;
	}
	public void setListaRavltBean(ListaRavltBean listaRavltBean) {
		this.listaRavltBean = listaRavltBean;
	}
}
