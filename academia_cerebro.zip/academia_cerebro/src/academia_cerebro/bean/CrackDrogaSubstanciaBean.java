package academia_cerebro.bean;

public class CrackDrogaSubstanciaBean extends DrogaSubstanciaBean {
	private Integer id_droga;

	public Integer getId_droga() {
		return id_droga;
	}

	public void setId_droga(Integer id_droga) {
		this.id_droga = id_droga;
	}
}
