package arquivoxls;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ArqXlsAux {
	public ArqXlsAux() {
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void executarQuery(String id) {
		// TODO Auto-generated method stub
		DataXlsDAO dtXlsDao = new DataXlsDAO();
		List<String> listaDatasRetornadas = new ArrayList<String>();
		try {
			listaDatasRetornadas = dtXlsDao.getListaData(id);
			gerarArquivoXls(listaDatasRetornadas, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void gerarArquivoXls(List<String> listaDatasRetornadas, String id) throws IOException {
		/* Início da Gravação na Planilha Excel */
		String path = null;
		HSSFWorkbook hwbk = new HSSFWorkbook();
		HSSFSheet sht = hwbk.createSheet(id);
		int i = 0;
		for (int index = 0; index < listaDatasRetornadas.size(); index++) {
			String data = (String) listaDatasRetornadas.get(index);
			
			HSSFRow rowXls = sht.createRow((short) 0 + index);
			
			HSSFCell celulaNovaDataXls = null;
			HSSFCell celulaNovaHoraXls = null;
			
			celulaNovaDataXls = rowXls.createCell(0);
			celulaNovaHoraXls = rowXls.createCell(1);
			
			celulaNovaDataXls.setCellValue(data);
			
			if ( i < 40 && listaDatasRetornadas.size() > 40 ) {
				celulaNovaHoraXls.setCellValue("T" + ++i);
			} else if ( i <= listaDatasRetornadas.size() && listaDatasRetornadas.size() < 40 ) {
				celulaNovaHoraXls.setCellValue("T" + ++i);
			}

		}
		
		path = "/Volumes/Seagate_Expansion_3TB_5_1_4/01 - Mestrado UFF/01-PostgreSQL e Java/Desenv/Java/01-Materiais para Popular as Tabelas/DataSets/dados/pacientes/treino2/" + id + ".xls";
		FileOutputStream fosOut = null;
		try {
			fosOut = new FileOutputStream(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		hwbk.write(fosOut);
		hwbk.close();
		fosOut.close();
		System.out.println("Seu Arquivo Excel (XLS) foi Gerado com Sucesso!!!");
	}
}
