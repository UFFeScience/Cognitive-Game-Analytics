package arquivoxls;

import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class InicioXls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("apple.awt.fileDialogForDirectories", "true");
		while(true) {
			String id = JOptionPane.showInputDialog("Informe o ID do paciente para gerar a nova planilha em excel. Digite (n)ão se quiser sair.");
			if(("n".toUpperCase()).equals(id.toUpperCase())) {
				break;
			} if(!"n".equals(id)) {
				ArqXlsAux arqXlsAux = new ArqXlsAux();
				arqXlsAux.executarQuery(id);
			} else {
				JOptionPane.showMessageDialog(null, id + " Inválido. Informe (s)im ou (n)ão. ", "Opção Errada!!!", JOptionPane.WARNING_MESSAGE);
			}
		}
		System.exit(0);
	}

}
