package arquivoxls;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DataXlsDAO {
	private Connection conn;
	
	public DataXlsDAO() {
		this.conn = new ConnectionFactory().getConnection();
	}
	
	public List<String> getListaData(String id) throws SQLException {
		/* Entrará o Select */
		
		PreparedStatement stmt = null;
		List<String> listaDataSessao = new ArrayList<String>();
		
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("select cast(chr(39) as varchar) || to_char(data_local, 'MM-DD-YY') || cast(chr(39) as varchar) as data")
				  .append(" from sessao where id_paciente ='" + id + "'")
				  .append(" group by data_local")
				  .append(" order by data_local");
		
		try {
			stmt = conn.prepareStatement(sqlBuilder.toString());
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				DataSessaoJogoBean dtSessaoJogoBean = new DataSessaoJogoBean();
				dtSessaoJogoBean.setData(rs.getString("data"));
				System.out.print(dtSessaoJogoBean.getData());
				listaDataSessao.add(dtSessaoJogoBean.getData());
			}
			
			rs.close();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				stmt.close();
			} 
			if (conn != null) {
				conn.close();
			}
		}
		
		return listaDataSessao;
	}	
}
